package com.daniil.zapret.whitelist

import android.content.Context

class WhitelistManager(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("whitelist", Context.MODE_PRIVATE)

    companion object {
        val DEFAULTS = listOf(
            "discord.com","discord.gg","discordapp.com","discordapp.net","discord.media",
            "youtube.com","youtu.be","googlevideo.com","ytimg.com","googleapis.com","google.com",
            "instagram.com","cdninstagram.com","facebook.com","fbcdn.net",
            "twitter.com","twimg.com","x.com","twitch.tv","jtvnw.net",
            "tiktok.com","reddit.com","redd.it","spotify.com","scdn.co",
            "telegram.org","t.me","github.com","githubusercontent.com","4pda.to",
            "whatsapp.com","whatsapp.net","wa.me","mmg.whatsapp.net","pps.whatsapp.net",
            "cloudflare.com","cloudflarestream.com"
        )
    }

    init { if (!prefs.contains("domains")) save(DEFAULTS) }

    fun get(): List<String> = prefs.getString("domains","")?.split("\n")?.filter { it.isNotBlank() } ?: emptyList()
    fun save(list: List<String>) = prefs.edit().putString("domains", list.joinToString("\n")).apply()
    fun add(d: String)    { save((get() + d.trim()).distinct()) }
    fun remove(d: String) { save(get().filter { it != d }) }

    fun getMode(): String  = prefs.getString("mode","whitelist") ?: "whitelist"
    fun setMode(m: String) = prefs.edit().putString("mode", m).apply()

    // true = bypass everything (don't use whitelist)
    fun isEmpty() = getMode() == "all"

    fun matchesPort(port: Int) = port == 443 || port == 80

    fun matchesSni(sni: String): Boolean {
        if (isEmpty()) return true
        val s = sni.lowercase()
        return get().any { d -> val dn = d.lowercase().trimStart('.'); s == dn || s.endsWith(".$dn") }
    }
}
