package com.daniil.zapret.core

import android.net.VpnService
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

private const val TAG = "PacketRouter"

/**
 * Reads raw IP packets from TUN.
 * For each TCP SYN: opens a real socket via SOCKS5 proxy (localhost:socksPort)
 * and relays data bidirectionally.
 * For UDP: relays directly.
 */
class PacketRouter(
    private val vpn: VpnService,
    private val tunIn: FileInputStream,
    private val tunOut: FileOutputStream,
    private val socksPort: Int,
    private val scope: CoroutineScope
) {
    private val running  = AtomicBoolean(false)
    private val executor = Executors.newCachedThreadPool()

    // Serialise TUN writes
    private val tunWriteQueue = LinkedBlockingQueue<ByteArray>(8192)

    // Active TCP sessions keyed by "clientPort-serverIP:serverPort"
    private val sessions = ConcurrentHashMap<String, TcpSession>()

    fun start() {
        running.set(true)

        // TUN writer thread
        executor.execute {
            while (running.get()) {
                try {
                    val pkt = tunWriteQueue.poll(200, TimeUnit.MILLISECONDS) ?: continue
                    if (pkt.isEmpty()) break
                    tunOut.write(pkt)
                } catch (_: Exception) {}
            }
        }

        // TUN reader thread
        executor.execute { readLoop() }
        Log.i(TAG, "PacketRouter started, socksPort=$socksPort")
    }

    fun stop() {
        running.set(false)
        sessions.values.forEach { it.close() }
        sessions.clear()
        tunWriteQueue.offer(ByteArray(0)) // wake writer
        executor.shutdownNow()
    }

    private fun tunWrite(pkt: ByteArray) {
        if (!tunWriteQueue.offer(pkt)) {
            tunWriteQueue.poll()
            tunWriteQueue.offer(pkt)
        }
    }

    // ─── Read loop ───────────────────────────────────────────────────────

    private fun readLoop() {
        val buf = ByteArray(65536)
        var pkts = 0
        Log.d(TAG, "readLoop started")
        while (running.get()) {
            val n = try { tunIn.read(buf) } catch (_: Exception) { -1 }
            if (n <= 0) continue
            pkts++
            if (pkts == 1) Log.i(TAG, "first packet! len=$n")

            val pkt = buf.copyOf(n)
            if (IP.version(pkt) != 4) continue

            val ihl   = IP.ihl(pkt)
            val proto = IP.proto(pkt)

            when (proto) {
                6  -> handleTcp(pkt, ihl)   // TCP
                17 -> handleUdp(pkt, ihl)   // UDP
            }
        }
        Log.d(TAG, "readLoop ended after $pkts packets")
    }

    // ─── TCP ─────────────────────────────────────────────────────────────

    private fun handleTcp(pkt: ByteArray, ihl: Int) {
        if (pkt.size < ihl + 20) return
        val flags  = IP.tcpFlags(pkt, ihl)
        val cIp    = IP.srcIp(pkt)
        val sIp    = IP.dstIp(pkt)
        val cPort  = IP.tcpSrcPort(pkt, ihl)
        val sPort  = IP.tcpDstPort(pkt, ihl)
        val seq    = IP.tcpSeq(pkt, ihl)
        val data   = IP.tcpPayload(pkt, ihl)
        val key    = "$cPort-${IP.ipStr(sIp)}:$sPort"

        if (flags and IP.SYN != 0 && flags and IP.ACK == 0) {
            // New connection — open SOCKS5 tunnel
            if (sessions.size > 200) cleanSessions()
            val sess = TcpSession(
                vpn       = vpn,
                write     = ::tunWrite,
                clientIp  = cIp,
                serverIp  = sIp,
                clientPort = cPort,
                serverPort = sPort,
                clientIsn  = seq,
                socksPort  = socksPort,
                executor  = executor
            )
            sessions[key] = sess
            sess.start()
            return
        }

        val sess = sessions[key] ?: return
        when {
            flags and IP.RST != 0 -> { sess.close(); sessions.remove(key) }
            flags and IP.FIN != 0 -> { sess.feedFin() }
            data.isNotEmpty()     -> { sess.advanceAck(seq, data.size); sess.feed(data) }
        }
        if (sess.isDead) sessions.remove(key)
    }

    private fun handleUdp(pkt: ByteArray, ihl: Int) {
        // UDP: relay directly (no DPI bypass needed for UDP)
        if (pkt.size < ihl + 8) return
        val cIp   = IP.srcIp(pkt)
        val sIp   = IP.dstIp(pkt)
        val cPort = IP.udpSrcPort(pkt, ihl)
        val sPort = IP.udpDstPort(pkt, ihl)
        val data  = IP.udpPayload(pkt, ihl)
        if (data.isEmpty()) return

        val key = "udp-$cPort-${IP.ipStr(sIp)}:$sPort"
        // Simple direct UDP relay (no per-session state needed for basic cases)
        executor.execute {
            try {
                val sock = java.net.DatagramSocket()
                vpn.protect(sock)
                sock.send(java.net.DatagramPacket(data, data.size,
                    InetAddress.getByAddress(sIp), sPort))
                val buf = ByteArray(65535)
                val resp = java.net.DatagramPacket(buf, buf.size)
                sock.soTimeout = 3000
                sock.receive(resp)
                val reply = IP.buildUdp(sIp, cIp, sPort, cPort, buf.copyOf(resp.length))
                tunWrite(reply)
                sock.close()
            } catch (_: Exception) {}
        }
    }

    private fun cleanSessions() {
        sessions.entries.removeIf { it.value.isDead }
    }
}

// ─── Single TCP session via SOCKS5 ───────────────────────────────────────────

private class TcpSession(
    private val vpn: VpnService,
    private val write: (ByteArray) -> Unit,
    private val clientIp: ByteArray,
    private val serverIp: ByteArray,
    private val clientPort: Int,
    private val serverPort: Int,
    clientIsn: Long,
    private val socksPort: Int,
    private val executor: java.util.concurrent.ExecutorService
) {
    private val mySeq  = AtomicLong(0x74AB0000L)
    @Volatile private var myAck = (clientIsn + 1L) and 0xFFFFFFFFL
    private val socket = Socket()
    private val queue  = LinkedBlockingQueue<ByteArray>(512)
    private val dead   = AtomicBoolean(false)

    val isDead get() = dead.get()

    fun feed(data: ByteArray) { if (!dead.get()) queue.offer(data) }
    fun feedFin() { dead.set(true) }
    fun close()   {
        dead.set(true)
        try { socket.close() } catch (_: Exception) {}
    }
    fun advanceAck(seq: Long, size: Int) {
        myAck = ((seq and 0xFFFFFFFFL) + size) and 0xFFFFFFFFL
    }

    fun start() { executor.execute { run() } }

    private fun run() {
        // Connect to SOCKS5 proxy (localhost)
        try {
            // Don't call protect() for localhost connections
            socket.connect(InetSocketAddress("127.0.0.1", socksPort), 5000)
            socket.tcpNoDelay = true

            val inp = socket.getInputStream()
            val out = socket.getOutputStream()

            // SOCKS5 handshake
            out.write(byteArrayOf(5, 1, 0)); out.flush()            // version 5, 1 method, no-auth
            val resp = ByteArray(2); inp.read(resp)                  // should be 05 00
            if (resp[0] != 5.toByte() || resp[1] != 0.toByte()) {
                Log.e(TAG, "SOCKS5 auth failed: ${resp.toHex()}")
                close(); return
            }

            // SOCKS5 CONNECT to real destination (IPv4)
            val req = ByteArray(10)
            req[0] = 5; req[1] = 1; req[2] = 0; req[3] = 1         // ver,CONNECT,rsv,IPv4
            serverIp.copyInto(req, 4)
            req[8] = (serverPort shr 8).toByte()
            req[9] = serverPort.toByte()
            out.write(req); out.flush()

            val rep = ByteArray(10); inp.read(rep)
            if (rep[1] != 0.toByte()) {
                Log.w(TAG, "SOCKS5 connect failed code=${rep[1]}")
                close(); return
            }
        } catch (e: Exception) {
            Log.d(TAG, "SOCKS5 connect error: ${e.message}")
            close(); return
        }

        // Tell client we're ready
        synAck(); mySeq.incrementAndGet()

        // Server→Client
        executor.execute {
            try {
                val buf = ByteArray(1440)
                val inp = socket.getInputStream()
                while (!dead.get()) {
                    val n = inp.read(buf)
                    if (n == -1) break
                    send(IP.PSH or IP.ACK, buf.copyOf(n))
                }
            } catch (_: Exception) {
            } finally {
                if (!dead.get()) try { send(IP.FIN or IP.ACK, ByteArray(0)) } catch (_: Exception) {}
                close()
            }
        }

        // Client→Server
        try {
            val out = socket.getOutputStream()
            while (!dead.get()) {
                val data = queue.poll(300, TimeUnit.MILLISECONDS) ?: continue
                out.write(data); out.flush()
                send(IP.ACK, ByteArray(0))
            }
        } catch (_: Exception) {
        } finally { close() }
    }

    @Synchronized
    private fun send(flags: Int, payload: ByteArray) {
        val seq = mySeq.get() and 0xFFFFFFFFL
        write(IP.buildTcp(
            srcIp = serverIp, dstIp = clientIp,
            srcPort = serverPort, dstPort = clientPort,
            seq = seq, ack = myAck, flags = flags, payload = payload
        ))
        if (payload.isNotEmpty()) mySeq.addAndGet(payload.size.toLong())
        if (flags and IP.FIN != 0) mySeq.incrementAndGet()
    }

    private fun synAck() = send(IP.SYN or IP.ACK, ByteArray(0))
}

private fun ByteArray.toHex() = joinToString("") { "%02x".format(it) }

// ─── IP/TCP/UDP packet utilities ─────────────────────────────────────────────

object IP {
    const val SYN = 0x02; const val ACK = 0x10; const val PSH = 0x08
    const val RST = 0x04; const val FIN = 0x01
    const val PROTO_TCP = 6; const val PROTO_UDP = 17

    fun version(b: ByteArray) = (b[0].toInt() ushr 4) and 0xF
    fun ihl(b: ByteArray)     = (b[0].toInt() and 0xF) * 4
    fun proto(b: ByteArray)   = b[9].toInt() and 0xFF
    fun srcIp(b: ByteArray)   = b.copyOfRange(12, 16)
    fun dstIp(b: ByteArray)   = b.copyOfRange(16, 20)
    fun tcpSrcPort(b: ByteArray, ihl: Int) = ((b[ihl].toInt() and 0xFF) shl 8) or (b[ihl+1].toInt() and 0xFF)
    fun tcpDstPort(b: ByteArray, ihl: Int) = ((b[ihl+2].toInt() and 0xFF) shl 8) or (b[ihl+3].toInt() and 0xFF)
    fun tcpFlags(b: ByteArray, ihl: Int)   = b[ihl+13].toInt() and 0xFF
    fun tcpSeq(b: ByteArray, ihl: Int): Long =
        ((b[ihl+4].toLong() and 0xFF) shl 24) or ((b[ihl+5].toLong() and 0xFF) shl 16) or
        ((b[ihl+6].toLong() and 0xFF) shl 8)  or  (b[ihl+7].toLong() and 0xFF)
    fun tcpPayload(b: ByteArray, ihl: Int): ByteArray {
        val off = ((b[ihl+12].toInt() ushr 4) and 0xF) * 4
        val len = totalLen(b) - ihl - off
        return if (len > 0) b.copyOfRange(ihl + off, ihl + off + len) else ByteArray(0)
    }
    fun totalLen(b: ByteArray) = ((b[2].toInt() and 0xFF) shl 8) or (b[3].toInt() and 0xFF)
    fun udpSrcPort(b: ByteArray, ihl: Int) = ((b[ihl].toInt() and 0xFF) shl 8) or (b[ihl+1].toInt() and 0xFF)
    fun udpDstPort(b: ByteArray, ihl: Int) = ((b[ihl+2].toInt() and 0xFF) shl 8) or (b[ihl+3].toInt() and 0xFF)
    fun udpPayload(b: ByteArray, ihl: Int): ByteArray {
        val len = ((b[ihl+4].toInt() and 0xFF) shl 8) or (b[ihl+5].toInt() and 0xFF)
        return if (len > 8) b.copyOfRange(ihl + 8, ihl + len) else ByteArray(0)
    }
    fun ipStr(b: ByteArray) = try { java.net.InetAddress.getByAddress(b).hostAddress ?: "?" } catch (_: Exception) { "?" }

    fun checksum(buf: ByteArray, off: Int = 0, len: Int = buf.size): Int {
        var s = 0L; var i = off
        while (i < off + len - 1) { s += ((buf[i].toInt() and 0xFF) shl 8) or (buf[i+1].toInt() and 0xFF); i += 2 }
        if (i < off + len) s += (buf[i].toInt() and 0xFF) shl 8
        while (s shr 16 != 0L) s = (s and 0xFFFF) + (s shr 16)
        return (s.inv() and 0xFFFF).toInt()
    }

    fun buildTcp(srcIp: ByteArray, dstIp: ByteArray, srcPort: Int, dstPort: Int,
                 seq: Long, ack: Long, flags: Int, payload: ByteArray = ByteArray(0)): ByteArray {
        val tcpLen = 20 + payload.size; val total = 20 + tcpLen
        val b = ByteArray(total)
        b[0] = 0x45.toByte(); b[2] = (total shr 8).toByte(); b[3] = total.toByte()
        b[4] = 0; b[5] = 1; b[6] = 0x40.toByte(); b[8] = 64; b[9] = 6
        srcIp.copyInto(b, 12); dstIp.copyInto(b, 16)
        val cs = checksum(b, 0, 20); b[10] = (cs shr 8).toByte(); b[11] = cs.toByte()
        b[20] = (srcPort shr 8).toByte(); b[21] = srcPort.toByte()
        b[22] = (dstPort shr 8).toByte(); b[23] = dstPort.toByte()
        b[24]=(seq shr 24).toByte();b[25]=(seq shr 16).toByte();b[26]=(seq shr 8).toByte();b[27]=seq.toByte()
        b[28]=(ack shr 24).toByte();b[29]=(ack shr 16).toByte();b[30]=(ack shr 8).toByte();b[31]=ack.toByte()
        b[32] = 0x50.toByte(); b[33] = flags.toByte()
        b[34] = 0xFF.toByte(); b[35] = 0xFF.toByte()
        payload.copyInto(b, 40)
        val pseudo = ByteArray(12 + tcpLen)
        srcIp.copyInto(pseudo, 0); dstIp.copyInto(pseudo, 4)
        pseudo[9] = 6; pseudo[10] = (tcpLen shr 8).toByte(); pseudo[11] = tcpLen.toByte()
        b.copyInto(pseudo, 12, 20, 20 + tcpLen)
        val tcs = checksum(pseudo); b[36] = (tcs shr 8).toByte(); b[37] = tcs.toByte()
        return b
    }

    fun buildUdp(srcIp: ByteArray, dstIp: ByteArray, srcPort: Int, dstPort: Int, payload: ByteArray): ByteArray {
        val udpLen = 8 + payload.size; val total = 20 + udpLen
        val b = ByteArray(total)
        b[0] = 0x45.toByte(); b[2] = (total shr 8).toByte(); b[3] = total.toByte()
        b[6] = 0x40.toByte(); b[8] = 64; b[9] = 17
        srcIp.copyInto(b, 12); dstIp.copyInto(b, 16)
        val cs = checksum(b, 0, 20); b[10] = (cs shr 8).toByte(); b[11] = cs.toByte()
        b[20]=(srcPort shr 8).toByte();b[21]=srcPort.toByte()
        b[22]=(dstPort shr 8).toByte();b[23]=dstPort.toByte()
        b[24]=(udpLen shr 8).toByte();b[25]=udpLen.toByte()
        payload.copyInto(b, 28)
        return b
    }
}
