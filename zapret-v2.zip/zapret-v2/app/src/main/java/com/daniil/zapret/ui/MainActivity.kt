package com.daniil.zapret.ui

import android.app.Activity
import android.content.*
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.daniil.zapret.R
import com.daniil.zapret.appfilter.AppFilterActivity
import com.daniil.zapret.core.*
import com.daniil.zapret.core.EXTRA_DOH
import com.daniil.zapret.databinding.ActivityMainBinding
import com.daniil.zapret.dpi.BypassMode
import com.daniil.zapret.whitelist.WhitelistActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.*
import java.net.HttpURLConnection
import java.net.URL

private const val VPN_REQ = 1001

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private val prefs by lazy { getSharedPreferences("settings", Context.MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private var tick: Runnable? = null
    private var guard = false
    private var testing = false

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, i: Intent?) { updateUi() }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        setSupportActionBar(b.toolbar)

        b.powerToggle.onToggled = { on ->
            if (!guard) {
                if (on) { val i = VpnService.prepare(this); if (i != null) { guard=true; b.powerToggle.setOn(false,false); guard=false; startActivityForResult(i, VPN_REQ) } else startVpn() }
                else stopVpn()
            }
        }
        b.cardProfile.setOnClickListener { pickProfile() }
        b.btnAutoDetect.setOnClickListener { autoDetect() }
        b.btnWhitelist.setOnClickListener { startActivity(Intent(this, WhitelistActivity::class.java)) }
        b.btnAppFilter.setOnClickListener { startActivity(Intent(this, AppFilterActivity::class.java)) }

        // DoH toggle
        b.switchDoh.isChecked = prefs.getBoolean("doh", true)
        b.switchDoh.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("doh", checked).apply()
            // Restart VPN if running to apply
            if (ZapretVpnService.isRunning) { stopVpn(); handler.postDelayed({ startVpn() }, 600) }
        }

        updateUi()
    }

    override fun onResume() {
        super.onResume()
        registerReceiver(statusReceiver, IntentFilter("com.daniil.zapret.STATUS"), RECEIVER_NOT_EXPORTED)
        updateUi(); startTick()
    }
    override fun onPause() { super.onPause(); unregisterReceiver(statusReceiver); stopTick() }

    @Deprecated("Deprecated")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == VPN_REQ && res == Activity.RESULT_OK) { startVpn(); guard=true; b.powerToggle.setOn(true,true); guard=false }
    }

    // ─── VPN ─────────────────────────────────────────────────────────────

    private fun startVpn() {
        val mode = currentMode()
        val appPrefs = getSharedPreferences("app_filter", Context.MODE_PRIVATE)
        val pkgMode  = appPrefs.getString("mode","all") ?: "all"
        val pkgs     = appPrefs.getStringSet("pkgs", emptySet()) ?: emptySet()
        val allowed  = if (pkgMode == "include") pkgs.joinToString(",") else ""
        val excluded = if (pkgMode == "exclude") pkgs.joinToString(",") else ""

        val doh = prefs.getBoolean("doh", true)
        prefs.edit().putString("mode", mode.id).apply()
        startForegroundService(Intent(this, ZapretVpnService::class.java).apply {
            action = ACTION_START
            putExtra(EXTRA_MODE, mode.id)
            putExtra(EXTRA_PKGS, allowed)
            putExtra(EXTRA_PKG_EXCLUDE, excluded)
            putExtra(EXTRA_DOH, doh)
        })
    }

    private fun stopVpn() {
        startService(Intent(this, ZapretVpnService::class.java).apply { action = ACTION_STOP })
    }

    private fun currentMode() = BypassMode.byId(prefs.getString("mode","split2") ?: "split2")

    // ─── Auto-detect ─────────────────────────────────────────────────────

    private fun autoDetect() {
        if (testing) return
        testing = true
        b.btnAutoDetect.isEnabled = false
        b.tvAutoStatus.visibility = View.VISIBLE
        b.tvAutoStatus.text = "Запускаю тест..."

        lifecycleScope.launch {
            val sb = StringBuilder()
            var best: BypassMode? = null

            for (mode in BypassMode.entries.filter { it != BypassMode.NONE }) {
                b.tvAutoStatus.text = "Тестирую: ${mode.title}..."

                // Switch to this mode and restart VPN
                prefs.edit().putString("mode", mode.id).apply()
                if (ZapretVpnService.isRunning) { stopVpn(); delay(700) }
                startVpn(); delay(1800)

                val ping = testConnection()
                val line = if (ping >= 0) "✓ ${mode.title}: ${ping}ms\n" else "✗ ${mode.title}: нет связи\n"
                sb.append(line)
                b.tvAutoStatus.text = sb.toString().trimEnd()

                if (ping >= 0 && best == null) best = mode
            }

            if (best != null) {
                prefs.edit().putString("mode", best.id).apply()
                if (!ZapretVpnService.isRunning) { startVpn() }
                else { stopVpn(); delay(500); startVpn() }
                sb.append("\n→ Выбран: ${best.title}")
            } else {
                sb.append("\n✗ Ни один профиль не работает")
                stopVpn()
            }

            b.tvAutoStatus.text = sb.toString().trimEnd()
            testing = false
            b.btnAutoDetect.isEnabled = true
            updateUi()
        }
    }

    private suspend fun testConnection(): Long = withContext(Dispatchers.IO) {
        val start = System.currentTimeMillis()
        try {
            val conn = URL("https://www.youtube.com/generate_204").openConnection() as HttpURLConnection
            conn.connectTimeout = 6000; conn.readTimeout = 6000
            conn.instanceFollowRedirects = false
            val code = conn.responseCode
            conn.disconnect()
            if (code in 200..399) System.currentTimeMillis() - start else -1L
        } catch (_: Exception) { -1L }
    }

    // ─── Profile picker ──────────────────────────────────────────────────

    private fun pickProfile() {
        if (testing) return
        val modes = BypassMode.entries
        val cur = modes.indexOfFirst { it.id == (prefs.getString("mode","split2") ?: "split2") }
        MaterialAlertDialogBuilder(this)
            .setTitle("Режим обхода DPI")
            .setSingleChoiceItems(modes.map { "${it.title}\n${it.desc}" }.toTypedArray(), cur) { d, i ->
                prefs.edit().putString("mode", modes[i].id).apply()
                if (ZapretVpnService.isRunning) { stopVpn(); handler.postDelayed({ startVpn() }, 600) }
                updateUi(); d.dismiss()
            }.show()
    }

    // ─── UI ──────────────────────────────────────────────────────────────

    private fun updateUi() {
        val on = ZapretVpnService.isRunning
        val mode = currentMode()

        b.statusDot.setBackgroundResource(if (on) R.drawable.dot_green else R.drawable.dot_red)
        b.tvStatus.text    = if (on) "АКТИВЕН" else "ОТКЛЮЧЁН"
        b.tvStatusSub.text = if (on) "Обход DPI работает (TCP + UDP)" else "Нажми для запуска"
        b.tvToggleLabel.text = if (on) "АКТИВНО" else "ЗАПУСТИТЬ"

        // Uptime tag — set when VPN activates
        if (on && b.tvUptime.tag == null) b.tvUptime.tag = System.currentTimeMillis()
        if (!on) { b.tvUptime.tag = null; b.tvUptime.text = "Аптайм: --:--:--" }

        guard = true; b.powerToggle.setOn(on, true); guard = false

        b.tvProfileName.text = mode.title
        b.tvProfileDesc.text = mode.desc
        b.tvProfileMode.text = "Режим: ${mode.id.uppercase()}  |  split: ${mode.splitPos}"

        b.btnAutoDetect.isEnabled = !testing
        if (!testing) { b.tvAutoStatus.visibility = View.GONE }
    }

    private fun startTick() {
        tick = object : Runnable {
            override fun run() {
                if (ZapretVpnService.isRunning) {
                    val s = (System.currentTimeMillis() - (b.tvUptime.tag as? Long ?: System.currentTimeMillis())) / 1000
                    b.tvUptime.text = "Аптайм: %02d:%02d:%02d".format(s/3600,(s%3600)/60,s%60)
                }
                handler.postDelayed(this, 1000)
            }
        }.also { handler.postDelayed(it, 0) }
        if (ZapretVpnService.isRunning && b.tvUptime.tag == null) b.tvUptime.tag = System.currentTimeMillis()
        if (!ZapretVpnService.isRunning) { b.tvUptime.tag = null; b.tvUptime.text = "Аптайм: --:--:--" }
    }
    private fun stopTick() { tick?.let { handler.removeCallbacks(it) }; tick = null }

    override fun onCreateOptionsMenu(m: Menu): Boolean { menuInflater.inflate(R.menu.main_menu, m); return true }
    override fun onOptionsItemSelected(item: MenuItem) = when(item.itemId) {
        R.id.menu_whitelist -> { startActivity(Intent(this, WhitelistActivity::class.java)); true }
        R.id.menu_about -> {
            MaterialAlertDialogBuilder(this).setTitle("Zapret v2")
                .setMessage("DPI-обход через локальный TUN.\n\nТрафик не уходит на сторонние серверы.\n\n✓ TCP 80/443 — с обходом DPI\n✓ UDP — прозрачный форвардинг (Discord voice, QUIC)")
                .setPositiveButton("OK",null).show(); true
        }
        else -> super.onOptionsItemSelected(item)
    }
}
