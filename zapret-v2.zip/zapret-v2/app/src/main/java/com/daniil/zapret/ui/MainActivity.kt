package com.daniil.zapret.ui

import android.app.Activity
import android.content.*
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.daniil.zapret.R
import com.daniil.zapret.appfilter.AppFilterActivity
import com.daniil.zapret.core.*
import com.daniil.zapret.databinding.ActivityMainBinding
import com.daniil.zapret.dpi.BypassMode
import com.daniil.zapret.whitelist.WhitelistActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.*
import java.net.HttpURLConnection
import java.net.URL

private const val VPN_REQ = 1001

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private val prefs by lazy { getSharedPreferences("settings", Context.MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private var tick: Runnable? = null
    private var testing = false

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, i: Intent?) { syncUi() }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        setSupportActionBar(b.toolbar)

        // Toggle: fires on click, we check current state and act
        b.powerToggle.onClicked = {
            if (ZapretVpnService.isRunning) {
                stopVpn()
            } else {
                val perm = VpnService.prepare(this)
                if (perm != null) startActivityForResult(perm, VPN_REQ)
                else startVpn()
            }
        }

        b.cardProfile.setOnClickListener { pickProfile() }
        b.btnAutoDetect.setOnClickListener { autoDetect() }
        b.btnWhitelist.setOnClickListener { startActivity(Intent(this, WhitelistActivity::class.java)) }
        b.btnAppFilter.setOnClickListener { startActivity(Intent(this, AppFilterActivity::class.java)) }

        b.btnDohSetup.setOnClickListener { showDohDialog() }

        syncUi()
    }

    override fun onResume() {
        super.onResume()
        registerReceiver(statusReceiver, IntentFilter("com.daniil.zapret.STATUS"), RECEIVER_NOT_EXPORTED)
        syncUi()
        startTick()
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(statusReceiver)
        stopTick()
    }

    @Deprecated("Deprecated")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == VPN_REQ && res == Activity.RESULT_OK) startVpn()
    }

    // ─── VPN ─────────────────────────────────────────────────────────────

    private fun startVpn() {
        val mode = currentMode()
        val ap = getSharedPreferences("app_filter", Context.MODE_PRIVATE)
        val pkgMode = ap.getString("mode","all") ?: "all"
        val pkgs    = ap.getStringSet("pkgs", emptySet()) ?: emptySet()
        startForegroundService(Intent(this, ZapretVpnService::class.java).apply {
            action = ACTION_START
            putExtra(EXTRA_MODE, mode.id)
            putExtra(EXTRA_PKGS,  if (pkgMode == "include") pkgs.joinToString(",") else "")
            putExtra(EXTRA_PKG_EXCLUDE, if (pkgMode == "exclude") pkgs.joinToString(",") else "")
        })
    }

    private fun stopVpn() {
        startService(Intent(this, ZapretVpnService::class.java).apply { action = ACTION_STOP })
    }

    private fun currentMode() = BypassMode.byId(prefs.getString("mode","split2") ?: "split2")

    // ─── Profile picker — works while running ────────────────────────────

    private fun pickProfile() {
        if (testing) return
        val modes = BypassMode.entries
        val cur = modes.indexOfFirst { it.id == currentMode().id }
        MaterialAlertDialogBuilder(this)
            .setTitle("Режим обхода DPI")
            .setSingleChoiceItems(modes.map { "${it.title}\n${it.desc}" }.toTypedArray(), cur) { d, i ->
                val newMode = modes[i]
                prefs.edit().putString("mode", newMode.id).apply()
                if (ZapretVpnService.isRunning) {
                    // Seamless switch: stop → start with new mode
                    stopVpn()
                    handler.postDelayed({ startVpn() }, 600)
                }
                syncUi()
                d.dismiss()
            }.show()
    }

    // ─── Auto-detect ─────────────────────────────────────────────────────

    private fun autoDetect() {
        if (testing) return
        testing = true
        b.btnAutoDetect.isEnabled = false
        b.tvAutoStatus.visibility = View.VISIBLE
        b.tvAutoStatus.text = "Запускаю тест..."

        lifecycleScope.launch {
            val sb = StringBuilder()
            var best: BypassMode? = null

            for (mode in BypassMode.entries.filter { it != BypassMode.NONE }) {
                b.tvAutoStatus.text = sb.toString() + "Тестирую: ${mode.title}..."
                prefs.edit().putString("mode", mode.id).apply()
                if (ZapretVpnService.isRunning) { stopVpn(); delay(800) }
                startVpn(); delay(2000)

                val ping = testPing()
                sb.append(if (ping >= 0) "✓ ${mode.title}: ${ping}ms\n" else "✗ ${mode.title}: нет связи\n")
                b.tvAutoStatus.text = sb.toString().trimEnd()
                if (ping >= 0 && best == null) best = mode
            }

            if (best != null) {
                prefs.edit().putString("mode", best.id).apply()
                stopVpn(); delay(600); startVpn()
                sb.append("\n→ Выбран: ${best.title}")
            } else {
                sb.append("\n✗ Ни один не работает")
                stopVpn()
            }
            b.tvAutoStatus.text = sb.toString().trimEnd()
            testing = false
            b.btnAutoDetect.isEnabled = true
            syncUi()
        }
    }

    private suspend fun testPing(): Long = withContext(Dispatchers.IO) {
        val t = System.currentTimeMillis()
        try {
            val conn = URL("https://www.youtube.com/generate_204").openConnection() as HttpURLConnection
            conn.connectTimeout = 6000; conn.readTimeout = 6000
            conn.instanceFollowRedirects = false
            val code = conn.responseCode; conn.disconnect()
            if (code in 200..399) System.currentTimeMillis() - t else -1L
        } catch (_: Exception) { -1L }
    }

    // ─── UI sync ─────────────────────────────────────────────────────────

    /** Single source of truth for all UI state */
    private fun syncUi() {
        val on = ZapretVpnService.isRunning
        val mode = currentMode()

        // Toggle — set visual only, no callback triggered
        b.powerToggle.setOn(on, animate = true)
        b.tvToggleLabel.text = if (on) "АКТИВНО" else "ЗАПУСТИТЬ"

        // Status
        b.statusDot.setBackgroundResource(if (on) R.drawable.dot_green else R.drawable.dot_red)
        b.tvStatus.text    = if (on) "АКТИВЕН" else "ОТКЛЮЧЁН"
        b.tvStatusSub.text = if (on) "TCP обход + UDP + DoH" else "Нажми ползунок для запуска"

        // Profile
        b.tvProfileName.text = mode.title
        b.tvProfileDesc.text = mode.desc
        b.tvProfileMode.text = "id: ${mode.id}  •  split: ${mode.splitPos}b"

        // Uptime — reset tag on state change
        if (on && b.tvUptime.tag == null) {
            // Use service start time if available
            val svcStart = ZapretVpnService.startMs
            b.tvUptime.tag = if (svcStart > 0) svcStart else System.currentTimeMillis()
        }
        if (!on) { b.tvUptime.tag = null; b.tvUptime.text = "Аптайм: --:--:--" }

        b.btnAutoDetect.isEnabled = !testing
        if (!testing && b.tvAutoStatus.visibility == View.VISIBLE) {
            // Keep result visible but hide after profile pick
        }
    }

    // ─── Uptime tick ─────────────────────────────────────────────────────

    private fun startTick() {
        tick = object : Runnable {
            override fun run() {
                if (ZapretVpnService.isRunning) {
                    val startTag = b.tvUptime.tag as? Long
                    if (startTag != null) {
                        val s = (System.currentTimeMillis() - startTag) / 1000
                        b.tvUptime.text = "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
                    }
                }
                handler.postDelayed(this, 1000)
            }
        }.also { handler.postDelayed(it, 0) }
    }

    private fun stopTick() { tick?.let { handler.removeCallbacks(it) }; tick = null }

    // ─── DoH setup dialog ─────────────────────────────────────────────────

    private fun showDohDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle("DNS over HTTPS")
            .setMessage(
                "Android поддерживает DoH нативно через «Частный DNS».

" +
                "Как настроить:
" +
                "1. Настройки → Сеть и интернет → Частный DNS
" +
                "2. Выбери «Имя хоста частного DNS-провайдера»
" +
                "3. Введи: 1dot1dot1dot1.cloudflare-dns.com
   или: dns.google

" +
                "После этого все DNS-запросы будут зашифрованы " +
                "и провайдер не сможет их подменить."
            )
            .setPositiveButton("Понятно", null)
            .setNeutralButton("Открыть настройки") { _, _ ->
                try {
                    startActivity(android.content.Intent(
                        android.provider.Settings.ACTION_WIRELESS_SETTINGS))
                } catch (_: Exception) {}
            }
            .show()
    }

    // ─── Menu ─────────────────────────────────────────────────────────────

    override fun onCreateOptionsMenu(m: Menu): Boolean { menuInflater.inflate(R.menu.main_menu, m); return true }

    override fun onOptionsItemSelected(item: MenuItem) = when (item.itemId) {
        R.id.menu_whitelist -> { startActivity(Intent(this, WhitelistActivity::class.java)); true }
        R.id.menu_about -> {
            MaterialAlertDialogBuilder(this).setTitle("Zapret v2")
                .setMessage(
                    "Обход DPI-блокировок.\n\n" +
                    "• TCP 80/443 — фрагментация TLS ClientHello\n" +
                    "• UDP — прозрачный форвардинг (Discord, QUIC)\n" +
                    "• DNS over HTTPS — обход DNS-блокировок\n\n" +
                    "Трафик не уходит на сторонние серверы."
                )
                .setPositiveButton("OK", null).show()
            true
        }
        else -> super.onOptionsItemSelected(item)
    }
}
