package com.daniil.zapret.core

import android.net.VpnService
import android.util.Log
import com.daniil.zapret.dpi.BypassMode
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

private const val TAG = "Socks5"

/**
 * Local SOCKS5 proxy server.
 * tun2socks connects here for every TCP connection.
 * We connect to the real server (with VPN protect) and apply DPI bypass on first packet.
 */
class DpiSocks5Server(
    private val vpn: VpnService,
    private val bypass: BypassMode,
    val port: Int = 2080
) {
    private var serverSocket: ServerSocket? = null
    private val running = AtomicBoolean(false)
    private val executor: ExecutorService = Executors.newCachedThreadPool()

    fun start() {
        running.set(true)
        serverSocket = ServerSocket(port, 128, InetAddress.getLoopbackAddress())
        Thread({
            Log.i(TAG, "SOCKS5 proxy listening on port $port")
            while (running.get()) {
                try {
                    val client = serverSocket!!.accept()
                    executor.execute { handleClient(client) }
                } catch (e: Exception) {
                    if (running.get()) Log.w(TAG, "accept: ${e.message}")
                }
            }
        }, "socks5-accept").also { it.isDaemon = true; it.start() }
    }

    fun stop() {
        running.set(false)
        try { serverSocket?.close() } catch (_: Exception) {}
        executor.shutdownNow()
    }

    // ─── Handle one SOCKS5 client ────────────────────────────────────────

    private fun handleClient(client: Socket) {
        client.tcpNoDelay = true
        client.soTimeout  = 10_000
        try {
            val inp = client.getInputStream()
            val out = client.getOutputStream()

            // ── SOCKS5 handshake ──────────────────────────────────────────
            val version = inp.read()
            if (version != 5) { client.close(); return }

            val nMethods = inp.read()
            val methods  = ByteArray(nMethods)
            inp.readFully(methods)
            // Reply: no auth required
            out.write(byteArrayOf(5, 0))
            out.flush()

            // ── SOCKS5 CONNECT request ────────────────────────────────────
            val req = ByteArray(4)
            inp.readFully(req)
            if (req[0].toInt() != 5 || req[1].toInt() != 1) {
                // Only CONNECT supported
                out.write(byteArrayOf(5, 7, 0, 1, 0, 0, 0, 0, 0, 0))
                client.close(); return
            }

            val (dstHost, dstPort) = when (req[3].toInt()) {
                1 -> {  // IPv4
                    val addr = ByteArray(4); inp.readFully(addr)
                    val port = readPort(inp)
                    InetAddress.getByAddress(addr).hostAddress!! to port
                }
                3 -> {  // Domain
                    val len    = inp.read()
                    val domain = ByteArray(len); inp.readFully(domain)
                    val port   = readPort(inp)
                    String(domain) to port
                }
                4 -> {  // IPv6
                    val addr = ByteArray(16); inp.readFully(addr)
                    val port = readPort(inp)
                    InetAddress.getByAddress(addr).hostAddress!! to port
                }
                else -> {
                    out.write(byteArrayOf(5, 8, 0, 1, 0, 0, 0, 0, 0, 0))
                    client.close(); return
                }
            }

            // ── Connect to real server ────────────────────────────────────
            val server = Socket()
            vpn.protect(server)
            try {
                server.connect(InetSocketAddress(dstHost, dstPort), 8_000)
                server.tcpNoDelay = true
                server.soTimeout  = 0
            } catch (e: Exception) {
                Log.d(TAG, "connect $dstHost:$dstPort failed: ${e.message}")
                out.write(byteArrayOf(5, 4, 0, 1, 0, 0, 0, 0, 0, 0))
                out.flush()
                client.close(); return
            }

            // ── Reply success ─────────────────────────────────────────────
            out.write(byteArrayOf(5, 0, 0, 1, 0, 0, 0, 0, 0, 0))
            out.flush()
            client.soTimeout = 0

            // ── Bidirectional relay with DPI bypass ───────────────────────
            val serverOut = server.getOutputStream()
            val serverInp = server.getInputStream()
            val isTls = dstPort == 443

            // Client→Server thread (applies DPI on first packet)
            val c2s = Thread({
                try {
                    val buf = ByteArray(16384)
                    var first = true
                    while (true) {
                        val n = inp.read(buf)
                        if (n == -1) break
                        val data = buf.copyOf(n)
                        if (first && isTls && bypass != BypassMode.NONE && n > bypass.splitPos + 1) {
                            doBypass(serverOut, data)
                        } else {
                            serverOut.write(data); serverOut.flush()
                        }
                        first = false
                    }
                } catch (_: Exception) {}
                finally { try { server.shutdownOutput() } catch (_: Exception) {} }
            }, "c2s-$dstPort").also { it.isDaemon = true; it.start() }

            // Server→Client (this thread)
            try {
                val buf = ByteArray(16384)
                while (true) {
                    val n = serverInp.read(buf)
                    if (n == -1) break
                    out.write(buf, 0, n); out.flush()
                }
            } catch (_: Exception) {}
            finally {
                c2s.interrupt()
                try { client.close() } catch (_: Exception) {}
                try { server.close() } catch (_: Exception) {}
            }

        } catch (e: Exception) {
            Log.d(TAG, "client error: ${e.message}")
        } finally {
            try { client.close() } catch (_: Exception) {}
        }
    }

    // ─── DPI bypass ──────────────────────────────────────────────────────

    private fun doBypass(out: OutputStream, data: ByteArray) {
        val pos = bypass.splitPos.coerceIn(1, data.size - 1)
        when (bypass) {
            BypassMode.SPLIT_2, BypassMode.SPLIT_1, BypassMode.SPLIT_40 -> {
                out.write(data, 0, pos);               out.flush()
                Thread.sleep(1)
                out.write(data, pos, data.size - pos); out.flush()
            }
            BypassMode.FAKE -> {
                val fake = data.copyOf()
                for (i in pos until minOf(pos + 16, fake.size))
                    fake[i] = (fake[i].toInt() xor 0xFF).toByte()
                out.write(fake, 0, pos); out.flush()
                Thread.sleep(1)
                out.write(data); out.flush()
            }
            BypassMode.DISORDER -> {
                out.write(data, pos, data.size - pos); out.flush()
                Thread.sleep(1)
                out.write(data, 0, pos); out.flush()
            }
            BypassMode.NONE -> { out.write(data); out.flush() }
        }
    }

    private fun readPort(inp: InputStream): Int {
        val b = ByteArray(2); inp.readFully(b)
        return ((b[0].toInt() and 0xFF) shl 8) or (b[1].toInt() and 0xFF)
    }
}

private fun InputStream.readFully(buf: ByteArray) {
    var off = 0
    while (off < buf.size) {
        val n = read(buf, off, buf.size - off)
        if (n == -1) throw java.io.EOFException()
        off += n
    }
}
