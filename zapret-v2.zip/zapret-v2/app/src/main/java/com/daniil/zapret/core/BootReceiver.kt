package com.daniil.zapret.core

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
        if (prefs.getBoolean("autostart", false)) {
            val mode = prefs.getString("mode", "split2") ?: "split2"
            ctx.startForegroundService(Intent(ctx, ZapretVpnService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_MODE, mode)
            })
        }
    }
}
