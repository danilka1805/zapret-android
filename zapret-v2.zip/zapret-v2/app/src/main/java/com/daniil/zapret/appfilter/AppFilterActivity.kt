package com.daniil.zapret.appfilter

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.*
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.*
import com.daniil.zapret.R
import com.daniil.zapret.databinding.ActivityAppFilterBinding
import kotlinx.coroutines.*

class AppFilterActivity : AppCompatActivity() {
    private lateinit var b: ActivityAppFilterBinding
    private val prefs by lazy { getSharedPreferences("app_filter", Context.MODE_PRIVATE) }
    private lateinit var adapter: AppAdapter
    private var allApps = listOf<AppEntry>()

    data class AppEntry(val pkg: String, val label: String, var selected: Boolean)

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityAppFilterBinding.inflate(layoutInflater)
        setContentView(b.root)
        setSupportActionBar(b.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Фильтр приложений"

        val mode = prefs.getString("mode","all") ?: "all"
        val selected = prefs.getStringSet("pkgs", emptySet()) ?: emptySet()

        adapter = AppAdapter(packageManager) { pkg, checked ->
            val cur = (prefs.getStringSet("pkgs", emptySet()) ?: emptySet()).toMutableSet()
            if (checked) cur.add(pkg) else cur.remove(pkg)
            prefs.edit().putStringSet("pkgs", cur).apply()
        }

        b.recyclerApps.layoutManager = LinearLayoutManager(this)
        b.recyclerApps.adapter = adapter

        updateMode(mode)
        b.chipAll.setOnClickListener     { saveMode("all");     updateMode("all") }
        b.chipInclude.setOnClickListener { saveMode("include"); updateMode("include") }
        b.chipExclude.setOnClickListener { saveMode("exclude"); updateMode("exclude") }

        b.etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = filter(s?.toString() ?: "")
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })

        b.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            allApps = withContext(Dispatchers.IO) { loadApps(selected) }
            b.progressBar.visibility = View.GONE
            filter("")
        }
    }

    private fun loadApps(selected: Set<String>): List<AppEntry> {
        val pm = packageManager
        return pm.getInstalledApplications(0)
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
            .mapNotNull { app ->
                try { AppEntry(app.packageName, pm.getApplicationLabel(app).toString(), app.packageName in selected) }
                catch (_: Exception) { null }
            }
            .sortedWith(compareBy({ !it.selected }, { it.label.lowercase() }))
    }

    private fun filter(q: String) {
        val list = if (q.isBlank()) allApps
        else allApps.filter { it.label.contains(q,true) || it.pkg.contains(q,true) }
        adapter.submit(list)
    }

    private fun saveMode(m: String) = prefs.edit().putString("mode", m).apply()
    private fun updateMode(m: String) {
        b.chipAll.isSelected     = m == "all"
        b.chipInclude.isSelected = m == "include"
        b.chipExclude.isSelected = m == "exclude"
        b.tvModeHint.text = when(m) {
            "include" -> "Только выбранные приложения будут обходить DPI"
            "exclude" -> "Выбранные приложения НЕ будут обходить DPI"
            else      -> "Все приложения обходят DPI"
        }
        b.appListGroup.visibility = if (m == "all") View.GONE else View.VISIBLE
    }

    override fun onSupportNavigateUp(): Boolean { onBackPressedDispatcher.onBackPressed(); return true }
}

class AppAdapter(private val pm: PackageManager, private val onToggle: (String, Boolean)->Unit)
    : RecyclerView.Adapter<AppAdapter.VH>() {
    private var items = listOf<AppFilterActivity.AppEntry>()
    private val icons = HashMap<String, Drawable>()

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.ivAppIcon)
        val label: TextView = v.findViewById(R.id.tvAppLabel)
        val pkg: TextView   = v.findViewById(R.id.tvPackageName)
        val check: CheckBox = v.findViewById(R.id.checkApp)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) = VH(
        LayoutInflater.from(p.context).inflate(R.layout.item_app, p, false))

    override fun onBindViewHolder(h: VH, i: Int) {
        val app = items[i]
        h.label.text = app.label; h.pkg.text = app.pkg
        h.check.isChecked = app.selected
        h.icon.setImageDrawable(icons.getOrPut(app.pkg) {
            try { pm.getApplicationIcon(app.pkg) } catch (_: Exception) { pm.defaultActivityIcon }
        })
        h.itemView.setOnClickListener { app.selected = !app.selected; h.check.isChecked = app.selected; onToggle(app.pkg, app.selected) }
        h.check.setOnClickListener   { app.selected = h.check.isChecked; onToggle(app.pkg, app.selected) }
    }

    override fun getItemCount() = items.size
    fun submit(list: List<AppFilterActivity.AppEntry>) { items = list; notifyDataSetChanged() }
}
