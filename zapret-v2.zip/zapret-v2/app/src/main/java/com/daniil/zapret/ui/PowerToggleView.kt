package com.daniil.zapret.ui

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.abs

/**
 * Simple power toggle:
 * - Visual state is set ONLY from outside via setOn()
 * - onClicked fires when user taps — caller decides what to do
 * - No internal state toggle to prevent race conditions
 */
class PowerToggleView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    /** Called when user taps the toggle. No argument — caller reads current state and acts. */
    var onClicked: (() -> Unit)? = null

    private var visualOn = false
    private var animProgress = 0f

    private val trackW  = dp(80f); private val trackH = dp(40f)
    private val thumbR  = dp(16f); private val thumbP = dp(4f)

    private val trackLeft   get() = (width  - trackW) / 2f
    private val trackTop    get() = (height - trackH) / 2f
    private val trackRight  get() = trackLeft + trackW
    private val trackBottom get() = trackTop + trackH
    private val trackRect   get() = RectF(trackLeft, trackTop, trackRight, trackBottom)
    private val thumbXOff   get() = trackLeft + thumbP + thumbR
    private val thumbXOn    get() = trackRight - thumbP - thumbR
    private val thumbY      get() = trackTop + trackH / 2f

    private var thumbX = 0f

    private val colorOff = Color.parseColor("#242836")
    private val colorOn  = Color.parseColor("#16A34A")
    private var trackColor = colorOff
    private var glowAlpha = 0

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.FILL
        setShadowLayer(dp(6f), 0f, dp(2f), Color.argb(80, 0, 0, 0))
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        maskFilter = BlurMaskFilter(dp(10f), BlurMaskFilter.Blur.NORMAL)
    }
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeWidth = dp(2f)
    }

    private var touchDownX = 0f; private var dragging = false

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    // ─── Public API ──────────────────────────────────────────────────────

    fun setOn(on: Boolean, animate: Boolean = true) {
        if (visualOn == on && (animProgress == (if (on) 1f else 0f))) return
        visualOn = on
        if (animate) {
            ValueAnimator.ofFloat(animProgress, if (on) 1f else 0f).apply {
                duration = 260; interpolator = DecelerateInterpolator(1.4f)
                addUpdateListener { v ->
                    animProgress = v.animatedValue as Float
                    thumbX = thumbXOff + (thumbXOn - thumbXOff) * animProgress
                    trackColor = ArgbEvaluator().evaluate(animProgress, colorOff, colorOn) as Int
                    glowAlpha = (animProgress * 150).toInt()
                    invalidate()
                }
                start()
            }
        } else {
            animProgress = if (on) 1f else 0f
            trackColor = if (on) colorOn else colorOff
            glowAlpha = if (on) 150 else 0
            invalidate()
        }
    }

    // ─── Touch ───────────────────────────────────────────────────────────

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> { touchDownX = event.x; dragging = false }
            MotionEvent.ACTION_MOVE -> { if (abs(event.x - touchDownX) > dp(6f)) dragging = true }
            MotionEvent.ACTION_UP -> {
                if (!dragging) { onClicked?.invoke(); performClick() }
            }
        }
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }

    // ─── Draw ─────────────────────────────────────────────────────────────

    override fun onDraw(canvas: Canvas) {
        if (thumbX == 0f) thumbX = if (visualOn) thumbXOn else thumbXOff

        // Glow
        if (glowAlpha > 0) {
            glowPaint.color = Color.argb(glowAlpha / 4, 34, 197, 94)
            canvas.drawRoundRect(
                RectF(trackLeft - dp(5f), trackTop - dp(5f), trackRight + dp(5f), trackBottom + dp(5f)),
                dp(25f), dp(25f), glowPaint
            )
        }

        // Track
        trackPaint.color = trackColor
        canvas.drawRoundRect(trackRect, trackH / 2f, trackH / 2f, trackPaint)

        // Track border
        trackPaint.apply { color = Color.argb(40, 255, 255, 255); style = Paint.Style.STROKE; strokeWidth = dp(1f) }
        canvas.drawRoundRect(trackRect, trackH / 2f, trackH / 2f, trackPaint)
        trackPaint.style = Paint.Style.FILL

        // Thumb glow
        if (animProgress > 0.05f) {
            glowPaint.color = Color.argb((animProgress * 70).toInt(), 34, 197, 94)
            canvas.drawCircle(thumbX, thumbY, thumbR + dp(3f), glowPaint)
        }

        // Thumb
        canvas.drawCircle(thumbX, thumbY, thumbR, thumbPaint)

        // Power icon
        val cx = thumbX; val cy = thumbY; val r = thumbR * 0.44f
        val iconColor = ArgbEvaluator().evaluate(
            animProgress, Color.argb(100, 120, 120, 120), Color.parseColor("#16A34A")
        ) as Int
        iconPaint.color = iconColor
        canvas.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), -220f, 260f, false, iconPaint)
        canvas.drawLine(cx, cy - r - dp(1.5f), cx, cy - r * 0.25f, iconPaint)
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(
            resolveSize((trackW + dp(24f)).toInt(), w),
            resolveSize((trackH + dp(24f)).toInt(), h)
        )
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density
}
