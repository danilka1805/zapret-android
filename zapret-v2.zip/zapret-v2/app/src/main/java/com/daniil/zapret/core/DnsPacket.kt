package com.daniil.zapret.core

/**
 * Minimal DNS wire-format parser and response builder.
 * Only handles A (type 1) queries — enough for IPv4 resolution.
 */
object DnsPacket {

    data class Query(
        val txId: Int,
        val domain: String,
        val qtype: Int,      // 1 = A, 28 = AAAA
        val qclass: Int
    )

    /** Parse a DNS query from raw UDP payload. Returns null if not a standard query. */
    fun parseQuery(data: ByteArray): Query? {
        if (data.size < 12) return null
        val flags = ((data[2].toInt() and 0xFF) shl 8) or (data[3].toInt() and 0xFF)
        val qr    = (flags ushr 15) and 1
        if (qr != 0) return null           // not a query
        val qdcount = ((data[4].toInt() and 0xFF) shl 8) or (data[5].toInt() and 0xFF)
        if (qdcount < 1) return null

        val txId = ((data[0].toInt() and 0xFF) shl 8) or (data[1].toInt() and 0xFF)

        // Parse QNAME starting at offset 12
        val sb = StringBuilder()
        var pos = 12
        while (pos < data.size) {
            val len = data[pos].toInt() and 0xFF
            if (len == 0) { pos++; break }
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(data, pos + 1, len, Charsets.US_ASCII))
            pos += 1 + len
        }
        if (pos + 4 > data.size) return null

        val qtype  = ((data[pos].toInt() and 0xFF) shl 8) or (data[pos+1].toInt() and 0xFF)
        val qclass = ((data[pos+2].toInt() and 0xFF) shl 8) or (data[pos+3].toInt() and 0xFF)

        return Query(txId, sb.toString(), qtype, qclass)
    }

    /**
     * Build a DNS A-record response.
     * ips: list of IPv4 addresses as strings ("1.2.3.4")
     * Returns raw DNS response bytes.
     */
    fun buildResponse(query: Query, ips: List<String>, ttl: Int = 60): ByteArray {
        val buf = mutableListOf<Byte>()

        // Header
        buf.add((query.txId ushr 8).toByte()); buf.add(query.txId.toByte())
        // Flags: QR=1 AA=1 RD=1 RA=1 RCODE=0
        buf.add(0x81.toByte()); buf.add(0x80.toByte())
        buf.add(0x00); buf.add(0x01)                             // QDCOUNT = 1
        buf.add((ips.size ushr 8).toByte()); buf.add(ips.size.toByte())  // ANCOUNT
        buf.add(0x00); buf.add(0x00)                             // NSCOUNT
        buf.add(0x00); buf.add(0x00)                             // ARCOUNT

        // Question section — re-encode the domain name
        for (label in query.domain.split('.')) {
            if (label.isEmpty()) continue
            buf.add(label.length.toByte())
            label.toByteArray(Charsets.US_ASCII).forEach { buf.add(it) }
        }
        buf.add(0x00)  // root label
        buf.add((query.qtype ushr 8).toByte()); buf.add(query.qtype.toByte())
        buf.add((query.qclass ushr 8).toByte()); buf.add(query.qclass.toByte())

        // Answer section
        for (ip in ips) {
            // Name: pointer back to offset 12 (0xC0 0x0C)
            buf.add(0xC0.toByte()); buf.add(0x0C.toByte())
            // Type A = 0x0001
            buf.add(0x00); buf.add(0x01)
            // Class IN = 0x0001
            buf.add(0x00); buf.add(0x01)
            // TTL
            buf.add((ttl ushr 24).toByte()); buf.add((ttl ushr 16).toByte())
            buf.add((ttl ushr 8).toByte());  buf.add(ttl.toByte())
            // RDLENGTH = 4
            buf.add(0x00); buf.add(0x04)
            // RDATA = IPv4 address
            ip.split('.').forEach { buf.add(it.toInt().toByte()) }
        }

        return buf.toByteArray()
    }

    /**
     * Build an NXDOMAIN response (domain not found).
     */
    fun buildNxDomain(query: Query): ByteArray {
        val buf = mutableListOf<Byte>()
        buf.add((query.txId ushr 8).toByte()); buf.add(query.txId.toByte())
        buf.add(0x81.toByte()); buf.add(0x83.toByte())  // RCODE=3 NXDOMAIN
        buf.add(0x00); buf.add(0x01)
        buf.add(0x00); buf.add(0x00)
        buf.add(0x00); buf.add(0x00)
        buf.add(0x00); buf.add(0x00)
        for (label in query.domain.split('.')) {
            if (label.isEmpty()) continue
            buf.add(label.length.toByte())
            label.toByteArray(Charsets.US_ASCII).forEach { buf.add(it) }
        }
        buf.add(0x00)
        buf.add((query.qtype ushr 8).toByte()); buf.add(query.qtype.toByte())
        buf.add((query.qclass ushr 8).toByte()); buf.add(query.qclass.toByte())
        return buf.toByteArray()
    }
}
