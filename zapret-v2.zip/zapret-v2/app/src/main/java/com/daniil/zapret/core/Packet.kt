package com.daniil.zapret.core

import java.net.InetAddress

object Packet {
    // IP
    fun version(b: ByteArray) = (b[0].toInt() ushr 4) and 0xF
    fun ihl(b: ByteArray)     = (b[0].toInt() and 0xF) * 4
    fun proto(b: ByteArray)   = b[9].toInt() and 0xFF
    fun totalLen(b: ByteArray)= ((b[2].toInt() and 0xFF) shl 8) or (b[3].toInt() and 0xFF)
    fun srcIp(b: ByteArray)   = b.copyOfRange(12, 16)
    fun dstIp(b: ByteArray)   = b.copyOfRange(16, 20)

    // TCP
    fun tcpSrcPort(b: ByteArray, ihl: Int) = ((b[ihl].toInt() and 0xFF) shl 8) or (b[ihl+1].toInt() and 0xFF)
    fun tcpDstPort(b: ByteArray, ihl: Int) = ((b[ihl+2].toInt() and 0xFF) shl 8) or (b[ihl+3].toInt() and 0xFF)
    fun tcpSeq(b: ByteArray, ihl: Int): Long =
        ((b[ihl+4].toLong() and 0xFF) shl 24) or ((b[ihl+5].toLong() and 0xFF) shl 16) or
        ((b[ihl+6].toLong() and 0xFF) shl 8)  or  (b[ihl+7].toLong() and 0xFF)
    fun tcpAck(b: ByteArray, ihl: Int): Long =
        ((b[ihl+8].toLong() and 0xFF) shl 24) or ((b[ihl+9].toLong() and 0xFF) shl 16) or
        ((b[ihl+10].toLong() and 0xFF) shl 8) or  (b[ihl+11].toLong() and 0xFF)
    fun tcpDataOffset(b: ByteArray, ihl: Int) = ((b[ihl+12].toInt() ushr 4) and 0xF) * 4
    fun tcpFlags(b: ByteArray, ihl: Int)      = b[ihl+13].toInt() and 0xFF
    fun tcpWindow(b: ByteArray, ihl: Int)     = ((b[ihl+14].toInt() and 0xFF) shl 8) or (b[ihl+15].toInt() and 0xFF)
    fun tcpPayload(b: ByteArray, ihl: Int): ByteArray {
        val dataOff = tcpDataOffset(b, ihl)
        val start = ihl + dataOff
        val len = totalLen(b) - ihl - dataOff
        return if (len > 0 && start + len <= b.size) b.copyOfRange(start, start + len) else ByteArray(0)
    }

    // UDP
    fun udpSrcPort(b: ByteArray, ihl: Int) = ((b[ihl].toInt() and 0xFF) shl 8) or (b[ihl+1].toInt() and 0xFF)
    fun udpDstPort(b: ByteArray, ihl: Int) = ((b[ihl+2].toInt() and 0xFF) shl 8) or (b[ihl+3].toInt() and 0xFF)
    fun udpPayload(b: ByteArray, ihl: Int): ByteArray {
        val len = ((b[ihl+4].toInt() and 0xFF) shl 8) or (b[ihl+5].toInt() and 0xFF)
        val start = ihl + 8
        val dataLen = len - 8
        return if (dataLen > 0 && start + dataLen <= b.size) b.copyOfRange(start, start + dataLen) else ByteArray(0)
    }

    // Flags
    const val FIN = 0x01; const val SYN = 0x02; const val RST = 0x04
    const val PSH = 0x08; const val ACK = 0x10

    // Protocol numbers
    const val PROTO_TCP = 6; const val PROTO_UDP = 17

    // Checksum
    fun checksum(buf: ByteArray, offset: Int = 0, length: Int = buf.size): Int {
        var sum = 0L
        var i = offset
        val end = offset + length
        while (i < end - 1) { sum += ((buf[i].toInt() and 0xFF) shl 8) or (buf[i+1].toInt() and 0xFF); i += 2 }
        if (i < end) sum += (buf[i].toInt() and 0xFF) shl 8
        while (sum shr 16 != 0L) sum = (sum and 0xFFFF) + (sum shr 16)
        return (sum.inv() and 0xFFFF).toInt()
    }

    // Build IP+TCP packet
    fun buildTcp(
        srcIp: ByteArray, dstIp: ByteArray, srcPort: Int, dstPort: Int,
        seq: Long, ack: Long, flags: Int, window: Int = 65535,
        payload: ByteArray = ByteArray(0)
    ): ByteArray {
        val tcpLen = 20 + payload.size
        val total  = 20 + tcpLen
        val buf = ByteArray(total)
        // IP header
        buf[0] = 0x45.toByte(); buf[1] = 0
        buf[2] = (total shr 8).toByte(); buf[3] = total.toByte()
        buf[4] = 0; buf[5] = 1; buf[6] = 0x40.toByte(); buf[7] = 0
        buf[8] = 64; buf[9] = 6.toByte()
        srcIp.copyInto(buf, 12); dstIp.copyInto(buf, 16)
        val ipCs = checksum(buf, 0, 20)
        buf[10] = (ipCs shr 8).toByte(); buf[11] = ipCs.toByte()
        // TCP header
        buf[20] = (srcPort shr 8).toByte(); buf[21] = srcPort.toByte()
        buf[22] = (dstPort shr 8).toByte(); buf[23] = dstPort.toByte()
        buf[24] = (seq shr 24).toByte(); buf[25] = (seq shr 16).toByte()
        buf[26] = (seq shr 8).toByte();  buf[27] = seq.toByte()
        buf[28] = (ack shr 24).toByte(); buf[29] = (ack shr 16).toByte()
        buf[30] = (ack shr 8).toByte();  buf[31] = ack.toByte()
        buf[32] = 0x50.toByte(); buf[33] = flags.toByte()
        buf[34] = (window shr 8).toByte(); buf[35] = window.toByte()
        payload.copyInto(buf, 40)
        val pseudo = ByteArray(12 + tcpLen)
        srcIp.copyInto(pseudo, 0); dstIp.copyInto(pseudo, 4)
        pseudo[8] = 0; pseudo[9] = 6
        pseudo[10] = (tcpLen shr 8).toByte(); pseudo[11] = tcpLen.toByte()
        buf.copyInto(pseudo, 12, 20, 20 + tcpLen)
        val tcpCs = checksum(pseudo)
        buf[36] = (tcpCs shr 8).toByte(); buf[37] = tcpCs.toByte()
        return buf
    }

    // Build IP+UDP packet (for writing back to TUN)
    fun buildUdp(
        srcIp: ByteArray, dstIp: ByteArray, srcPort: Int, dstPort: Int,
        payload: ByteArray
    ): ByteArray {
        val udpLen = 8 + payload.size
        val total  = 20 + udpLen
        val buf = ByteArray(total)
        buf[0] = 0x45.toByte(); buf[1] = 0
        buf[2] = (total shr 8).toByte(); buf[3] = total.toByte()
        buf[4] = 0; buf[5] = 2; buf[6] = 0x40.toByte(); buf[7] = 0
        buf[8] = 64; buf[9] = 17.toByte()
        srcIp.copyInto(buf, 12); dstIp.copyInto(buf, 16)
        val ipCs = checksum(buf, 0, 20)
        buf[10] = (ipCs shr 8).toByte(); buf[11] = ipCs.toByte()
        buf[20] = (srcPort shr 8).toByte(); buf[21] = srcPort.toByte()
        buf[22] = (dstPort shr 8).toByte(); buf[23] = dstPort.toByte()
        buf[24] = (udpLen shr 8).toByte(); buf[25] = udpLen.toByte()
        buf[26] = 0; buf[27] = 0
        payload.copyInto(buf, 28)
        val pseudo = ByteArray(12 + udpLen)
        srcIp.copyInto(pseudo, 0); dstIp.copyInto(pseudo, 4)
        pseudo[8] = 0; pseudo[9] = 17
        pseudo[10] = (udpLen shr 8).toByte(); pseudo[11] = udpLen.toByte()
        buf.copyInto(pseudo, 12, 20, 20 + udpLen)
        val udpCs = checksum(pseudo)
        buf[26] = (udpCs shr 8).toByte(); buf[27] = udpCs.toByte()
        return buf
    }

    fun ipStr(b: ByteArray): String = try { InetAddress.getByAddress(b).hostAddress ?: "?" } catch (_: Exception) { "?" }

    // Extract SNI from TLS ClientHello
    fun sni(payload: ByteArray): String? {
        if (payload.size < 5 || payload[0].toInt() and 0xFF != 0x16) return null
        var pos = 5
        if (pos >= payload.size || payload[pos].toInt() and 0xFF != 0x01) return null
        pos += 4 + 2 + 32
        if (pos >= payload.size) return null
        val sessionLen = payload[pos].toInt() and 0xFF; pos += 1 + sessionLen
        if (pos + 2 >= payload.size) return null
        val cipherLen = ((payload[pos].toInt() and 0xFF) shl 8) or (payload[pos+1].toInt() and 0xFF); pos += 2 + cipherLen
        if (pos >= payload.size) return null
        val compLen = payload[pos].toInt() and 0xFF; pos += 1 + compLen
        if (pos + 2 >= payload.size) return null
        val extEnd = pos + 2 + (((payload[pos].toInt() and 0xFF) shl 8) or (payload[pos+1].toInt() and 0xFF)); pos += 2
        while (pos + 4 <= extEnd && pos + 4 <= payload.size) {
            val type = ((payload[pos].toInt() and 0xFF) shl 8) or (payload[pos+1].toInt() and 0xFF)
            val len  = ((payload[pos+2].toInt() and 0xFF) shl 8) or (payload[pos+3].toInt() and 0xFF)
            pos += 4
            if (type == 0) {
                pos += 3
                val nameLen = ((payload[pos].toInt() and 0xFF) shl 8) or (payload[pos+1].toInt() and 0xFF); pos += 2
                if (pos + nameLen <= payload.size) return String(payload, pos, nameLen, Charsets.US_ASCII)
            } else pos += len
        }
        return null
    }
}
