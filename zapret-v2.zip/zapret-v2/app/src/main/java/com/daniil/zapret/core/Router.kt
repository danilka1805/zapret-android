package com.daniil.zapret.core

import android.net.VpnService
import android.util.Log
import com.daniil.zapret.dpi.BypassMode
import com.daniil.zapret.whitelist.WhitelistManager
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap

private const val TAG = "Router"
private const val MAX_TCP = 256
private const val MAX_UDP = 256

class Router(
    private val vpn: VpnService,
    private val tunOut: FileOutputStream,
    private val whitelist: WhitelistManager,
    private val bypass: BypassMode
) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val tcpConns = ConcurrentHashMap<String, TcpConn>()
    private val udpConns = ConcurrentHashMap<String, UdpConn>()

    // Single writer to TUN prevents concurrent write races
    private val tunCh = Channel<ByteArray>(Channel.UNLIMITED)
    private var writerJob: Job? = null
    private var lastClean = System.currentTimeMillis()

    fun start() {
        writerJob = scope.launch(Dispatchers.IO) {
            for (pkt in tunCh) {
                try { tunOut.write(pkt) }
                catch (e: Exception) { Log.w(TAG, "tunOut.write: ${e.message}") }
            }
        }
    }

    suspend fun tunWrite(pkt: ByteArray) { tunCh.send(pkt) }

    fun handlePacket(raw: ByteArray, len: Int) {
        if (len < 20) return
        val pkt = raw.copyOf(len)
        if (Packet.version(pkt) != 4) return
        val ihl = Packet.ihl(pkt)
        if (pkt.size < ihl + 8) return

        when (Packet.proto(pkt)) {
            Packet.PROTO_TCP -> handleTcp(pkt, ihl)
            Packet.PROTO_UDP -> handleUdp(pkt, ihl)
        }

        val now = System.currentTimeMillis()
        if (now - lastClean > 20_000) { cleanup(); lastClean = now }
    }

    // ─── TCP ───────────────────────────────────────────────────────────

    private fun handleTcp(pkt: ByteArray, ihl: Int) {
        if (pkt.size < ihl + 20) return
        val flags      = Packet.tcpFlags(pkt, ihl)
        val clientIp   = Packet.srcIp(pkt)
        val serverIp   = Packet.dstIp(pkt)
        val clientPort = Packet.tcpSrcPort(pkt, ihl)
        val serverPort = Packet.tcpDstPort(pkt, ihl)
        val seq        = Packet.tcpSeq(pkt, ihl)
        val payload    = Packet.tcpPayload(pkt, ihl)
        val key        = "${clientPort}→${Packet.ipStr(serverIp)}:${serverPort}"

        if (flags and Packet.SYN != 0 && flags and Packet.ACK == 0) {
            // New connection
            if (tcpConns.size >= MAX_TCP) { cleanup() }

            // Apply DPI bypass only on HTTPS (port 443)
            val doBypass = serverPort == 443 &&
                (whitelist.isEmpty() || whitelist.matchesPort(443))

            Log.d(TAG, "SYN $key bypass=$doBypass mode=${if (doBypass) bypass.id else "none"}")

            val conn = TcpConn(
                vpn        = vpn,
                tunWrite   = ::tunWrite,
                clientIp   = clientIp,
                serverIp   = serverIp,
                clientPort = clientPort,
                serverPort = serverPort,
                clientIsn  = seq,
                bypass     = if (doBypass) bypass else BypassMode.NONE,
                scope      = scope
            )
            tcpConns[key] = conn
            ZapretVpnService.activeConns = tcpConns.size
            conn.start()
            return
        }

        val conn = tcpConns[key] ?: return
        when {
            flags and Packet.RST != 0 -> {
                conn.feedRst()
                tcpConns.remove(key)
                ZapretVpnService.activeConns = tcpConns.size
            }
            flags and Packet.FIN != 0 -> {
                conn.feedFin()
                tcpConns.remove(key)
                ZapretVpnService.activeConns = tcpConns.size
            }
            payload.isNotEmpty() -> {
                conn.advanceAck(seq, payload.size)
                conn.feedData(payload)
            }
            // Pure ACK — update nothing, client acknowledged our data
        }
    }

    // ─── UDP ───────────────────────────────────────────────────────────

    private fun handleUdp(pkt: ByteArray, ihl: Int) {
        if (pkt.size < ihl + 8) return
        val clientIp   = Packet.srcIp(pkt)
        val serverIp   = Packet.dstIp(pkt)
        val clientPort = Packet.udpSrcPort(pkt, ihl)
        val serverPort = Packet.udpDstPort(pkt, ihl)
        val payload    = Packet.udpPayload(pkt, ihl)
        if (payload.isEmpty()) return

        val key = "udp-${clientPort}-${serverPort}-${Packet.ipStr(serverIp)}"
        val conn = udpConns.getOrPut(key) {
            if (udpConns.size >= MAX_UDP) cleanup()
            UdpConn(vpn, ::tunWrite, clientIp, serverIp, clientPort, serverPort, scope)
                .also { it.start() }
        }
        conn.send(payload)
    }

    // ─── Cleanup ───────────────────────────────────────────────────────

    private fun cleanup() {
        val tcpDead = tcpConns.entries.filter { it.value.state == ConnState.CLOSED }
        tcpDead.forEach { tcpConns.remove(it.key) }
        val udpDead = udpConns.entries.filter { it.value.isIdle }
        udpDead.forEach { (k, v) -> v.close(); udpConns.remove(k) }
        ZapretVpnService.activeConns = tcpConns.size
        if (tcpDead.isNotEmpty() || udpDead.isNotEmpty())
            Log.d(TAG, "cleanup: removed tcp=${tcpDead.size} udp=${udpDead.size}, left tcp=${tcpConns.size} udp=${udpConns.size}")
    }

    fun close() {
        tcpConns.values.forEach { it.close() }
        udpConns.values.forEach { it.close() }
        tcpConns.clear(); udpConns.clear()
        tunCh.close()
        writerJob?.cancel()
        scope.cancel()
    }
}
