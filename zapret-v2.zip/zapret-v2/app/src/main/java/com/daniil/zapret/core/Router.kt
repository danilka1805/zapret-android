package com.daniil.zapret.core

import android.net.VpnService
import android.util.Log
import com.daniil.zapret.dpi.BypassMode
import com.daniil.zapret.whitelist.WhitelistManager
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap

private const val TAG = "Router"
private const val MAX_TCP = 128
private const val MAX_UDP = 256

class Router(
    private val vpn: VpnService,
    private val tunOut: FileOutputStream,
    private val whitelist: WhitelistManager,
    private val bypass: BypassMode,
    val dohEnabled: Boolean = true
) {
    // Coroutine scope for all connections — limited parallelism for stability
    private val scope = CoroutineScope(
        Dispatchers.IO.limitedParallelism(32) + SupervisorJob()
    )

    private val tcpConns = ConcurrentHashMap<String, TcpConn>()
    private val udpConns = ConcurrentHashMap<String, UdpConn>()

    // Channel for writing to TUN — single writer prevents concurrent write races
    private val tunChannel = Channel<ByteArray>(Channel.UNLIMITED)
    private var tunWriterJob: Job? = null

    private var lastCleanup = System.currentTimeMillis()

    fun start() {
        tunWriterJob = scope.launch {
            for (pkt in tunChannel) {
                try { withContext(Dispatchers.IO) { tunOut.write(pkt) } }
                catch (_: Exception) {}
            }
        }
    }

    private suspend fun tunWrite(pkt: ByteArray) { tunChannel.send(pkt) }

    fun handlePacket(raw: ByteArray, len: Int) {
        if (len < 20) return
        val pkt = raw.copyOf(len)
        if (Packet.version(pkt) != 4) return

        val ihl = Packet.ihl(pkt)
        val proto = Packet.proto(pkt)

        when (proto) {
            Packet.PROTO_TCP -> handleTcp(pkt, ihl)
            Packet.PROTO_UDP -> handleUdp(pkt, ihl)
        }

        val now = System.currentTimeMillis()
        if (now - lastCleanup > 15_000) { cleanup(); lastCleanup = now }
    }

    // ─── TCP ───────────────────────────────────────────────────────────

    private fun handleTcp(pkt: ByteArray, ihl: Int) {
        if (pkt.size < ihl + 20) return
        val flags     = Packet.tcpFlags(pkt, ihl)
        val clientIp  = Packet.srcIp(pkt)
        val serverIp  = Packet.dstIp(pkt)
        val clientPort= Packet.tcpSrcPort(pkt, ihl)
        val serverPort= Packet.tcpDstPort(pkt, ihl)
        val seq       = Packet.tcpSeq(pkt, ihl)
        val payload   = Packet.tcpPayload(pkt, ihl)

        val key = "$clientPort-$serverPort-${Packet.ipStr(serverIp)}"

        if (flags and Packet.SYN != 0 && flags and Packet.ACK == 0) {
            // New connection
            if (tcpConns.size >= MAX_TCP) { cleanup(); if (tcpConns.size >= MAX_TCP) return }

            // Check whitelist (SNI check happens lazily on first data packet)
            val shouldBypass = whitelist.isEmpty() || serverPort == 443 || serverPort == 80

            val conn = TcpConn(
                vpn = vpn,
                tunWrite = ::tunWrite,
                clientIp = clientIp, serverIp = serverIp,
                clientPort = clientPort, serverPort = serverPort,
                clientIsn = seq,
                bypass = if (shouldBypass) bypass else BypassMode.NONE,
                scope = scope
            )
            tcpConns[key] = conn
            conn.start()
            return
        }

        val conn = tcpConns[key] ?: return
        when {
            flags and Packet.RST != 0 -> { conn.feedRst(); tcpConns.remove(key) }
            flags and Packet.FIN != 0 -> { conn.feedFin(); tcpConns.remove(key) }
            payload.isNotEmpty() -> { conn.advanceAck(seq + payload.size - 1); conn.feedData(payload) }
        }
    }

    // ─── UDP ───────────────────────────────────────────────────────────

    private fun handleUdp(pkt: ByteArray, ihl: Int) {
        if (pkt.size < ihl + 8) return
        val clientIp  = Packet.srcIp(pkt)
        val serverIp  = Packet.dstIp(pkt)
        val clientPort= Packet.udpSrcPort(pkt, ihl)
        val serverPort= Packet.udpDstPort(pkt, ihl)
        val payload   = Packet.udpPayload(pkt, ihl)
        if (payload.isEmpty()) return

        // Intercept DNS queries and resolve via DoH
        if (serverPort == 53 && dohEnabled) {
            handleDns(payload, clientIp, serverIp, clientPort)
            return
        }

        val key = "udp-$clientPort-$serverPort-${Packet.ipStr(serverIp)}"
        val conn = udpConns.getOrPut(key) {
            if (udpConns.size >= MAX_UDP) cleanup()
            UdpConn(vpn, ::tunWrite, clientIp, serverIp, clientPort, serverPort, scope).also { it.start() }
        }
        conn.send(payload)
    }

    private fun handleDns(payload: ByteArray, clientIp: ByteArray, serverIp: ByteArray, clientPort: Int) {
        val query = DnsPacket.parseQuery(payload) ?: return
        Log.d(TAG, "DNS query: ${query.domain} type=${query.qtype}")

        scope.launch(Dispatchers.IO) {
            try {
                val ips = DoHResolver.resolve(query.domain, query.qtype)
                val responsePayload = if (ips.isNotEmpty()) {
                    Log.d(TAG, "DoH resolved ${query.domain} -> $ips")
                    DnsPacket.buildResponse(query, ips)
                } else {
                    Log.d(TAG, "DoH NXDOMAIN for ${query.domain}")
                    DnsPacket.buildNxDomain(query)
                }
                // Write DNS response back as UDP: src=DNS server, dst=client
                val udpPkt = Packet.buildUdp(serverIp, clientIp, 53, clientPort, responsePayload)
                tunWrite(udpPkt)
            } catch (e: Exception) {
                Log.w(TAG, "DoH error for ${query.domain}: ${e.message}")
            }
        }
    }

    // ─── Cleanup ───────────────────────────────────────────────────────

    private fun cleanup() {
        tcpConns.entries.removeIf { it.value.state == ConnState.CLOSED }
        udpConns.entries.filter { it.value.isIdle }.forEach { (k, v) -> v.close(); udpConns.remove(k) }
        Log.d(TAG, "Cleanup: tcp=${tcpConns.size} udp=${udpConns.size}")
    }

    fun close() {
        tcpConns.values.forEach { it.close() }
        udpConns.values.forEach { it.close() }
        tcpConns.clear(); udpConns.clear()
        tunChannel.close()
        tunWriterJob?.cancel()
        scope.cancel()
    }

    val stats get() = "TCP: ${tcpConns.size} / UDP: ${udpConns.size}"
}
