package com.daniil.zapret.core

import android.net.VpnService
import android.util.Log
import com.daniil.zapret.dpi.BypassMode
import com.daniil.zapret.whitelist.WhitelistManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue

private const val TAG = "Router"
// Max concurrent connections — 2 tasks per conn (c2s + s2c)
private const val POOL_SIZE = 64

class Router(
    private val vpn: VpnService,
    private val tunOut: FileOutputStream,
    private val whitelist: WhitelistManager,
    private val bypass: BypassMode
) {
    // Fixed thread pool — prevents thread explosion
    private val executor = Executors.newFixedThreadPool(POOL_SIZE)

    // Coroutine scope for UDP (simpler there)
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val tcpConns = ConcurrentHashMap<String, TcpConn>()
    private val udpConns = ConcurrentHashMap<String, UdpConn>()

    // Single-writer queue for TUN → no concurrent write races
    private val tunQueue = LinkedBlockingQueue<ByteArray>(8192)
    private var writerThread: Thread? = null
    private var lastClean = System.currentTimeMillis()

    fun start() {
        writerThread = Thread({
            while (true) {
                val pkt = tunQueue.take()
                if (pkt.isEmpty()) break
                try { tunOut.write(pkt) }
                catch (e: Exception) { Log.w(TAG, "tunOut: ${e.message}") }
            }
        }, "tun-writer").also { it.isDaemon = true; it.start() }
    }

    fun tunWrite(pkt: ByteArray) {
        if (!tunQueue.offer(pkt)) {
            // Queue full — drop oldest, add new (backpressure)
            tunQueue.poll()
            tunQueue.offer(pkt)
        }
    }

    fun handlePacket(raw: ByteArray, len: Int) {
        if (len < 20) return
        val pkt = raw.copyOf(len)
        if (Packet.version(pkt) != 4) return
        val ihl = Packet.ihl(pkt)
        if (pkt.size < ihl + 8) return
        when (Packet.proto(pkt)) {
            Packet.PROTO_TCP -> handleTcp(pkt, ihl)
            Packet.PROTO_UDP -> handleUdp(pkt, ihl)
        }
        val now = System.currentTimeMillis()
        if (now - lastClean > 15_000) { cleanup(); lastClean = now }
    }

    private fun handleTcp(pkt: ByteArray, ihl: Int) {
        if (pkt.size < ihl + 20) return
        val flags      = Packet.tcpFlags(pkt, ihl)
        val clientIp   = Packet.srcIp(pkt)
        val serverIp   = Packet.dstIp(pkt)
        val clientPort = Packet.tcpSrcPort(pkt, ihl)
        val serverPort = Packet.tcpDstPort(pkt, ihl)
        val seq        = Packet.tcpSeq(pkt, ihl)
        val payload    = Packet.tcpPayload(pkt, ihl)
        val key        = "$clientPort→${Packet.ipStr(serverIp)}:$serverPort"

        if (flags and Packet.SYN != 0 && flags and Packet.ACK == 0) {
            // Limit total connections
            if (tcpConns.size >= 128) cleanup()
            if (tcpConns.size >= 128) return

            val doBypass = serverPort == 443 &&
                (whitelist.isEmpty() || whitelist.matchesPort(443))

            val conn = TcpConn(
                vpn        = vpn,
                tunWrite   = ::tunWrite,
                clientIp   = clientIp,
                serverIp   = serverIp,
                clientPort = clientPort,
                serverPort = serverPort,
                clientIsn  = seq,
                bypass     = if (doBypass) bypass else BypassMode.NONE,
                executor   = executor
            )
            tcpConns[key] = conn
            ZapretVpnService.activeConns = tcpConns.size
            conn.start()
            return
        }

        val conn = tcpConns[key] ?: return
        when {
            flags and Packet.RST != 0 -> {
                conn.feedRst()
                tcpConns.remove(key)
                ZapretVpnService.activeConns = tcpConns.size
            }
            flags and Packet.FIN != 0 -> {
                conn.feedFin()
            }
            payload.isNotEmpty() -> {
                conn.advanceAck(seq, payload.size)
                conn.feedData(payload)
            }
        }
    }

    private fun handleUdp(pkt: ByteArray, ihl: Int) {
        if (pkt.size < ihl + 8) return
        val clientIp   = Packet.srcIp(pkt)
        val serverIp   = Packet.dstIp(pkt)
        val clientPort = Packet.udpSrcPort(pkt, ihl)
        val serverPort = Packet.udpDstPort(pkt, ihl)
        val payload    = Packet.udpPayload(pkt, ihl)
        if (payload.isEmpty()) return
        val key  = "udp-$clientPort-$serverPort-${Packet.ipStr(serverIp)}"
        val conn = udpConns.getOrPut(key) {
            if (udpConns.size >= 256) cleanup()
            UdpConn(vpn, ::tunWrite, clientIp, serverIp, clientPort, serverPort, scope)
                .also { it.start() }
        }
        conn.send(payload)
    }

    private fun cleanup() {
        tcpConns.entries.removeIf { it.value.state == ConnState.CLOSED }
        udpConns.entries.filter { it.value.isIdle }.forEach { (k, v) -> v.close(); udpConns.remove(k) }
        ZapretVpnService.activeConns = tcpConns.size
    }

    fun close() {
        tcpConns.values.forEach { it.close() }
        udpConns.values.forEach { it.close() }
        tcpConns.clear(); udpConns.clear()
        executor.shutdownNow()
        tunQueue.put(ByteArray(0))
        scope.cancel()
    }
}
