package com.daniil.zapret.core

import android.net.VpnService
import kotlinx.coroutines.*
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.atomic.AtomicLong

private const val UDP_IDLE_MS = 30_000L

/**
 * Transparent UDP relay: forwards datagrams to the real server and
 * writes responses back to the TUN (as IP+UDP packets).
 * No DPI bypass needed for UDP — providers mostly inspect TCP SNI.
 */
class UdpConn(
    private val vpn: VpnService,
    private val tunWrite: suspend (ByteArray) -> Unit,
    val clientIp: ByteArray,
    val serverIp: ByteArray,
    val clientPort: Int,
    val serverPort: Int,
    private val scope: CoroutineScope
) {
    private val socket = DatagramSocket()
    private val lastActivity = AtomicLong(System.currentTimeMillis())
    private var readerJob: Job? = null

    val isIdle get() = System.currentTimeMillis() - lastActivity.get() > UDP_IDLE_MS

    fun start() {
        val ok = vpn.protect(socket)
        if (!ok) android.util.Log.w("UdpConn", "protect() failed")
        socket.connect(InetAddress.getByAddress(serverIp), serverPort)
        readerJob = scope.launch(Dispatchers.IO) { readLoop() }
    }

    fun send(payload: ByteArray) {
        lastActivity.set(System.currentTimeMillis())
        try {
            socket.send(DatagramPacket(payload, payload.size))
        } catch (_: Exception) {}
    }

    private suspend fun readLoop() {
        val buf = ByteArray(65535)
        val pkt = DatagramPacket(buf, buf.size)
        while (true) {
            try {
                withContext(Dispatchers.IO) { socket.receive(pkt) }
                lastActivity.set(System.currentTimeMillis())
                val data = pkt.data.copyOf(pkt.length)
                // Write back to TUN: src=server, dst=client
                val ipPkt = Packet.buildUdp(serverIp, clientIp, serverPort, clientPort, data)
                tunWrite(ipPkt)
            } catch (_: Exception) { break }
        }
    }

    fun close() {
        readerJob?.cancel()
        try { socket.close() } catch (_: Exception) {}
    }

    val key get() = "udp-$clientPort-$serverPort-${Packet.ipStr(serverIp)}"
}
