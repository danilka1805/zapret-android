package com.daniil.zapret.core

import android.net.VpnService
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.atomic.AtomicLong

private const val TAG = "UdpConn"
private const val IDLE_MS = 30_000L

class UdpConn(
    private val vpn: VpnService,
    private val tunWrite: (ByteArray) -> Unit,    // now blocking, not suspend
    val clientIp: ByteArray,
    val serverIp: ByteArray,
    val clientPort: Int,
    val serverPort: Int,
    scope: CoroutineScope                         // kept for API compat, not used
) {
    private val socket       = DatagramSocket()
    private val lastActivity = AtomicLong(System.currentTimeMillis())
    @Volatile private var running = true

    val isIdle get() = System.currentTimeMillis() - lastActivity.get() > IDLE_MS

    fun start() {
        val ok = vpn.protect(socket)
        if (!ok) Log.w(TAG, "protect() failed udp $clientPort")
        socket.connect(InetAddress.getByAddress(serverIp), serverPort)

        Thread({
            val buf = ByteArray(65535)
            val pkt = DatagramPacket(buf, buf.size)
            while (running) {
                try {
                    socket.receive(pkt)
                    lastActivity.set(System.currentTimeMillis())
                    val data   = pkt.data.copyOf(pkt.length)
                    val ipPkt  = Packet.buildUdp(serverIp, clientIp, serverPort, clientPort, data)
                    tunWrite(ipPkt)
                } catch (_: Exception) { break }
            }
        }, "udp-$clientPort").also { it.isDaemon = true; it.start() }
    }

    fun send(payload: ByteArray) {
        lastActivity.set(System.currentTimeMillis())
        try { socket.send(DatagramPacket(payload, payload.size)) }
        catch (_: Exception) {}
    }

    fun close() {
        running = false
        try { socket.close() } catch (_: Exception) {}
    }

    val key get() = "udp-$clientPort-$serverPort-${Packet.ipStr(serverIp)}"
}
