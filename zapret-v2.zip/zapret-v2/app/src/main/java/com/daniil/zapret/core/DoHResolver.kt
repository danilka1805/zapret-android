package com.daniil.zapret.core

import android.net.VpnService
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.Socket
import java.net.URL
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLSocketFactory

private const val TAG = "DoH"

// Hardcoded IPs — no DNS needed to reach these, avoids infinite loop
private val DOH_SERVERS = listOf(
    Triple("1.1.1.1",     "cloudflare-dns.com", "https://1.1.1.1/dns-query"),
    Triple("8.8.8.8",     "dns.google",         "https://8.8.8.8/dns-query"),
    Triple("9.9.9.9",     "dns.quad9.net",      "https://9.9.9.9/dns-query"),
    Triple("1.0.0.1",     "cloudflare-dns.com", "https://1.0.0.1/dns-query")
)

object DoHResolver {

    private lateinit var vpnService: VpnService

    fun init(vpn: VpnService) { vpnService = vpn }

    suspend fun resolve(domain: String, qtype: Int = 1): List<String> =
        withContext(Dispatchers.IO) {
            for ((ip, host, url) in DOH_SERVERS) {
                try {
                    val result = query(ip, host, url, domain, qtype)
                    if (result.isNotEmpty()) return@withContext result
                } catch (e: Exception) {
                    Log.d(TAG, "DoH $ip failed: ${e.message}")
                }
            }
            emptyList()
        }

    private fun query(serverIp: String, serverHost: String, urlStr: String,
                      domain: String, qtype: Int): List<String> {
        val typeStr = if (qtype == 28) "AAAA" else "A"
        val url = URL("$urlStr?name=${domain.trimEnd('.')}&type=$typeStr")

        val conn = url.openConnection() as HttpsURLConnection

        // Use a protected socket factory so this connection bypasses our TUN
        if (::vpnService.isInitialized) {
            conn.sslSocketFactory = ProtectedSslSocketFactory(
                vpnService,
                SSLSocketFactory.getDefault() as SSLSocketFactory,
                InetAddress.getByName(serverIp),
                serverHost
            )
        }

        conn.setRequestProperty("Accept", "application/dns-json")
        conn.setRequestProperty("Host", serverHost)
        conn.connectTimeout = 4000
        conn.readTimeout = 4000

        val code = conn.responseCode
        if (code != 200) { conn.disconnect(); return emptyList() }

        val body = conn.inputStream.bufferedReader().readText()
        conn.disconnect()

        val json = JSONObject(body)
        if (json.optInt("Status", -1) != 0) return emptyList()

        val answers = json.optJSONArray("Answer") ?: return emptyList()
        val ips = mutableListOf<String>()
        for (i in 0 until answers.length()) {
            val ans = answers.getJSONObject(i)
            if (ans.optInt("type", 0) == qtype) {
                val data = ans.optString("data", "")
                if (data.isNotEmpty()) ips.add(data)
            }
        }
        return ips
    }
}

/**
 * SSLSocketFactory that calls vpn.protect() on every socket it creates,
 * so DoH connections bypass the TUN and go directly to the internet.
 */
private class ProtectedSslSocketFactory(
    private val vpn: VpnService,
    private val delegate: SSLSocketFactory,
    private val serverAddr: InetAddress,
    private val serverHost: String
) : SSLSocketFactory() {

    override fun getDefaultCipherSuites(): Array<String> = delegate.defaultCipherSuites
    override fun getSupportedCipherSuites(): Array<String> = delegate.supportedCipherSuites

    override fun createSocket(host: String?, port: Int) = protect(delegate.createSocket(serverAddr, 443))
    override fun createSocket(host: String?, port: Int, localHost: java.net.InetAddress?, localPort: Int) =
        protect(delegate.createSocket(serverAddr, 443, localHost, localPort))
    override fun createSocket(address: java.net.InetAddress?, port: Int) = protect(delegate.createSocket(serverAddr, 443))
    override fun createSocket(address: java.net.InetAddress?, port: Int, localAddress: java.net.InetAddress?, localPort: Int) =
        protect(delegate.createSocket(serverAddr, 443, localAddress, localPort))
    override fun createSocket(s: Socket?, host: String?, port: Int, autoClose: Boolean) =
        protect(delegate.createSocket(s, serverHost, 443, autoClose))

    private fun protect(socket: Socket): Socket {
        vpn.protect(socket)
        return socket
    }
}
