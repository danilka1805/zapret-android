package com.daniil.zapret.core

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private const val TAG = "DoH"

// Cloudflare and Google DoH endpoints — tried in order
private val DOH_ENDPOINTS = listOf(
    "https://cloudflare-dns.com/dns-query",
    "https://dns.google/dns-query",
    "https://dns11.quad9.net/dns-query"
)

object DoHResolver {

    /**
     * Resolves a domain via DNS-over-HTTPS.
     * Returns list of IPv4 addresses, or empty list on failure.
     */
    suspend fun resolve(domain: String, type: Int = 1 /* A record */): List<String> =
        withContext(Dispatchers.IO) {
            for (endpoint in DOH_ENDPOINTS) {
                try {
                    val result = queryDoH(endpoint, domain, type)
                    if (result.isNotEmpty()) return@withContext result
                } catch (e: Exception) {
                    Log.d(TAG, "DoH $endpoint failed: ${e.message}")
                }
            }
            emptyList()
        }

    private fun queryDoH(endpoint: String, domain: String, type: Int): List<String> {
        val typeStr = if (type == 28) "AAAA" else "A"
        val url = URL("$endpoint?name=${domain.trimEnd('.')}&type=$typeStr")
        val conn = url.openConnection() as HttpURLConnection
        conn.apply {
            requestMethod = "GET"
            setRequestProperty("Accept", "application/dns-json")
            connectTimeout = 4000
            readTimeout = 4000
        }
        val code = conn.responseCode
        if (code != 200) { conn.disconnect(); return emptyList() }
        val body = conn.inputStream.bufferedReader().readText()
        conn.disconnect()

        val json = JSONObject(body)
        val status = json.optInt("Status", -1)
        if (status != 0) return emptyList()   // NXDOMAIN or error

        val answers = json.optJSONArray("Answer") ?: return emptyList()
        val ips = mutableListOf<String>()
        for (i in 0 until answers.length()) {
            val ans = answers.getJSONObject(i)
            val ansType = ans.optInt("type", 0)
            // type 1 = A, type 28 = AAAA
            if (ansType == type) {
                val data = ans.optString("data", "")
                if (data.isNotEmpty()) ips.add(data)
            }
        }
        return ips
    }
}
