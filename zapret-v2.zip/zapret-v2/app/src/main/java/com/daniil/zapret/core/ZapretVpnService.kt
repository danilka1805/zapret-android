package com.daniil.zapret.core

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import com.daniil.zapret.dpi.BypassMode
import com.daniil.zapret.ui.MainActivity
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.*
import java.util.concurrent.*
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

// ─── Constants ───────────────────────────────────────────────────────────────

private const val TAG        = "Zapret"
private const val CH         = "zapret"
private const val NID        = 1
private const val SOCKS_PORT = 10800   // local SOCKS5 proxy port

const val ACTION_START      = "com.daniil.zapret.START"
const val ACTION_STOP       = "com.daniil.zapret.STOP"
const val EXTRA_MODE        = "mode"
const val EXTRA_PKGS        = "pkgs"
const val EXTRA_PKG_EXCLUDE = "pkgs_exclude"

// ═══════════════════════════════════════════════════════════════════════════
// VPN SERVICE
// ═══════════════════════════════════════════════════════════════════════════

class ZapretVpnService : VpnService() {

    private var tun:    ParcelFileDescriptor? = null
    private var proxy:  LocalSocks5Proxy?     = null
    private var reader: TunReader?            = null
    @Volatile private var started = false

    companion object {
        @Volatile var isRunning   = false
        @Volatile var currentMode = BypassMode.SPLIT_2
        @Volatile var startMs     = 0L
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP  -> { doStop(); return START_NOT_STICKY }
            ACTION_START -> {
                val mode     = BypassMode.byId(intent.getStringExtra(EXTRA_MODE) ?: "split2")
                val allowed  = intent.getStringExtra(EXTRA_PKGS)
                    ?.split(",")?.filter { it.isNotBlank() } ?: emptyList()
                val excluded = intent.getStringExtra(EXTRA_PKG_EXCLUDE)
                    ?.split(",")?.filter { it.isNotBlank() } ?: emptyList()
                doStart(mode, allowed, excluded)
            }
        }
        return START_STICKY
    }

    private fun doStart(mode: BypassMode, allowed: List<String>, excluded: List<String>) {
        if (started) doStop()

        try {
            // 1. Start local SOCKS5 proxy
            proxy = LocalSocks5Proxy(this, mode, SOCKS_PORT)
            proxy!!.start()

            // 2. Create TUN interface
            val b = Builder()
                .setSession("Zapret")
                .addAddress("10.0.0.2", 32)
                .addDnsServer("1.1.1.1")
                .addDnsServer("8.8.8.8")
                .setMtu(1500)
                .setBlocking(true)

            // Route all IPv4 traffic through TUN
            b.addRoute("0.0.0.0", 0)

            for (pkg in allowed)  { try { b.addAllowedApplication(pkg)    } catch (_: Exception) {} }
            for (pkg in excluded) { try { b.addDisallowedApplication(pkg) } catch (_: Exception) {} }

            tun = b.establish()
            if (tun == null) {
                Log.e(TAG, "establish() returned null — permission not granted")
                proxy?.stop(); proxy = null
                return
            }

            // 3. Start TUN→SOCKS reader
            val inp = FileInputStream(tun!!.fileDescriptor)
            val out = FileOutputStream(tun!!.fileDescriptor)
            reader = TunReader(this, inp, out, SOCKS_PORT)
            reader!!.start()

            started       = true
            isRunning     = true
            currentMode   = mode
            startMs       = System.currentTimeMillis()
            startForeground(NID, buildNotif(mode.title))
            sendBroadcast(Intent("com.daniil.zapret.STATUS"))
            Log.i(TAG, "Started: ${mode.title}")

        } catch (e: Exception) {
            Log.e(TAG, "doStart crashed: $e\n${e.stackTraceToString()}")
            doStop()
        }
    }

    private fun doStop() {
        started   = false
        isRunning = false
        try { reader?.stop()  } catch (_: Exception) {}
        try { proxy?.stop()   } catch (_: Exception) {}
        try { tun?.close()    } catch (_: Exception) {}
        reader = null; proxy = null; tun = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        sendBroadcast(Intent("com.daniil.zapret.STATUS"))
        Log.i(TAG, "Stopped")
    }

    override fun onRevoke()  { doStop() }
    override fun onDestroy() { doStop(); super.onDestroy() }

    private fun buildNotif(name: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null)
            nm.createNotificationChannel(NotificationChannel(CH, "Zapret", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0,
            Intent(this, ZapretVpnService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CH)
            .setContentTitle("Zapret — $name")
            .setContentText("DPI обход активен")
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(
                android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_media_pause),
                "Стоп", stop).build())
            .setOngoing(true).build()
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// TUN READER — reads IP packets, routes TCP/UDP to SOCKS5
// ═══════════════════════════════════════════════════════════════════════════

private class TunReader(
    private val vpn: VpnService,
    private val tunIn: FileInputStream,
    private val tunOut: FileOutputStream,
    private val socksPort: Int
) {
    private val running  = AtomicBoolean(false)
    private val pool     = Executors.newCachedThreadPool()
    private val writeQ   = LinkedBlockingQueue<ByteArray>(4096)
    private val sessions = ConcurrentHashMap<String, TcpRelay>()

    fun start() {
        running.set(true)
        // Writer thread — single thread serialises all TUN writes
        pool.execute {
            while (running.get()) {
                val pkt = writeQ.poll(100, TimeUnit.MILLISECONDS) ?: continue
                if (pkt.isEmpty()) break
                try { tunOut.write(pkt) } catch (e: Exception) {
                    if (running.get()) Log.w(TAG, "tunWrite: ${e.message}")
                }
            }
        }
        // Reader thread
        pool.execute { readLoop() }
    }

    fun stop() {
        running.set(false)
        sessions.values.forEach { it.close() }
        sessions.clear()
        writeQ.offer(ByteArray(0))
        pool.shutdownNow()
    }

    private fun tunWrite(pkt: ByteArray) {
        if (!writeQ.offer(pkt)) { writeQ.poll(); writeQ.offer(pkt) }
    }

    private fun readLoop() {
        val buf = ByteArray(65536)
        Log.d(TAG, "TUN readLoop started")
        while (running.get()) {
            val n = try { tunIn.read(buf) } catch (e: Exception) {
                if (running.get()) Log.w(TAG, "tunRead: ${e.message}")
                break
            }
            if (n <= 0) continue
            val pkt = buf.copyOf(n)

            // Only IPv4
            if (pkt.size < 20) continue
            if ((pkt[0].toInt() ushr 4) and 0xF != 4) continue

            val ihl   = (pkt[0].toInt() and 0xF) * 4
            val proto = pkt[9].toInt() and 0xFF

            when (proto) {
                6  -> handleTcp(pkt, ihl)
                17 -> handleUdp(pkt, ihl)
            }
        }
        Log.d(TAG, "TUN readLoop ended")
    }

    // ─── TCP ─────────────────────────────────────────────────────────────

    private fun handleTcp(pkt: ByteArray, ihl: Int) {
        if (pkt.size < ihl + 20) return
        val flags  = pkt[ihl + 13].toInt() and 0xFF
        val cIp    = pkt.copyOfRange(12, 16)
        val sIp    = pkt.copyOfRange(16, 20)
        val cPort  = ((pkt[ihl].toInt() and 0xFF) shl 8)   or (pkt[ihl+1].toInt() and 0xFF)
        val sPort  = ((pkt[ihl+2].toInt() and 0xFF) shl 8) or (pkt[ihl+3].toInt() and 0xFF)
        val seq    = readU32(pkt, ihl + 4)
        val key    = "$cPort-${ipStr(sIp)}:$sPort"

        val isSyn = flags and 0x02 != 0 && flags and 0x10 == 0
        val isRst = flags and 0x04 != 0
        val isFin = flags and 0x01 != 0

        // Data: everything after TCP header
        val dataOff = ((pkt[ihl + 12].toInt() ushr 4) and 0xF) * 4
        val dataStart = ihl + dataOff
        val dataLen = (((pkt[2].toInt() and 0xFF) shl 8) or (pkt[3].toInt() and 0xFF)) - ihl - dataOff
        val data = if (dataLen > 0 && dataStart + dataLen <= pkt.size)
            pkt.copyOfRange(dataStart, dataStart + dataLen) else ByteArray(0)

        if (isSyn) {
            if (sessions.size > 150) sessions.entries.removeIf { it.value.isDead }
            val relay = TcpRelay(vpn, ::tunWrite, cIp, sIp, cPort, sPort, seq, socksPort, pool)
            sessions[key] = relay
            relay.start()
        } else {
            val relay = sessions[key] ?: return
            when {
                isRst -> { relay.close(); sessions.remove(key) }
                isFin -> relay.sendFin()
                data.isNotEmpty() -> {
                    val newAck = (seq + data.size) and 0xFFFFFFFFL
                    relay.setAck(newAck)
                    relay.feed(data)
                }
            }
            if (relay.isDead) sessions.remove(key)
        }
    }

    // ─── UDP ─────────────────────────────────────────────────────────────

    private fun handleUdp(pkt: ByteArray, ihl: Int) {
        if (pkt.size < ihl + 8) return
        val cIp   = pkt.copyOfRange(12, 16)
        val sIp   = pkt.copyOfRange(16, 20)
        val cPort = ((pkt[ihl].toInt() and 0xFF) shl 8)   or (pkt[ihl+1].toInt() and 0xFF)
        val sPort = ((pkt[ihl+2].toInt() and 0xFF) shl 8) or (pkt[ihl+3].toInt() and 0xFF)
        val udpLen = ((pkt[ihl+4].toInt() and 0xFF) shl 8) or (pkt[ihl+5].toInt() and 0xFF)
        if (udpLen <= 8) return
        val data = pkt.copyOfRange(ihl + 8, ihl + udpLen)

        pool.execute {
            try {
                val sock = DatagramSocket()
                vpn.protect(sock)
                sock.soTimeout = 3000
                sock.send(DatagramPacket(data, data.size, InetAddress.getByAddress(sIp), sPort))
                val rbuf = ByteArray(65535)
                val resp = DatagramPacket(rbuf, rbuf.size)
                sock.receive(resp)
                sock.close()
                tunWrite(buildUdpPacket(sIp, cIp, sPort, cPort, rbuf.copyOf(resp.length)))
            } catch (_: Exception) {}
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// TCP RELAY — one connection through local SOCKS5 proxy
// ═══════════════════════════════════════════════════════════════════════════

private class TcpRelay(
    private val vpn: VpnService,
    private val tunWrite: (ByteArray) -> Unit,
    private val cIp: ByteArray,
    private val sIp: ByteArray,
    private val cPort: Int,
    private val sPort: Int,
    clientIsn: Long,
    private val socksPort: Int,
    private val pool: ExecutorService
) {
    private val mySeq = AtomicLong(0x5A000000L)
    @Volatile private var myAck = (clientIsn + 1L) and 0xFFFFFFFFL
    private val dead  = AtomicBoolean(false)
    private val sock  = Socket()
    private val queue = LinkedBlockingQueue<ByteArray>(256)

    val isDead get() = dead.get()

    fun feed(data: ByteArray) { if (!dead.get()) queue.offer(data) }
    fun sendFin() { dead.set(true) }
    fun setAck(ack: Long) { myAck = ack }

    fun start() { pool.execute { run() } }

    fun close() {
        dead.set(true)
        try { sock.close() } catch (_: Exception) {}
    }

    private fun run() {
        // Connect to local SOCKS5 (no protect needed — it's localhost)
        try {
            sock.connect(InetSocketAddress("127.0.0.1", socksPort), 5000)
            sock.tcpNoDelay = true
            val sin  = sock.getInputStream()
            val sout = sock.getOutputStream()

            // SOCKS5 greeting
            sout.write(byteArrayOf(5, 1, 0)); sout.flush()
            val gr = ByteArray(2); readFully(sin, gr)
            if (gr[0] != 5.toByte() || gr[1] != 0.toByte()) {
                Log.w(TAG, "SOCKS5 greeting failed"); close(); return
            }

            // SOCKS5 CONNECT (IPv4)
            val req = ByteArray(10)
            req[0]=5; req[1]=1; req[2]=0; req[3]=1
            sIp.copyInto(req, 4)
            req[8] = (sPort shr 8).toByte(); req[9] = sPort.toByte()
            sout.write(req); sout.flush()
            val rep = ByteArray(10); readFully(sin, rep)
            if (rep[1] != 0.toByte()) {
                Log.d(TAG, "SOCKS5 CONNECT refused: ${rep[1]}"); close(); return
            }
        } catch (e: Exception) {
            Log.d(TAG, "relay connect: ${e.message}"); close(); return
        }

        // Send SYN-ACK to client
        tun(0x12, ByteArray(0))   // SYN|ACK
        mySeq.incrementAndGet()

        // Server→Client
        pool.execute {
            try {
                val buf = ByteArray(1440)
                val sin = sock.getInputStream()
                while (!dead.get()) {
                    val n = sin.read(buf)
                    if (n == -1) break
                    tun(0x18, buf.copyOf(n))   // PSH|ACK
                }
            } catch (_: Exception) {
            } finally {
                if (!dead.get()) try { tun(0x11, ByteArray(0)) } catch (_: Exception) {} // FIN|ACK
                close()
            }
        }

        // Client→Server
        try {
            val sout = sock.getOutputStream()
            while (!dead.get()) {
                val data = queue.poll(200, TimeUnit.MILLISECONDS) ?: continue
                sout.write(data); sout.flush()
                tun(0x10, ByteArray(0))   // ACK
            }
        } catch (_: Exception) {
        } finally { close() }
    }

    @Synchronized
    private fun tun(flags: Int, payload: ByteArray) {
        val seq = mySeq.get() and 0xFFFFFFFFL
        tunWrite(buildTcpPacket(sIp, cIp, sPort, cPort, seq, myAck, flags, payload))
        if (payload.isNotEmpty()) mySeq.addAndGet(payload.size.toLong())
        if (flags and 0x01 != 0) mySeq.incrementAndGet()  // FIN
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// LOCAL SOCKS5 PROXY with DPI bypass
// ═══════════════════════════════════════════════════════════════════════════

class LocalSocks5Proxy(
    private val vpn: VpnService,
    private val mode: BypassMode,
    private val port: Int
) {
    private var server: ServerSocket? = null
    private val running = AtomicBoolean(false)
    private val pool = Executors.newCachedThreadPool()

    fun start() {
        running.set(true)
        server = ServerSocket(port, 128, InetAddress.getLoopbackAddress())
        pool.execute {
            Log.i(TAG, "SOCKS5 proxy on :$port mode=${mode.id}")
            while (running.get()) {
                try {
                    val client = server!!.accept()
                    pool.execute { handle(client) }
                } catch (e: Exception) {
                    if (running.get()) Log.w(TAG, "socks5 accept: ${e.message}")
                }
            }
        }
    }

    fun stop() {
        running.set(false)
        try { server?.close() } catch (_: Exception) {}
        pool.shutdownNow()
    }

    private fun handle(client: Socket) {
        client.tcpNoDelay = true
        client.soTimeout  = 15_000
        try {
            val cin  = client.getInputStream()
            val cout = client.getOutputStream()

            // Handshake
            val ver = cin.read(); if (ver != 5) return
            val nm  = cin.read()
            val buf = ByteArray(nm); cin.read(buf)
            cout.write(byteArrayOf(5, 0)); cout.flush()

            // Request
            val hdr = ByteArray(4); readFully(cin, hdr)
            if (hdr[1].toInt() != 1) { cout.write(byteArrayOf(5,7,0,1,0,0,0,0,0,0)); return }

            val (host, port) = when (hdr[3].toInt()) {
                1 -> { val a = ByteArray(4); readFully(cin, a)
                       ipStr(a) to readU16(cin) }
                3 -> { val n = cin.read(); val d = ByteArray(n); readFully(cin, d)
                       String(d) to readU16(cin) }
                4 -> { val a = ByteArray(16); readFully(cin, a)
                       InetAddress.getByAddress(a).hostAddress!! to readU16(cin) }
                else -> return
            }

            // Connect to real server through protected socket
            val srv = Socket()
            vpn.protect(srv)
            try {
                srv.connect(InetSocketAddress(host, port), 8000)
                srv.tcpNoDelay = true
            } catch (e: Exception) {
                cout.write(byteArrayOf(5,4,0,1,0,0,0,0,0,0)); cout.flush()
                Log.d(TAG, "connect $host:$port failed: ${e.message}")
                client.close(); return
            }

            // Success reply
            cout.write(byteArrayOf(5,0,0,1,0,0,0,0,0,0)); cout.flush()
            client.soTimeout = 0

            val isTls = port == 443
            val sin   = srv.getInputStream()
            val sout  = srv.getOutputStream()

            // Client→Server with DPI bypass on first TLS packet
            val c2s = Thread({
                try {
                    val rbuf = ByteArray(32768)
                    var first = true
                    while (true) {
                        val n = cin.read(rbuf); if (n == -1) break
                        val data = rbuf.copyOf(n)
                        if (first && isTls && n > mode.splitPos + 1) {
                            applyBypass(sout, data)
                        } else {
                            sout.write(data); sout.flush()
                        }
                        first = false
                    }
                } catch (_: Exception) {
                } finally { try { srv.shutdownOutput() } catch (_: Exception) {} }
            }, "c2s").also { it.isDaemon = true; it.start() }

            // Server→Client
            try {
                val rbuf = ByteArray(32768)
                while (true) { val n = sin.read(rbuf); if (n == -1) break; cout.write(rbuf, 0, n); cout.flush() }
            } catch (_: Exception) {
            } finally { c2s.interrupt(); client.close(); srv.close() }

        } catch (e: Exception) {
            Log.d(TAG, "handle: ${e.message}")
        } finally {
            try { client.close() } catch (_: Exception) {}
        }
    }

    /**
     * Novel bypass: SNI Reflection + Split
     *
     * Standard split just fragments the TLS ClientHello.
     * Our enhanced version first sends a "reflection" record — a complete
     * TLS ClientHello with an allowed domain SNI (yandex.ru) at the correct
     * byte position, followed by the real ClientHello fragmented.
     *
     * DPI inspects the first TLS record, sees an approved SNI, marks the
     * connection as allowed. The server ignores the garbage record (it has
     * an invalid handshake transcript hash) and falls back to the next
     * valid ClientHello. Works because most DPI systems are stateless after
     * the first approved packet.
     *
     * For non-SNI-filtered connections: standard TCP split is applied.
     */
    private fun applyBypass(out: OutputStream, data: ByteArray) {
        val pos = mode.splitPos.coerceIn(1, data.size - 1)
        when (mode) {
            BypassMode.SPLIT_2, BypassMode.SPLIT_1, BypassMode.SPLIT_40 -> {
                // SNI Reflection: inject decoy ClientHello with allowed SNI before split
                val decoy = buildDecoyClientHello(data, "vc.ru")
                if (decoy != null) { out.write(decoy); out.flush(); Thread.sleep(1) }
                // Then send real data split
                out.write(data, 0, pos);               out.flush()
                Thread.sleep(1)
                out.write(data, pos, data.size - pos); out.flush()
            }
            BypassMode.FAKE -> {
                val fake = data.copyOf()
                for (i in pos until minOf(pos + 16, fake.size))
                    fake[i] = (fake[i].toInt() xor 0xFF).toByte()
                out.write(fake, 0, pos); out.flush()
                Thread.sleep(1)
                out.write(data); out.flush()
            }
            BypassMode.DISORDER -> {
                out.write(data, pos, data.size - pos); out.flush()
                Thread.sleep(1)
                out.write(data, 0, pos); out.flush()
            }
            BypassMode.NONE -> { out.write(data); out.flush() }
        }
    }

    /**
     * Builds a fake TLS ClientHello that looks valid to DPI but will be
     * ignored by the real server. We copy the structure of the original
     * ClientHello but replace the SNI with an allowed domain and corrupt
     * the random bytes so the server rejects it gracefully.
     */
    private fun buildDecoyClientHello(original: ByteArray, fakeSni: String): ByteArray? {
        // Only works if original is a TLS record (starts with 0x16)
        if (original.size < 9 || original[0] != 0x16.toByte()) return null
        try {
            val buf = original.copyOf()
            // Corrupt the 32-byte random field (offset 6+4+2 = 11 in handshake, or 5+4+2=11 from record)
            // TLS record (5) + Handshake header (4) + version (2) = offset 11 for random
            val randomOffset = 11
            if (buf.size > randomOffset + 32) {
                for (i in randomOffset until randomOffset + 32) buf[i] = (i * 7).toByte()
            }
            // Try to replace SNI in the copy
            replaceSni(buf, fakeSni)
            return buf
        } catch (_: Exception) { return null }
    }

    /** Best-effort SNI replacement in a TLS ClientHello byte array */
    private fun replaceSni(buf: ByteArray, newSni: String) {
        // Find SNI extension (type 0x00 0x00) and replace hostname
        var i = 5 + 4  // skip TLS record header + handshake header
        if (i + 2 >= buf.size) return
        i += 2 + 32    // skip version + random
        if (i >= buf.size) return
        val sessLen = buf[i].toInt() and 0xFF; i += 1 + sessLen
        if (i + 2 >= buf.size) return
        val cipherLen = ((buf[i].toInt() and 0xFF) shl 8) or (buf[i+1].toInt() and 0xFF); i += 2 + cipherLen
        if (i >= buf.size) return
        val compLen = buf[i].toInt() and 0xFF; i += 1 + compLen
        if (i + 2 >= buf.size) return
        i += 2  // skip extensions length
        while (i + 4 < buf.size) {
            val extType = ((buf[i].toInt() and 0xFF) shl 8) or (buf[i+1].toInt() and 0xFF)
            val extLen  = ((buf[i+2].toInt() and 0xFF) shl 8) or (buf[i+3].toInt() and 0xFF)
            if (extType == 0 && i + 4 + extLen <= buf.size) {
                // Found SNI extension — replace hostname bytes if same length fits
                val nameOff = i + 4 + 2 + 1 + 2   // listLen + type + nameLen
                val nameLen = ((buf[nameOff-2].toInt() and 0xFF) shl 8) or (buf[nameOff-1].toInt() and 0xFF)
                val newBytes = newSni.toByteArray(Charsets.US_ASCII)
                if (newBytes.size <= nameLen && nameOff + newBytes.size <= buf.size) {
                    newBytes.copyInto(buf, nameOff)
                    // Pad remainder with spaces
                    for (p in nameOff + newBytes.size until nameOff + nameLen) buf[p] = 0x20
                }
                return
            }
            i += 4 + extLen
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// PACKET BUILDING UTILITIES
// ═══════════════════════════════════════════════════════════════════════════

private fun checksum(buf: ByteArray, off: Int = 0, len: Int = buf.size): Int {
    var s = 0L; var i = off; val end = off + len
    while (i < end - 1) { s += ((buf[i].toInt() and 0xFF) shl 8) or (buf[i+1].toInt() and 0xFF); i += 2 }
    if (i < end) s += (buf[i].toInt() and 0xFF) shl 8
    while (s shr 16 != 0L) s = (s and 0xFFFF) + (s shr 16)
    return (s.inv() and 0xFFFF).toInt()
}

private fun buildTcpPacket(
    src: ByteArray, dst: ByteArray, sp: Int, dp: Int,
    seq: Long, ack: Long, flags: Int, payload: ByteArray
): ByteArray {
    val tl = 20 + payload.size; val tot = 20 + tl
    val b = ByteArray(tot)
    b[0]=0x45.toByte(); b[2]=(tot shr 8).toByte(); b[3]=tot.toByte()
    b[6]=0x40.toByte(); b[8]=64; b[9]=6
    src.copyInto(b,12); dst.copyInto(b,16)
    val ic=checksum(b,0,20); b[10]=(ic shr 8).toByte(); b[11]=ic.toByte()
    b[20]=(sp shr 8).toByte(); b[21]=sp.toByte(); b[22]=(dp shr 8).toByte(); b[23]=dp.toByte()
    b[24]=(seq shr 24).toByte();b[25]=(seq shr 16).toByte();b[26]=(seq shr 8).toByte();b[27]=seq.toByte()
    b[28]=(ack shr 24).toByte();b[29]=(ack shr 16).toByte();b[30]=(ack shr 8).toByte();b[31]=ack.toByte()
    b[32]=0x50.toByte(); b[33]=flags.toByte(); b[34]=0xFF.toByte(); b[35]=0xFF.toByte()
    payload.copyInto(b,40)
    val ph=ByteArray(12+tl); src.copyInto(ph,0); dst.copyInto(ph,4)
    ph[9]=6; ph[10]=(tl shr 8).toByte(); ph[11]=tl.toByte(); b.copyInto(ph,12,20,20+tl)
    val tc=checksum(ph); b[36]=(tc shr 8).toByte(); b[37]=tc.toByte()
    return b
}

private fun buildUdpPacket(src: ByteArray, dst: ByteArray, sp: Int, dp: Int, payload: ByteArray): ByteArray {
    val ul = 8 + payload.size; val tot = 20 + ul
    val b = ByteArray(tot)
    b[0]=0x45.toByte(); b[2]=(tot shr 8).toByte(); b[3]=tot.toByte()
    b[6]=0x40.toByte(); b[8]=64; b[9]=17
    src.copyInto(b,12); dst.copyInto(b,16)
    val ic=checksum(b,0,20); b[10]=(ic shr 8).toByte(); b[11]=ic.toByte()
    b[20]=(sp shr 8).toByte();b[21]=sp.toByte();b[22]=(dp shr 8).toByte();b[23]=dp.toByte()
    b[24]=(ul shr 8).toByte();b[25]=ul.toByte()
    payload.copyInto(b,28)
    return b
}

private fun readU32(b: ByteArray, off: Int): Long =
    ((b[off].toLong() and 0xFF) shl 24) or ((b[off+1].toLong() and 0xFF) shl 16) or
    ((b[off+2].toLong() and 0xFF) shl 8) or (b[off+3].toLong() and 0xFF)

private fun readU16(inp: InputStream): Int {
    val b = ByteArray(2); readFully(inp, b)
    return ((b[0].toInt() and 0xFF) shl 8) or (b[1].toInt() and 0xFF)
}

private fun readFully(inp: InputStream, buf: ByteArray) {
    var off = 0
    while (off < buf.size) {
        val n = inp.read(buf, off, buf.size - off)
        if (n == -1) throw java.io.EOFException()
        off += n
    }
}

private fun ipStr(b: ByteArray) =
    try { InetAddress.getByAddress(b).hostAddress ?: "?" } catch (_: Exception) { "?" }
