package com.daniil.zapret.core

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import com.daniil.zapret.dpi.BypassMode
import com.daniil.zapret.ui.MainActivity
import com.daniil.zapret.whitelist.WhitelistManager
import kotlinx.coroutines.*
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean

private const val TAG = "ZapretVpnService"
private const val CH  = "zapret"
private const val NID = 1

const val ACTION_START  = "com.daniil.zapret.START"
const val ACTION_STOP   = "com.daniil.zapret.STOP"
const val EXTRA_MODE    = "mode"
const val EXTRA_PKGS    = "pkgs"      // comma-separated allowed packages (empty = all)
const val EXTRA_PKG_EXCLUDE = "pkgs_exclude"
const val EXTRA_DOH = "doh" // comma-separated excluded packages

class ZapretVpnService : VpnService() {

    private var tun: ParcelFileDescriptor? = null
    private var router: Router? = null
    private val running = AtomicBoolean(false)
    private var readJob: Job? = null
    private val readScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    companion object {
        @Volatile var isRunning = false
        @Volatile var currentMode = BypassMode.SPLIT_2
        @Volatile var dohActive = true
        @Volatile var startMs = 0L
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stop(); return START_NOT_STICKY }
        if (intent?.action == ACTION_START) {
            val modeId = intent.getStringExtra(EXTRA_MODE) ?: "split2"
            val allowedPkgs = intent.getStringExtra(EXTRA_PKGS)
                ?.split(",")?.filter { it.isNotBlank() } ?: emptyList()
            val excludedPkgs = intent.getStringExtra(EXTRA_PKG_EXCLUDE)
                ?.split(",")?.filter { it.isNotBlank() } ?: emptyList()
            start(BypassMode.byId(modeId), allowedPkgs, excludedPkgs)
        }
        return START_STICKY
    }

    private fun start(mode: BypassMode, allowedPkgs: List<String>, excludedPkgs: List<String>) {
        if (running.get()) stop()
        currentMode = mode

        val builder = Builder()
            .setSession("Zapret")
            .addAddress("10.33.0.1", 32)
            .addRoute("0.0.0.0", 0)           // all IPv4
            .addRoute("::", 0)                 // all IPv6 (will be ignored by our router)
            .addDnsServer("1.1.1.1")
            .addDnsServer("8.8.8.8")
            .setMtu(1500)
            .setBlocking(true)

        // Per-app filter
        allowedPkgs.forEach { pkg -> try { builder.addAllowedApplication(pkg) } catch (_: Exception) {} }
        excludedPkgs.forEach { pkg -> try { builder.addDisallowedApplication(pkg) } catch (_: Exception) {} }

        tun = builder.establish() ?: run { Log.e(TAG, "establish() returned null"); return }

        val whitelist = WhitelistManager(this)
        val tunOut = FileOutputStream(tun!!.fileDescriptor)
        router = Router(this, tunOut, whitelist, mode).also { it.start() }

        running.set(true)
        isRunning = true
        startTimeMs = System.currentTimeMillis()
        startMs = startTimeMs
        startForeground(NID, buildNotif(mode.title))
        sendBroadcast(Intent("com.daniil.zapret.STATUS"))

        readJob = readScope.launch { readLoop() }
        Log.i(TAG, "Started: ${mode.title}")
    }

    private suspend fun readLoop() {
        val inp = FileInputStream(tun!!.fileDescriptor)
        val buf = ByteArray(32767)
        while (running.get()) {
            val n = withContext(Dispatchers.IO) { try { inp.read(buf) } catch (_: Exception) { -1 } }
            if (n <= 0) { delay(1); continue }
            router?.handlePacket(buf, n)
        }
    }

    private fun stop() {
        running.set(false)
        isRunning = false
        readJob?.cancel()
        router?.close(); router = null
        try { tun?.close() } catch (_: Exception) {}; tun = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        sendBroadcast(Intent("com.daniil.zapret.STATUS"))
        Log.i(TAG, "Stopped")
    }

    override fun onRevoke() { stop() }
    override fun onDestroy() { stop(); readScope.cancel(); super.onDestroy() }

    fun uptimeSeconds() = if (isRunning) (System.currentTimeMillis() - startMs) / 1000 else 0L

    private fun buildNotif(modeName: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CH, "Zapret", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val stopPi = PendingIntent.getService(this, 0,
            Intent(this, ZapretVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE)
        val openPi = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CH)
            .setContentTitle("Zapret активен")
            .setContentText(modeName)
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .setContentIntent(openPi)
            .addAction(Notification.Action.Builder(
                android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_media_pause),
                "Стоп", stopPi).build())
            .setOngoing(true).build()
    }
}
