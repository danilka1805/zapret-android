package com.daniil.zapret.core

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import com.daniil.zapret.dpi.BypassMode
import com.daniil.zapret.ui.MainActivity
import java.io.File

private const val TAG        = "ZapretVpnService"
private const val CH         = "zapret"
private const val NID        = 1
private const val SOCKS_PORT = 2080

const val ACTION_START      = "com.daniil.zapret.START"
const val ACTION_STOP       = "com.daniil.zapret.STOP"
const val EXTRA_MODE        = "mode"
const val EXTRA_PKGS        = "pkgs"
const val EXTRA_PKG_EXCLUDE = "pkgs_exclude"

class ZapretVpnService : VpnService() {

    private var tun: ParcelFileDescriptor? = null
    private var socks5: DpiSocks5Server?   = null
    private var tun2socksProcess: Process? = null

    companion object {
        @Volatile var isRunning   = false
        @Volatile var currentMode = BypassMode.SPLIT_2
        @Volatile var startMs     = 0L
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP)  { stop(); return START_NOT_STICKY }
        if (intent?.action == ACTION_START) {
            val mode     = BypassMode.byId(intent.getStringExtra(EXTRA_MODE) ?: "split2")
            val allowed  = intent.getStringExtra(EXTRA_PKGS)
                ?.split(",")?.filter { it.isNotBlank() } ?: emptyList()
            val excluded = intent.getStringExtra(EXTRA_PKG_EXCLUDE)
                ?.split(",")?.filter { it.isNotBlank() } ?: emptyList()
            start(mode, allowed, excluded)
        }
        return START_STICKY
    }

    private fun start(mode: BypassMode, allowed: List<String>, excluded: List<String>) {
        stop()
        currentMode = mode

        // 1. Start SOCKS5 proxy with DPI bypass on localhost
        socks5 = DpiSocks5Server(this, mode, SOCKS_PORT).also { it.start() }

        // 2. Build TUN
        val builder = Builder()
            .setSession("Zapret")
            .addAddress("10.33.0.1", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1")
            .addDnsServer("8.8.8.8")
            .setMtu(1500)
            .setBlocking(false)

        allowed.forEach  { try { builder.addAllowedApplication(it)    } catch (_: Exception) {} }
        excluded.forEach { try { builder.addDisallowedApplication(it) } catch (_: Exception) {} }

        tun = builder.establish() ?: run {
            Log.e(TAG, "establish() null"); socks5?.stop(); return
        }

        // 3. Start tun2socks binary
        val fd = tun!!.fd
        startTun2Socks(fd)

        isRunning = true
        startMs   = System.currentTimeMillis()
        startForeground(NID, buildNotif(mode.title))
        sendBroadcast(Intent("com.daniil.zapret.STATUS"))
        Log.i(TAG, "Started: ${mode.title} fd=$fd")
    }

    private fun startTun2Socks(tunFd: Int) {
        // Extract tun2socks binary from assets to internal storage
        val binary = extractBinary() ?: run {
            Log.e(TAG, "tun2socks binary not found in assets")
            return
        }

        // Run tun2socks:
        // --device fd://N  — use our TUN fd
        // --proxy socks5://127.0.0.1:PORT — forward to our SOCKS5 proxy
        // --tcp-rcvbuf/sndbuf — tuning
        val cmd = arrayOf(
            binary.absolutePath,
            "--device",  "fd://$tunFd",
            "--proxy",   "socks5://127.0.0.1:$SOCKS_PORT",
            "--loglevel", "silent"
        )
        Log.i(TAG, "Starting tun2socks: ${cmd.joinToString(" ")}")

        tun2socksProcess = ProcessBuilder(*cmd)
            .redirectErrorStream(true)
            .start()

        // Log output in background
        Thread({
            tun2socksProcess?.inputStream?.bufferedReader()?.forEachLine { line ->
                Log.d(TAG, "tun2socks: $line")
            }
        }, "t2s-log").also { it.isDaemon = true; it.start() }
    }

    private fun extractBinary(): File? {
        val abi = android.os.Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64-v8a"
        // Map ABI to asset name
        val assetName = when {
            abi.startsWith("arm64")  -> "tun2socks-arm64"
            abi.startsWith("armeabi") -> "tun2socks-arm"
            abi.startsWith("x86_64") -> "tun2socks-x86_64"
            abi.startsWith("x86")    -> "tun2socks-x86"
            else                      -> "tun2socks-arm64"
        }

        val dest = File(filesDir, "tun2socks")

        // Copy from assets if not already extracted
        if (!dest.exists() || dest.length() == 0L) {
            try {
                assets.open(assetName).use { inp ->
                    dest.outputStream().use { out -> inp.copyTo(out) }
                }
                dest.setExecutable(true)
                Log.i(TAG, "Extracted $assetName (${dest.length()} bytes)")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to extract $assetName: ${e.message}")
                return null
            }
        }
        return if (dest.canExecute()) dest else null
    }

    private fun stop() {
        tun2socksProcess?.destroy()
        tun2socksProcess = null
        socks5?.stop(); socks5 = null
        try { tun?.close() } catch (_: Exception) {}
        tun       = null
        isRunning = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        sendBroadcast(Intent("com.daniil.zapret.STATUS"))
    }

    override fun onRevoke()  { stop() }
    override fun onDestroy() { stop(); super.onDestroy() }

    private fun buildNotif(modeName: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null)
            nm.createNotificationChannel(
                NotificationChannel(CH, "Zapret", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(this, 0,
            Intent(this, ZapretVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE)
        val openPi = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CH)
            .setContentTitle("Zapret — $modeName")
            .setContentText("DPI обход активен")
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .setContentIntent(openPi)
            .addAction(Notification.Action.Builder(
                android.graphics.drawable.Icon.createWithResource(
                    this, android.R.drawable.ic_media_pause), "Стоп", stopPi).build())
            .setOngoing(true).build()
    }
}
