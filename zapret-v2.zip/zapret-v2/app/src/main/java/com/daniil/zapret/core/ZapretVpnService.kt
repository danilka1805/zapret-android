package com.daniil.zapret.core

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import com.daniil.zapret.dpi.BypassMode
import com.daniil.zapret.ui.MainActivity
import kotlinx.coroutines.*
import java.io.FileInputStream
import java.io.FileOutputStream

private const val TAG        = "ZapretVpnService"
private const val CH         = "zapret"
private const val NID        = 1
private const val SOCKS_PORT = 2080

const val ACTION_START      = "com.daniil.zapret.START"
const val ACTION_STOP       = "com.daniil.zapret.STOP"
const val EXTRA_MODE        = "mode"
const val EXTRA_PKGS        = "pkgs"
const val EXTRA_PKG_EXCLUDE = "pkgs_exclude"

class ZapretVpnService : VpnService() {

    private var tun: ParcelFileDescriptor? = null
    private var socks5: DpiSocks5Server?   = null
    private var router: PacketRouter?      = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    companion object {
        @Volatile var isRunning   = false
        @Volatile var currentMode = BypassMode.SPLIT_2
        @Volatile var startMs     = 0L
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP)  { stop(); return START_NOT_STICKY }
        if (intent?.action == ACTION_START) {
            val mode     = BypassMode.byId(intent.getStringExtra(EXTRA_MODE) ?: "split2")
            val allowed  = intent.getStringExtra(EXTRA_PKGS)
                ?.split(",")?.filter { it.isNotBlank() } ?: emptyList()
            val excluded = intent.getStringExtra(EXTRA_PKG_EXCLUDE)
                ?.split(",")?.filter { it.isNotBlank() } ?: emptyList()
            start(mode, allowed, excluded)
        }
        return START_STICKY
    }

    private fun start(mode: BypassMode, allowed: List<String>, excluded: List<String>) {
        try {
            stop()
            currentMode = mode

            // 1. Start local SOCKS5 proxy
            socks5 = DpiSocks5Server(this, mode, SOCKS_PORT)
            socks5!!.start()
            Log.i(TAG, "SOCKS5 started on :$SOCKS_PORT")

            // 2. Build TUN — BLOCKING mode so reads don't need polling
            val builder = Builder()
                .setSession("Zapret")
                .addAddress("10.33.0.1", 32)
                .addRoute("0.0.0.0", 0)
                .addDnsServer("1.1.1.1")
                .addDnsServer("8.8.8.8")
                .setMtu(1500)
                .setBlocking(true)

            allowed.forEach  { pkg -> try { builder.addAllowedApplication(pkg)    } catch (e: Exception) { Log.w(TAG, "addAllowed $pkg: $e") } }
            excluded.forEach { pkg -> try { builder.addDisallowedApplication(pkg) } catch (e: Exception) { Log.w(TAG, "addExcluded $pkg: $e") } }

            tun = builder.establish()
            if (tun == null) {
                Log.e(TAG, "establish() returned null — VPN permission not granted?")
                socks5?.stop()
                return
            }
            Log.i(TAG, "TUN established fd=${tun!!.fd}")

            // 3. Start packet router: reads from TUN, forwards to SOCKS5
            val tunIn  = FileInputStream(tun!!.fileDescriptor)
            val tunOut = FileOutputStream(tun!!.fileDescriptor)
            router = PacketRouter(this, tunIn, tunOut, SOCKS_PORT, scope)
            router!!.start()

            isRunning = true
            startMs   = System.currentTimeMillis()
            startForeground(NID, buildNotif(mode.title))
            sendBroadcast(Intent("com.daniil.zapret.STATUS"))
            Log.i(TAG, "VPN started: ${mode.title}")

        } catch (e: Exception) {
            Log.e(TAG, "start() crashed: $e")
            stop()
        }
    }

    private fun stop() {
        try {
            router?.stop();  router = null
            socks5?.stop();  socks5 = null
            tun?.close();    tun    = null
            isRunning = false
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            sendBroadcast(Intent("com.daniil.zapret.STATUS"))
            Log.i(TAG, "VPN stopped")
        } catch (e: Exception) {
            Log.e(TAG, "stop() error: $e")
        }
    }

    override fun onRevoke()  { stop() }
    override fun onDestroy() { stop(); scope.cancel(); super.onDestroy() }

    private fun buildNotif(modeName: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null)
            nm.createNotificationChannel(
                NotificationChannel(CH, "Zapret", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(this, 0,
            Intent(this, ZapretVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE)
        val openPi = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CH)
            .setContentTitle("Zapret — $modeName")
            .setContentText("DPI обход активен")
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .setContentIntent(openPi)
            .addAction(Notification.Action.Builder(
                android.graphics.drawable.Icon.createWithResource(
                    this, android.R.drawable.ic_media_pause), "Стоп", stopPi).build())
            .setOngoing(true).build()
    }
}
