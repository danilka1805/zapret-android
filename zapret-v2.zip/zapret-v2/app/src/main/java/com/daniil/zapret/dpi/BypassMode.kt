package com.daniil.zapret.dpi

enum class BypassMode(
    val id: String,
    val title: String,
    val desc: String,
    val splitPos: Int = 2
) {
    SPLIT_2 ("split2",   "Split (pos 2)",  "Делит TLS ClientHello на 2-м байте — работает у большинства провайдеров",      2),
    SPLIT_1 ("split1",   "Split (pos 1)",  "Делит на 1-м байте — агрессивнее",                                              1),
    SPLIT_40("split40",  "Split (pos 40)", "Делит после заголовка TLS — для некоторых провайдеров",                         40),
    FAKE    ("fake",     "Fake + Real",    "Сначала мусорный пакет, потом настоящий TLS ClientHello",                       2),
    DISORDER("disorder", "Disorder",       "Отправляет части в обратном порядке",                                            2),
    NONE    ("none",     "Без обхода",     "Без изменений — для тестирования",                                              2);

    companion object {
        fun byId(id: String) = entries.find { it.id == id } ?: SPLIT_2
    }
}
