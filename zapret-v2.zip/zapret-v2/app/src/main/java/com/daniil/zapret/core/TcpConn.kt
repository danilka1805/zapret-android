package com.daniil.zapret.core

import android.net.VpnService
import android.util.Log
import com.daniil.zapret.dpi.BypassMode
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

private const val TAG = "TcpConn"

enum class ConnState { HANDSHAKE, OPEN, CLOSED }

class TcpConn(
    private val vpn: VpnService,
    private val tunWrite: suspend (ByteArray) -> Unit,
    val clientIp: ByteArray,
    val serverIp: ByteArray,
    val clientPort: Int,
    val serverPort: Int,
    clientIsn: Long,
    private val bypass: BypassMode,
    private val scope: CoroutineScope
) {
    var state = ConnState.HANDSHAKE

    // Sequence number we send to client (starts at our ISN, increments with each byte)
    private val mySeq = AtomicLong(0x12345678L)
    // Next sequence we expect from client (set after SYN, advanced by each payload)
    @Volatile private var myAck = (clientIsn + 1L) and 0xFFFFFFFFL
    // Mutex so two coroutines don't write to TUN simultaneously for this conn
    private val writeLock = Mutex()

    private val socket = Socket()
    private val queue  = Channel<ByteArray>(Channel.UNLIMITED)
    private val dead   = AtomicBoolean(false)

    fun feedData(payload: ByteArray) { if (!dead.get()) queue.trySend(payload) }
    fun feedFin()  { queue.close(); dead.set(true) }
    fun feedRst()  { close() }
    fun advanceAck(seq: Long, size: Int) {
        myAck = ((seq and 0xFFFFFFFFL) + size.toLong()) and 0xFFFFFFFFL
    }

    fun start() {
        scope.launch(Dispatchers.IO) { connectAndRelay() }
    }

    private suspend fun connectAndRelay() {
        // ── 1. Connect to real server FIRST ────────────────────────────
        val protected = vpn.protect(socket)
        if (!protected) Log.w(TAG, "protect() returned false for $clientPort")
        try {
            withContext(Dispatchers.IO) {
                socket.connect(
                    InetSocketAddress(InetAddress.getByAddress(serverIp), serverPort),
                    6_000
                )
                socket.tcpNoDelay = true
            }
        } catch (e: Exception) {
            Log.w(TAG, "connect failed $clientPort->$serverPort: ${e.message}")
            state = ConnState.CLOSED
            try { socket.close() } catch (_: Exception) {}
            return
        }

        // ── 2. Send SYN-ACK to client ───────────────────────────────────
        state = ConnState.OPEN
        tun(Packet.SYN or Packet.ACK, ByteArray(0))
        mySeq.incrementAndGet()   // SYN occupies 1 seq number
        Log.d(TAG, "ready $clientPort->$serverPort bypass=${bypass.id}")

        // ── 3. Start server→client reader in parallel ───────────────────
        scope.launch(Dispatchers.IO) { readServer() }

        // ── 4. This coroutine: relay client→server ───────────────────────
        writeServer()
    }

    // ─── client → server ─────────────────────────────────────────────────

    private suspend fun writeServer() {
        var first = true
        try {
            val out = socket.getOutputStream()
            for (data in queue) {
                if (data.isEmpty()) break
                withContext(Dispatchers.IO) {
                    if (first && bypass != BypassMode.NONE && data.size > bypass.splitPos + 1) {
                        doBypass(out, data)
                    } else {
                        out.write(data); out.flush()
                    }
                }
                first = false
                tun(Packet.ACK, ByteArray(0))   // ACK client's data
            }
        } catch (e: Exception) {
            Log.d(TAG, "c2s end $clientPort: ${e.message}")
        } finally { close() }
    }

    private fun doBypass(out: OutputStream, data: ByteArray) {
        val pos = bypass.splitPos.coerceIn(1, data.size - 1)
        when (bypass) {
            BypassMode.SPLIT_2, BypassMode.SPLIT_1, BypassMode.SPLIT_40 -> {
                out.write(data, 0, pos);               out.flush()
                Thread.sleep(1)
                out.write(data, pos, data.size - pos); out.flush()
            }
            BypassMode.FAKE -> {
                val fake = data.copyOf()
                for (i in pos until minOf(pos + 16, fake.size))
                    fake[i] = (fake[i].toInt() xor 0xFF).toByte()
                out.write(fake, 0, pos); out.flush()
                Thread.sleep(1)
                out.write(data);         out.flush()
            }
            BypassMode.DISORDER -> {
                out.write(data, pos, data.size - pos); out.flush()
                Thread.sleep(1)
                out.write(data, 0, pos);               out.flush()
            }
            BypassMode.NONE -> { out.write(data); out.flush() }
        }
    }

    // ─── server → client ─────────────────────────────────────────────────

    private suspend fun readServer() {
        try {
            val inp = socket.getInputStream()
            val buf = ByteArray(1440)  // MTU-safe chunk size
            while (!dead.get()) {
                val n = withContext(Dispatchers.IO) { inp.read(buf) }
                if (n == -1) break
                tun(Packet.PSH or Packet.ACK, buf.copyOf(n))
            }
        } catch (e: Exception) {
            Log.d(TAG, "s2c end $clientPort: ${e.message}")
        } finally {
            if (!dead.get()) {
                try { tun(Packet.FIN or Packet.ACK, ByteArray(0)) } catch (_: Exception) {}
            }
            close()
        }
    }

    // ─── Build and write TCP packet to TUN ───────────────────────────────

    private suspend fun tun(flags: Int, payload: ByteArray) {
        writeLock.withLock {
            val seq = mySeq.get() and 0xFFFFFFFFL
            val ack = myAck
            val pkt = Packet.buildTcp(
                srcIp   = serverIp,  dstIp   = clientIp,
                srcPort = serverPort, dstPort = clientPort,
                seq = seq, ack = ack, flags = flags, payload = payload
            )
            tunWrite(pkt)
            if (payload.isNotEmpty()) mySeq.addAndGet(payload.size.toLong())
            if (flags and Packet.FIN != 0) mySeq.incrementAndGet()
        }
    }

    fun close() {
        if (dead.compareAndSet(false, true)) {
            try { socket.close() } catch (_: Exception) {}
            queue.close()
            state = ConnState.CLOSED
        }
    }

    val key get() = "$clientPort→${Packet.ipStr(serverIp)}:$serverPort"
}
