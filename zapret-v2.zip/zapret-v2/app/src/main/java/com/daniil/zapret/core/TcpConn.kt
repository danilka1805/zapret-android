package com.daniil.zapret.core

import android.net.VpnService
import android.util.Log
import com.daniil.zapret.dpi.BypassMode
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

private const val TAG = "TcpConn"

enum class ConnState { HANDSHAKE, OPEN, CLOSED }

class TcpConn(
    private val vpn: VpnService,
    private val tunWrite: suspend (ByteArray) -> Unit,
    val clientIp: ByteArray,
    val serverIp: ByteArray,
    val clientPort: Int,
    val serverPort: Int,
    clientIsn: Long,
    private val bypass: BypassMode,
    private val scope: CoroutineScope
) {
    var state = ConnState.HANDSHAKE

    private val seqAtomic = AtomicLong(System.nanoTime() and 0xFFFFFFFFL)
    @Volatile private var myAck = clientIsn + 1
    private val writeMutex = Mutex()

    private val socket = Socket()
    private val toServer = Channel<ByteArray>(Channel.UNLIMITED)
    private val dead = AtomicBoolean(false)

    fun feedData(payload: ByteArray) { if (!dead.get()) toServer.trySend(payload) }
    fun feedFin()  { toServer.close(); dead.set(true) }
    fun feedRst()  { close() }
    fun advanceAck(seq: Long) { myAck = seq + 1 }

    fun start() {
        scope.launch(Dispatchers.IO) {
            synAck()
            seqAtomic.incrementAndGet()
            connect()
        }
    }

    private suspend fun connect() {
        try {
            val protected = vpn.protect(socket)
            if (!protected) Log.w(TAG, "protect() failed for $clientPort->$serverPort")
            withContext(Dispatchers.IO) {
                socket.connect(
                    InetSocketAddress(InetAddress.getByAddress(serverIp), serverPort),
                    8_000
                )
                socket.tcpNoDelay = true
            }
            state = ConnState.OPEN
            scope.launch(Dispatchers.IO) { readFromServer() }
            writeToServer()
        } catch (e: Exception) {
            Log.d(TAG, "Connect $clientPort->$serverPort: ${e.message}")
            sendRst(); close()
        }
    }

    private suspend fun writeToServer() {
        var first = true
        try {
            val out = socket.getOutputStream()
            for (data in toServer) {
                if (data.isEmpty()) break
                withContext(Dispatchers.IO) {
                    if (first && bypass != BypassMode.NONE && data.size > bypass.splitPos + 1) {
                        applyBypass(out, data)
                    } else {
                        out.write(data); out.flush()
                    }
                }
                first = false
                ack()
            }
        } catch (_: Exception) {
        } finally { close() }
    }

    private fun applyBypass(out: java.io.OutputStream, data: ByteArray) {
        val pos = bypass.splitPos.coerceIn(1, data.size - 1)
        when (bypass) {
            BypassMode.SPLIT_2, BypassMode.SPLIT_1, BypassMode.SPLIT_40 -> {
                // Fragment TLS ClientHello — DPI sees only first fragment, not full SNI
                out.write(data, 0, pos); out.flush()
                Thread.sleep(1)
                out.write(data, pos, data.size - pos); out.flush()
            }
            BypassMode.FAKE -> {
                // Send first fragment with wrong content, then correct fragment
                // This confuses stateful DPI that tracks sequence numbers
                val fake = data.copyOf()
                // Corrupt the SNI bytes in the fake (offset ~5+2+32+1+session+2+ciphers+1+comp+2 ≈ vary)
                // Simple approach: flip bytes in middle of fake
                for (i in pos until minOf(pos + 16, fake.size)) fake[i] = (fake[i].toInt() xor 0xFF).toByte()
                out.write(fake, 0, pos); out.flush()
                // Small delay so server processes first packet
                Thread.sleep(1)
                // Now send real data
                out.write(data); out.flush()
            }
            BypassMode.DISORDER -> {
                // Send second part first — DPI can't assemble the SNI
                // (without raw socket TTL tricks, this is best we can do on Android)
                out.write(data, pos, data.size - pos); out.flush()
                Thread.sleep(1)
                out.write(data, 0, pos); out.flush()
            }
            BypassMode.NONE -> { out.write(data); out.flush() }
        }
    }

    private suspend fun readFromServer() {
        try {
            val inp = socket.getInputStream()
            // 1440 = 1500 MTU - 20 IP header - 20 TCP header - 20 safety margin
            // CRITICAL: larger reads create oversized IP packets that TUN silently drops
            val buf = ByteArray(1440)
            while (!dead.get()) {
                val n = withContext(Dispatchers.IO) { inp.read(buf) }
                if (n == -1) break
                pushToClient(Packet.PSH or Packet.ACK, buf.copyOf(n))
            }
            pushToClient(Packet.FIN or Packet.ACK, ByteArray(0))
            seqAtomic.incrementAndGet()
        } catch (_: Exception) {
        } finally { close() }
    }

    private suspend fun synAck() = pushToClient(Packet.SYN or Packet.ACK, ByteArray(0))
    private suspend fun ack()    = pushToClient(Packet.ACK, ByteArray(0))

    private suspend fun pushToClient(flags: Int, payload: ByteArray) {
        writeMutex.withLock {
            val seq = seqAtomic.get()
            val pkt = Packet.buildTcp(
                srcIp = serverIp, dstIp = clientIp,
                srcPort = serverPort, dstPort = clientPort,
                seq = seq, ack = myAck, flags = flags, payload = payload
            )
            tunWrite(pkt)
            if (payload.isNotEmpty()) seqAtomic.addAndGet(payload.size.toLong())
        }
    }

    private fun sendRst() {
        scope.launch {
            try {
                val pkt = Packet.buildTcp(
                    serverIp, clientIp, serverPort, clientPort,
                    seqAtomic.get(), myAck, Packet.RST
                )
                tunWrite(pkt)
            } catch (_: Exception) {}
        }
    }

    fun close() {
        if (dead.compareAndSet(false, true)) {
            try { socket.close() } catch (_: Exception) {}
            toServer.close()
            state = ConnState.CLOSED
        }
    }

    val key get() = "$clientPort-$serverPort-${Packet.ipStr(serverIp)}"
}
