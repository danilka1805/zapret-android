package com.daniil.zapret.core

import android.net.VpnService
import android.util.Log
import com.daniil.zapret.dpi.BypassMode
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

private const val TAG = "TcpConn"

enum class ConnState { HANDSHAKE, OPEN, CLOSED }

class TcpConn(
    private val vpn: VpnService,
    private val tunWrite: suspend (ByteArray) -> Unit,
    val clientIp: ByteArray,
    val serverIp: ByteArray,
    val clientPort: Int,
    val serverPort: Int,
    clientIsn: Long,
    private val bypass: BypassMode,
    private val scope: CoroutineScope
) {
    var state = ConnState.HANDSHAKE

    // Our sequence counter and ack pointer
    private val mySeq = AtomicLong(0x01020304L)  // simple fixed ISN for debugging
    @Volatile private var myAck = (clientIsn + 1L) and 0xFFFFFFFFL
    private val mu = Mutex()

    private val socket = Socket()
    private val clientQueue = Channel<ByteArray>(Channel.UNLIMITED)
    private val dead = AtomicBoolean(false)

    fun feedData(payload: ByteArray) { if (!dead.get()) clientQueue.trySend(payload) }
    fun feedFin()                   { clientQueue.close(); dead.set(true) }
    fun feedRst()                   { close() }
    fun advanceAck(seq: Long, size: Int) {
        myAck = ((seq and 0xFFFFFFFFL) + size) and 0xFFFFFFFFL
    }

    fun start() {
        scope.launch(Dispatchers.IO) {
            // Step 1: Connect to real server FIRST
            val ok = try {
                vpn.protect(socket)
                socket.soTimeout = 0
                socket.connect(
                    InetSocketAddress(InetAddress.getByAddress(serverIp), serverPort),
                    5_000
                )
                socket.tcpNoDelay = true
                true
            } catch (e: Exception) {
                Log.w(TAG, "connect failed $clientPort->$serverPort: ${e.message}")
                state = ConnState.CLOSED
                try { socket.close() } catch (_: Exception) {}
                false
            }
            if (!ok) return@launch

            // Step 2: Tell client we're ready (SYN-ACK)
            state = ConnState.OPEN
            writePkt(Packet.SYN or Packet.ACK, ByteArray(0))
            mySeq.incrementAndGet()   // SYN counts as 1 byte

            Log.d(TAG, "connected $clientPort->$serverPort, sent SYN-ACK")

            // Step 3: Start bidirectional relay
            scope.launch(Dispatchers.IO) { serverToClient() }
            clientToServer()
        }
    }

    // ─── client → server ────────────────────────────────────────────────

    private suspend fun clientToServer() {
        var first = true
        try {
            val out = socket.getOutputStream()
            for (data in clientQueue) {
                if (data.isEmpty()) break
                withContext(Dispatchers.IO) {
                    if (first && bypass != BypassMode.NONE && data.size > bypass.splitPos + 1) {
                        split(out, data)
                    } else {
                        out.write(data)
                        out.flush()
                    }
                }
                first = false
                // ACK the data we received
                writePkt(Packet.ACK, ByteArray(0))
            }
        } catch (e: Exception) {
            Log.d(TAG, "c2s done $clientPort: ${e.message}")
        } finally { close() }
    }

    private fun split(out: java.io.OutputStream, data: ByteArray) {
        val pos = bypass.splitPos.coerceIn(1, data.size - 1)
        when (bypass) {
            BypassMode.SPLIT_2, BypassMode.SPLIT_1, BypassMode.SPLIT_40 -> {
                out.write(data, 0, pos);             out.flush()
                Thread.sleep(1)
                out.write(data, pos, data.size - pos); out.flush()
            }
            BypassMode.FAKE -> {
                val fake = data.copyOf()
                for (i in pos until minOf(pos + 16, fake.size))
                    fake[i] = (fake[i].toInt() xor 0xFF).toByte()
                out.write(fake, 0, pos); out.flush()
                Thread.sleep(1)
                out.write(data);         out.flush()
            }
            BypassMode.DISORDER -> {
                out.write(data, pos, data.size - pos); out.flush()
                Thread.sleep(1)
                out.write(data, 0, pos);               out.flush()
            }
            BypassMode.NONE -> { out.write(data); out.flush() }
        }
    }

    // ─── server → client ────────────────────────────────────────────────

    private suspend fun serverToClient() {
        try {
            val inp = socket.getInputStream()
            // 1440 = MTU(1500) - IP(20) - TCP(20) - spare(20)
            val buf = ByteArray(1440)
            while (!dead.get()) {
                val n = withContext(Dispatchers.IO) { inp.read(buf) }
                if (n == -1) break
                writePkt(Packet.PSH or Packet.ACK, buf.copyOf(n))
            }
        } catch (e: Exception) {
            Log.d(TAG, "s2c done $clientPort: ${e.message}")
        } finally {
            if (!dead.get()) writePkt(Packet.FIN or Packet.ACK, ByteArray(0))
            close()
        }
    }

    // ─── write IP+TCP packet to TUN ─────────────────────────────────────

    private suspend fun writePkt(flags: Int, payload: ByteArray) {
        mu.withLock {
            val seq = mySeq.get() and 0xFFFFFFFFL
            val pkt = Packet.buildTcp(
                srcIp   = serverIp, dstIp   = clientIp,
                srcPort = serverPort, dstPort = clientPort,
                seq = seq, ack = myAck,
                flags = flags, payload = payload
            )
            tunWrite(pkt)
            if (payload.isNotEmpty()) mySeq.addAndGet(payload.size.toLong())
            if (flags and Packet.FIN != 0) mySeq.incrementAndGet()
        }
    }

    fun close() {
        if (dead.compareAndSet(false, true)) {
            try { socket.close() } catch (_: Exception) {}
            clientQueue.close()
            state = ConnState.CLOSED
        }
    }

    val key get() = "$clientPort-$serverPort-${Packet.ipStr(serverIp)}"
}
