package com.daniil.zapret.core

import android.net.VpnService
import android.util.Log
import com.daniil.zapret.dpi.BypassMode
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

private const val TAG = "TcpConn"

enum class ConnState { HANDSHAKE, OPEN, CLOSED }

class TcpConn(
    private val vpn: VpnService,
    private val tunWrite: (ByteArray) -> Unit,
    val clientIp: ByteArray,
    val serverIp: ByteArray,
    val clientPort: Int,
    val serverPort: Int,
    clientIsn: Long,
    private val bypass: BypassMode,
    private val executor: java.util.concurrent.ExecutorService
) {
    var state = ConnState.HANDSHAKE

    private val mySeq  = AtomicLong(0x74A9B000L)
    @Volatile private var myAck = (clientIsn + 1L) and 0xFFFFFFFFL
    private val socket = Socket()
    private val queue  = LinkedBlockingQueue<ByteArray>(512)
    private val dead   = AtomicBoolean(false)

    fun feedData(data: ByteArray) { if (!dead.get()) queue.offer(data) }
    fun feedFin()  { dead.set(true) }
    fun feedRst()  { close() }
    fun advanceAck(seq: Long, size: Int) {
        myAck = ((seq and 0xFFFFFFFFL) + size.toLong()) and 0xFFFFFFFFL
    }

    fun start() {
        executor.execute { run() }
    }

    private fun run() {
        // 1. Connect to real server first
        try {
            vpn.protect(socket)
            socket.connect(InetSocketAddress(InetAddress.getByAddress(serverIp), serverPort), 6000)
            socket.tcpNoDelay = true
        } catch (e: Exception) {
            Log.d(TAG, "connect $clientPort->$serverPort: ${e.message}")
            state = ConnState.CLOSED
            try { socket.close() } catch (_: Exception) {}
            return
        }

        // 2. Send SYN-ACK to client
        state = ConnState.OPEN
        tun(Packet.SYN or Packet.ACK, ByteArray(0))
        mySeq.incrementAndGet()

        // 3. Server→Client in separate executor task
        executor.execute { readServer() }

        // 4. Client→Server (this thread)
        writeServer()
    }

    private fun writeServer() {
        var first = true
        try {
            val out = socket.getOutputStream()
            while (!dead.get()) {
                val data = queue.poll(300, TimeUnit.MILLISECONDS) ?: continue
                if (data.isEmpty()) break
                if (first && bypass != BypassMode.NONE && data.size > bypass.splitPos + 1) {
                    doBypass(out, data)
                } else {
                    out.write(data); out.flush()
                }
                first = false
                tun(Packet.ACK, ByteArray(0))
            }
        } catch (_: Exception) {
        } finally { close() }
    }

    private fun readServer() {
        try {
            val inp = socket.getInputStream()
            val buf = ByteArray(1440)
            while (!dead.get()) {
                val n = inp.read(buf)
                if (n == -1) break
                tun(Packet.PSH or Packet.ACK, buf.copyOf(n))
            }
        } catch (_: Exception) {
        } finally {
            if (!dead.get()) try { tun(Packet.FIN or Packet.ACK, ByteArray(0)) } catch (_: Exception) {}
            close()
        }
    }

    private fun doBypass(out: OutputStream, data: ByteArray) {
        val pos = bypass.splitPos.coerceIn(1, data.size - 1)
        when (bypass) {
            BypassMode.SPLIT_2, BypassMode.SPLIT_1, BypassMode.SPLIT_40 -> {
                out.write(data, 0, pos); out.flush()
                Thread.sleep(1)
                out.write(data, pos, data.size - pos); out.flush()
            }
            BypassMode.FAKE -> {
                val fake = data.copyOf()
                for (i in pos until minOf(pos + 16, fake.size))
                    fake[i] = (fake[i].toInt() xor 0xFF).toByte()
                out.write(fake, 0, pos); out.flush()
                Thread.sleep(1)
                out.write(data); out.flush()
            }
            BypassMode.DISORDER -> {
                out.write(data, pos, data.size - pos); out.flush()
                Thread.sleep(1)
                out.write(data, 0, pos); out.flush()
            }
            BypassMode.NONE -> { out.write(data); out.flush() }
        }
    }

    @Synchronized
    private fun tun(flags: Int, payload: ByteArray) {
        val seq = mySeq.get() and 0xFFFFFFFFL
        tunWrite(Packet.buildTcp(
            srcIp = serverIp, dstIp = clientIp,
            srcPort = serverPort, dstPort = clientPort,
            seq = seq, ack = myAck, flags = flags, payload = payload
        ))
        if (payload.isNotEmpty()) mySeq.addAndGet(payload.size.toLong())
        if (flags and Packet.FIN != 0) mySeq.incrementAndGet()
    }

    fun close() {
        if (dead.compareAndSet(false, true)) {
            try { socket.close() } catch (_: Exception) {}
            state = ConnState.CLOSED
        }
    }

    val key get() = "$clientPort→${Packet.ipStr(serverIp)}:$serverPort"
}
