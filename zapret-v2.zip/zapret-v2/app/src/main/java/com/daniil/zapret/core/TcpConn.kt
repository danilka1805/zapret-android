package com.daniil.zapret.core

import android.net.VpnService
import android.util.Log
import com.daniil.zapret.dpi.BypassMode
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

private const val TAG = "TcpConn"

enum class ConnState { HANDSHAKE, OPEN, CLOSED }

class TcpConn(
    private val vpn: VpnService,
    private val tunWrite: (ByteArray) -> Unit,   // blocking, called from thread
    val clientIp: ByteArray,
    val serverIp: ByteArray,
    val clientPort: Int,
    val serverPort: Int,
    clientIsn: Long,
    private val bypass: BypassMode
) {
    var state = ConnState.HANDSHAKE

    private val mySeq = AtomicLong(0x74A9B000L)
    @Volatile private var myAck = (clientIsn + 1L) and 0xFFFFFFFFL

    private val socket = Socket()
    private val dead   = AtomicBoolean(false)

    // Queue: inbound data from TUN (from client)
    private val queue = java.util.concurrent.LinkedBlockingQueue<ByteArray>(256)

    fun feedData(data: ByteArray) { if (!dead.get()) queue.offer(data) }
    fun feedFin()  { dead.set(true) }
    fun feedRst()  { close() }
    fun advanceAck(seq: Long, size: Int) {
        myAck = ((seq and 0xFFFFFFFFL) + size.toLong()) and 0xFFFFFFFFL
    }

    /** Start two threads: one connects+relays, returns immediately */
    fun start() {
        Thread({ run() }, "tcp-$clientPort").also { it.isDaemon = true; it.start() }
    }

    private fun run() {
        // ── 1. Connect to real server ────────────────────────────────
        try {
            val ok = vpn.protect(socket)
            if (!ok) Log.w(TAG, "protect() failed $clientPort")
            socket.connect(InetSocketAddress(InetAddress.getByAddress(serverIp), serverPort), 6000)
            socket.tcpNoDelay = true
            socket.soTimeout  = 0
        } catch (e: Exception) {
            Log.w(TAG, "connect fail $clientPort->$serverPort: ${e.message}")
            state = ConnState.CLOSED; return
        }

        // ── 2. Tell client we're ready ───────────────────────────────
        state = ConnState.OPEN
        writeTun(Packet.SYN or Packet.ACK, ByteArray(0))
        mySeq.incrementAndGet()
        Log.d(TAG, "ready $clientPort->$serverPort bypass=${bypass.id}")

        // ── 3. Server→Client thread ──────────────────────────────────
        val s2cThread = Thread({
            try {
                val inp = socket.getInputStream()
                val buf = ByteArray(1440)
                while (!dead.get()) {
                    val n = inp.read(buf)
                    if (n == -1) break
                    writeTun(Packet.PSH or Packet.ACK, buf.copyOf(n))
                }
            } catch (e: Exception) {
                Log.d(TAG, "s2c $clientPort: ${e.message}")
            } finally {
                if (!dead.get()) try { writeTun(Packet.FIN or Packet.ACK, ByteArray(0)) } catch (_: Exception) {}
                close()
            }
        }, "s2c-$clientPort").also { it.isDaemon = true; it.start() }

        // ── 4. Client→Server (this thread) ───────────────────────────
        try {
            val out = socket.getOutputStream()
            var first = true
            while (!dead.get()) {
                val data = queue.poll(500, java.util.concurrent.TimeUnit.MILLISECONDS) ?: continue
                if (data.isEmpty()) break
                if (first && bypass != BypassMode.NONE && data.size > bypass.splitPos + 1) {
                    doBypass(out, data)
                } else {
                    out.write(data); out.flush()
                }
                first = false
                writeTun(Packet.ACK, ByteArray(0))
            }
        } catch (e: Exception) {
            Log.d(TAG, "c2s $clientPort: ${e.message}")
        } finally {
            close()
        }
        s2cThread.join(2000)
    }

    private fun doBypass(out: OutputStream, data: ByteArray) {
        val pos = bypass.splitPos.coerceIn(1, data.size - 1)
        when (bypass) {
            BypassMode.SPLIT_2, BypassMode.SPLIT_1, BypassMode.SPLIT_40 -> {
                out.write(data, 0, pos);               out.flush()
                Thread.sleep(1)
                out.write(data, pos, data.size - pos); out.flush()
            }
            BypassMode.FAKE -> {
                val fake = data.copyOf()
                for (i in pos until minOf(pos + 16, fake.size))
                    fake[i] = (fake[i].toInt() xor 0xFF).toByte()
                out.write(fake, 0, pos); out.flush()
                Thread.sleep(1)
                out.write(data);         out.flush()
            }
            BypassMode.DISORDER -> {
                out.write(data, pos, data.size - pos); out.flush()
                Thread.sleep(1)
                out.write(data, 0, pos);               out.flush()
            }
            BypassMode.NONE -> { out.write(data); out.flush() }
        }
    }

    // ── Synchronized TUN write ────────────────────────────────────────

    @Synchronized
    private fun writeTun(flags: Int, payload: ByteArray) {
        val seq = mySeq.get() and 0xFFFFFFFFL
        val ack = myAck
        val pkt = Packet.buildTcp(
            srcIp = serverIp,  dstIp   = clientIp,
            srcPort = serverPort, dstPort = clientPort,
            seq = seq, ack = ack, flags = flags, payload = payload
        )
        tunWrite(pkt)
        if (payload.isNotEmpty()) mySeq.addAndGet(payload.size.toLong())
        if (flags and Packet.FIN != 0) mySeq.incrementAndGet()
    }

    fun close() {
        if (dead.compareAndSet(false, true)) {
            try { socket.close() } catch (_: Exception) {}
            state = ConnState.CLOSED
        }
    }

    val key get() = "$clientPort→${Packet.ipStr(serverIp)}:$serverPort"
}
