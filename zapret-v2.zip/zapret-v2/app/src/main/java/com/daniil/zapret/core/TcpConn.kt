package com.daniil.zapret.core

import android.net.VpnService
import android.util.Log
import com.daniil.zapret.dpi.BypassMode
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

private const val TAG = "TcpConn"

enum class ConnState { HANDSHAKE, OPEN, CLOSED }

class TcpConn(
    private val vpn: VpnService,
    private val tunWrite: suspend (ByteArray) -> Unit,
    val clientIp: ByteArray,
    val serverIp: ByteArray,
    val clientPort: Int,
    val serverPort: Int,
    clientIsn: Long,
    private val bypass: BypassMode,
    private val scope: CoroutineScope
) {
    var state = ConnState.HANDSHAKE

    private val mySeq = AtomicLong(System.nanoTime() and 0xFFFFFFFFL)
    @Volatile private var myAck = clientIsn + 1
    private val writeMutex = Mutex()

    private val socket = Socket()
    // Unlimited channel — stores client data while we're connecting to server
    private val clientQueue = Channel<ByteArray>(Channel.UNLIMITED)
    private val dead = AtomicBoolean(false)

    fun feedData(payload: ByteArray) {
        if (!dead.get()) clientQueue.trySend(payload)
    }
    fun feedFin()  { clientQueue.close(); dead.set(true) }
    fun feedRst()  { close() }
    fun advanceAck(seq: Long, size: Int) { myAck = seq + size }

    fun start() {
        scope.launch(Dispatchers.IO) {
            // CRITICAL: Connect to real server FIRST, then tell client we're ready.
            // This prevents client from sending data before we're ready to relay it.
            try {
                vpn.protect(socket)
                socket.connect(
                    InetSocketAddress(InetAddress.getByAddress(serverIp), serverPort),
                    8000
                )
                socket.tcpNoDelay = true
            } catch (e: Exception) {
                Log.d(TAG, "Connect failed $clientPort->$serverPort: ${e.message}")
                try { socket.close() } catch (_: Exception) {}
                state = ConnState.CLOSED
                return@launch
            }

            // Now send SYN-ACK — client will complete handshake and send data
            state = ConnState.OPEN
            sendSynAck()
            mySeq.incrementAndGet()

            // Start server→client reader
            scope.launch(Dispatchers.IO) { serverToClient() }

            // This coroutine becomes client→server writer
            clientToServer()
        }
    }

    // ─── client → server ─────────────────────────────────────────────────

    private suspend fun clientToServer() {
        var first = true
        try {
            val out = socket.getOutputStream()
            for (data in clientQueue) {
                if (data.isEmpty()) break
                withContext(Dispatchers.IO) {
                    if (first && bypass != BypassMode.NONE && data.size > bypass.splitPos + 1) {
                        applyBypass(out, data)
                    } else {
                        out.write(data)
                        out.flush()
                    }
                }
                first = false
                sendAck()
            }
        } catch (e: Exception) {
            Log.d(TAG, "c2s error $clientPort: ${e.message}")
        } finally {
            close()
        }
    }

    private fun applyBypass(out: java.io.OutputStream, data: ByteArray) {
        val pos = bypass.splitPos.coerceIn(1, data.size - 1)
        when (bypass) {
            BypassMode.SPLIT_2, BypassMode.SPLIT_1, BypassMode.SPLIT_40 -> {
                out.write(data, 0, pos); out.flush()
                Thread.sleep(1)
                out.write(data, pos, data.size - pos); out.flush()
            }
            BypassMode.FAKE -> {
                val fake = data.copyOf()
                for (i in pos until minOf(pos + 16, fake.size)) {
                    fake[i] = (fake[i].toInt() xor 0xFF).toByte()
                }
                out.write(fake, 0, pos); out.flush()
                Thread.sleep(1)
                out.write(data); out.flush()
            }
            BypassMode.DISORDER -> {
                out.write(data, pos, data.size - pos); out.flush()
                Thread.sleep(1)
                out.write(data, 0, pos); out.flush()
            }
            BypassMode.NONE -> { out.write(data); out.flush() }
        }
    }

    // ─── server → client ─────────────────────────────────────────────────

    private suspend fun serverToClient() {
        try {
            val inp = socket.getInputStream()
            // 1440 = MTU(1500) - IP(20) - TCP(20) - safety(20)
            val buf = ByteArray(1440)
            while (!dead.get()) {
                val n = withContext(Dispatchers.IO) { inp.read(buf) }
                if (n == -1) break
                sendData(buf.copyOf(n))
            }
        } catch (e: Exception) {
            Log.d(TAG, "s2c error $clientPort: ${e.message}")
        } finally {
            if (!dead.get()) {
                // Server closed — send FIN to client
                sendFin()
            }
            close()
        }
    }

    // ─── TUN writes ──────────────────────────────────────────────────────

    private suspend fun sendSynAck() = send(Packet.SYN or Packet.ACK, ByteArray(0))
    private suspend fun sendAck()    = send(Packet.ACK, ByteArray(0))
    private suspend fun sendData(payload: ByteArray) = send(Packet.PSH or Packet.ACK, payload)
    private suspend fun sendFin()    = send(Packet.FIN or Packet.ACK, ByteArray(0))

    private suspend fun send(flags: Int, payload: ByteArray) {
        writeMutex.withLock {
            val seq = mySeq.get()
            val pkt = Packet.buildTcp(
                srcIp = serverIp, dstIp = clientIp,
                srcPort = serverPort, dstPort = clientPort,
                seq = seq, ack = myAck,
                flags = flags, payload = payload
            )
            tunWrite(pkt)
            if (payload.isNotEmpty()) mySeq.addAndGet(payload.size.toLong())
            if (flags and Packet.FIN != 0) mySeq.incrementAndGet()
        }
    }

    fun close() {
        if (dead.compareAndSet(false, true)) {
            try { socket.close() } catch (_: Exception) {}
            clientQueue.close()
            state = ConnState.CLOSED
        }
    }

    val key get() = "$clientPort-$serverPort-${Packet.ipStr(serverIp)}"
}
