package com.daniil.zapret.whitelist

import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.*
import com.daniil.zapret.R
import com.daniil.zapret.databinding.ActivityWhitelistBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class WhitelistActivity : AppCompatActivity() {
    private lateinit var b: ActivityWhitelistBinding
    private lateinit var mgr: WhitelistManager
    private lateinit var adapter: DomainAdapter

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityWhitelistBinding.inflate(layoutInflater)
        setContentView(b.root)
        setSupportActionBar(b.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Белый список"

        mgr = WhitelistManager(this)
        adapter = DomainAdapter(mgr.get().toMutableList()) { mgr.remove(it); refresh() }
        b.recyclerDomains.layoutManager = LinearLayoutManager(this)
        b.recyclerDomains.adapter = adapter

        val isAll = mgr.getMode() == "all"
        b.switchBypassAll.isChecked = isAll
        updateMode(isAll)
        b.switchBypassAll.setOnCheckedChangeListener { _, c -> mgr.setMode(if (c) "all" else "whitelist"); updateMode(c) }

        b.fabAdd.setOnClickListener {
            val et = EditText(this).apply { hint = "example.com"; setPadding(48,24,48,8) }
            MaterialAlertDialogBuilder(this).setTitle("Добавить домен").setView(et)
                .setPositiveButton("Добавить") { _,_ -> mgr.add(et.text.toString()); refresh() }
                .setNegativeButton("Отмена", null).show()
        }
        b.btnReset.setOnClickListener {
            MaterialAlertDialogBuilder(this).setTitle("Сбросить к стандартным?")
                .setPositiveButton("Сбросить") { _,_ -> mgr.save(WhitelistManager.DEFAULTS); refresh() }
                .setNegativeButton("Отмена", null).show()
        }
    }

    private fun updateMode(all: Boolean) {
        b.tvModeDesc.text = if (all) "Весь трафик 80/443 обходит DPI" else "Только домены из списка"
        b.listGroup.visibility = if (all) android.view.View.GONE else android.view.View.VISIBLE
    }

    private fun refresh() { adapter.update(mgr.get().toMutableList()) }
    override fun onSupportNavigateUp(): Boolean { onBackPressedDispatcher.onBackPressed(); return true }
}

class DomainAdapter(private val items: MutableList<String>, private val onDel: (String)->Unit)
    : RecyclerView.Adapter<DomainAdapter.VH>() {
    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tv: TextView = v.findViewById(R.id.tvDomain)
        val btn: ImageButton = v.findViewById(R.id.btnRemove)
    }
    override fun onCreateViewHolder(p: ViewGroup, t: Int) = VH(
        LayoutInflater.from(p.context).inflate(R.layout.item_domain, p, false))
    override fun onBindViewHolder(h: VH, i: Int) {
        h.tv.text = items[i]; h.btn.setOnClickListener { onDel(items[i]) }
    }
    override fun getItemCount() = items.size
    fun update(list: MutableList<String>) { items.clear(); items.addAll(list); notifyDataSetChanged() }
}
