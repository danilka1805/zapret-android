// Package tunwrapper wraps tun2socks for Android via gomobile.
package tunwrapper

import (
	"fmt"

	"github.com/xjasonlyu/tun2socks/v2/engine"
)

// Start starts tun2socks. fd is the TUN file descriptor, proxy is "host:port".
func Start(fd int, proxy string) {
	key := new(engine.Key)
	key.Proxy    = fmt.Sprintf("socks5://%s", proxy)
	key.Device   = fmt.Sprintf("fd://%d", fd)
	key.LogLevel = "error"
	engine.Insert(key)
	engine.Start()
}

// Stop stops tun2socks.
func Stop() {
	engine.Stop()
}
