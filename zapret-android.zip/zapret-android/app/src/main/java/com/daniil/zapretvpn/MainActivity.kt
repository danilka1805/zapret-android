package com.daniil.zapretvpn

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.daniil.zapretvpn.appfilter.AppFilterActivity
import com.daniil.zapretvpn.databinding.ActivityMainBinding
import com.daniil.zapretvpn.dpi.ProfileAutoDetect
import com.daniil.zapretvpn.dpi.ProfileManager
import com.daniil.zapretvpn.dpi.Profiles
import com.daniil.zapretvpn.whitelist.WhitelistActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

private const val VPN_REQUEST_CODE = 1001

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var profileManager: ProfileManager
    private val handler = Handler(Looper.getMainLooper())
    private var uptimeTick: Runnable? = null
    private var suppressToggle = false
    private var autoDetecting = false

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { updateUi() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        profileManager = ProfileManager(this)

        binding.powerToggle.onToggled = { isOn ->
            if (!suppressToggle) {
                if (isOn) {
                    val intent = VpnService.prepare(this)
                    if (intent != null) {
                        suppressToggle = true
                        binding.powerToggle.setOn(false, animate = false)
                        suppressToggle = false
                        startActivityForResult(intent, VPN_REQUEST_CODE)
                    } else startVpn()
                } else stopVpn()
            }
        }

        binding.btnAutoDetect.setOnClickListener { startAutoDetect() }
        binding.cardProfile.setOnClickListener { showProfilePicker() }
        binding.btnWhitelist.setOnClickListener { startActivity(Intent(this, WhitelistActivity::class.java)) }
        binding.btnAppFilter.setOnClickListener { startActivity(Intent(this, AppFilterActivity::class.java)) }

        updateUi()
    }

    override fun onResume() {
        super.onResume()
        registerReceiver(statusReceiver, IntentFilter("com.daniil.zapretvpn.STATUS_CHANGED"), RECEIVER_NOT_EXPORTED)
        updateUi(); startUptimeTick()
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(statusReceiver); stopUptimeTick()
    }

    // ─── Auto-detect ─────────────────────────────────────────────────────

    private fun startAutoDetect() {
        if (autoDetecting) return
        autoDetecting = true
        binding.btnAutoDetect.isEnabled = false
        binding.tvAutoStatus.visibility = View.VISIBLE
        binding.tvAutoStatus.text = "Запускаю тест..."

        lifecycleScope.launch {
            val results = StringBuilder()
            var bestProfileId: String? = null

            // Test each profile: start VPN with it, wait 1s, test connection
            val profilesToTest = Profiles.ALL.filter { it.mode != "none" }

            for (profile in profilesToTest) {
                binding.tvAutoStatus.text = "Тестирую: ${profile.name}..."

                // Switch to this profile and (re)start VPN
                profileManager.setActiveProfile(profile.id)
                if (DpiVpnService.isRunning) {
                    stopVpn()
                    delay(800)
                }
                startVpn()
                delay(1500) // wait for VPN to establish

                val result = ProfileAutoDetect.testProfile(profile)
                val line = if (result.success)
                    "✓ ${profile.name}: ${result.pingMs}ms\n"
                else
                    "✗ ${profile.name}: нет связи\n"
                results.append(line)
                binding.tvAutoStatus.text = results.toString().trimEnd()

                if (result.success && bestProfileId == null) bestProfileId = profile.id
            }

            // Apply best profile
            if (bestProfileId != null) {
                profileManager.setActiveProfile(bestProfileId)
                stopVpn(); delay(500); startVpn()
                results.append("\n→ Выбран: ${Profiles.byId(bestProfileId).name}")
            } else {
                results.append("\n✗ Ни один профиль не работает")
                stopVpn()
            }

            binding.tvAutoStatus.text = results.toString().trimEnd()
            autoDetecting = false
            binding.btnAutoDetect.isEnabled = true
            updateUi()
        }
    }

    // ─── VPN ─────────────────────────────────────────────────────────────

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == VPN_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            startVpn()
            suppressToggle = true; binding.powerToggle.setOn(true, animate = true); suppressToggle = false
        }
    }

    private fun startVpn() {
        startForegroundService(Intent(this, DpiVpnService::class.java).apply {
            action = ACTION_START
            putExtra(EXTRA_PROFILE, profileManager.getActiveProfileId())
        })
    }

    private fun stopVpn() {
        startService(Intent(this, DpiVpnService::class.java).apply { action = ACTION_STOP })
    }

    // ─── Profile picker ──────────────────────────────────────────────────

    private fun showProfilePicker() {
        if (autoDetecting) return
        val profiles = Profiles.ALL
        val currentIdx = profiles.indexOfFirst { it.id == profileManager.getActiveProfileId() }
        MaterialAlertDialogBuilder(this)
            .setTitle("Профиль DPI-обхода")
            .setSingleChoiceItems(profiles.map { "${it.name}\n${it.description}" }.toTypedArray(), currentIdx) { dialog, which ->
                profileManager.setActiveProfile(profiles[which].id)
                if (DpiVpnService.isRunning) { stopVpn(); handler.postDelayed({ startVpn() }, 600) }
                updateUi(); dialog.dismiss()
            }.show()
    }

    // ─── UI ──────────────────────────────────────────────────────────────

    private fun updateUi() {
        val on = DpiVpnService.isRunning
        val profile = profileManager.getActiveProfile()

        binding.statusDot.setBackgroundResource(if (on) R.drawable.dot_green else R.drawable.dot_red)
        binding.tvStatus.text    = if (on) "АКТИВЕН" else "ОТКЛЮЧЁН"
        binding.tvStatusSub.text = if (on) "DPI-обход работает" else "Переключи для запуска"
        binding.tvToggleLabel.text = if (on) "АКТИВНО" else "ЗАПУСТИТЬ"

        suppressToggle = true; binding.powerToggle.setOn(on, animate = true); suppressToggle = false

        binding.tvProfileName.text = profile.name
        binding.tvProfileDesc.text = profile.description
        binding.tvProfileMode.text = "Режим: ${profile.mode.uppercase(Locale.ROOT)}  |  pos: ${profile.splitPos}"

        binding.btnAutoDetect.isEnabled = !autoDetecting
        if (!autoDetecting) binding.tvAutoStatus.visibility = View.GONE

        updateUptime()
    }

    private fun updateUptime() {
        val secs = if (DpiVpnService.isRunning) {
            binding.tvUptime.tag?.let { (it as? Long)?.let { s -> (System.currentTimeMillis() - s) / 1000 } } ?: 0L
        } else 0L
        val h = secs / 3600; val m = (secs % 3600) / 60; val s = secs % 60
        binding.tvUptime.text = if (DpiVpnService.isRunning) "Аптайм: %02d:%02d:%02d".format(h, m, s) else "Аптайм: --:--:--"
        if (DpiVpnService.isRunning && binding.tvUptime.tag == null) binding.tvUptime.tag = System.currentTimeMillis()
        else if (!DpiVpnService.isRunning) binding.tvUptime.tag = null
    }

    private fun startUptimeTick() {
        uptimeTick = object : Runnable {
            override fun run() { if (DpiVpnService.isRunning) updateUptime(); handler.postDelayed(this, 1000) }
        }.also { handler.postDelayed(it, 1000) }
    }

    private fun stopUptimeTick() { uptimeTick?.let { handler.removeCallbacks(it) }; uptimeTick = null }

    override fun onCreateOptionsMenu(menu: Menu): Boolean { menuInflater.inflate(R.menu.main_menu, menu); return true }

    override fun onOptionsItemSelected(item: MenuItem) = when (item.itemId) {
        R.id.menu_whitelist -> { startActivity(Intent(this, WhitelistActivity::class.java)); true }
        R.id.menu_about -> {
            MaterialAlertDialogBuilder(this).setTitle("ZapretVPN")
                .setMessage("Версия 1.0.0\n\nDPI-обход через локальный TUN. Трафик не уходит на сторонние серверы.\n\nТехника: TCP-фрагментация TLS ClientHello.")
                .setPositiveButton("OK", null).show(); true
        }
        else -> super.onOptionsItemSelected(item)
    }
}
