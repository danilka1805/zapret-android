package com.daniil.zapretvpn.tcp

import java.net.InetAddress

object PacketUtils {
    // TCP flags
    const val FLAG_FIN = 0x01
    const val FLAG_SYN = 0x02
    const val FLAG_RST = 0x04
    const val FLAG_PSH = 0x08
    const val FLAG_ACK = 0x10
    const val FLAG_URG = 0x20

    // ─── IP header parsing ───────────────────────────────────────────────

    fun getVersion(pkt: ByteArray) = (pkt[0].toInt() ushr 4) and 0xF
    fun getIHL(pkt: ByteArray) = (pkt[0].toInt() and 0xF) * 4
    fun getTotalLength(pkt: ByteArray) =
        ((pkt[2].toInt() and 0xFF) shl 8) or (pkt[3].toInt() and 0xFF)
    fun getProtocol(pkt: ByteArray) = pkt[9].toInt() and 0xFF
    fun getSrcIP(pkt: ByteArray): ByteArray = pkt.copyOfRange(12, 16)
    fun getDstIP(pkt: ByteArray): ByteArray = pkt.copyOfRange(16, 20)

    // ─── TCP header parsing ──────────────────────────────────────────────

    fun getTcpSrcPort(pkt: ByteArray, ihl: Int) =
        ((pkt[ihl].toInt() and 0xFF) shl 8) or (pkt[ihl + 1].toInt() and 0xFF)

    fun getTcpDstPort(pkt: ByteArray, ihl: Int) =
        ((pkt[ihl + 2].toInt() and 0xFF) shl 8) or (pkt[ihl + 3].toInt() and 0xFF)

    fun getTcpSeq(pkt: ByteArray, ihl: Int): Long =
        ((pkt[ihl + 4].toLong() and 0xFF) shl 24) or
                ((pkt[ihl + 5].toLong() and 0xFF) shl 16) or
                ((pkt[ihl + 6].toLong() and 0xFF) shl 8) or
                (pkt[ihl + 7].toLong() and 0xFF)

    fun getTcpAckNum(pkt: ByteArray, ihl: Int): Long =
        ((pkt[ihl + 8].toLong() and 0xFF) shl 24) or
                ((pkt[ihl + 9].toLong() and 0xFF) shl 16) or
                ((pkt[ihl + 10].toLong() and 0xFF) shl 8) or
                (pkt[ihl + 11].toLong() and 0xFF)

    fun getTcpDataOffset(pkt: ByteArray, ihl: Int) =
        ((pkt[ihl + 12].toInt() ushr 4) and 0xF) * 4

    fun getTcpFlags(pkt: ByteArray, ihl: Int) = pkt[ihl + 13].toInt() and 0xFF

    fun getTcpWindow(pkt: ByteArray, ihl: Int) =
        ((pkt[ihl + 14].toInt() and 0xFF) shl 8) or (pkt[ihl + 15].toInt() and 0xFF)

    fun getTcpPayload(pkt: ByteArray, ihl: Int): ByteArray {
        val tcpDataOffset = getTcpDataOffset(pkt, ihl)
        val start = ihl + tcpDataOffset
        val len = getTotalLength(pkt) - ihl - tcpDataOffset
        return if (len > 0) pkt.copyOfRange(start, start + len) else ByteArray(0)
    }

    // ─── Checksum ────────────────────────────────────────────────────────

    fun checksum(buf: ByteArray, offset: Int = 0, length: Int = buf.size): Int {
        var sum = 0L
        var i = offset
        val end = offset + length
        while (i < end - 1) {
            sum += ((buf[i].toInt() and 0xFF) shl 8) or (buf[i + 1].toInt() and 0xFF)
            i += 2
        }
        if (i < end) sum += (buf[i].toInt() and 0xFF) shl 8
        while (sum shr 16 != 0L) sum = (sum and 0xFFFF) + (sum shr 16)
        return (sum.inv() and 0xFFFF).toInt()
    }

    // ─── Build raw IP+TCP packet ─────────────────────────────────────────

    fun buildTcpPacket(
        srcIP: ByteArray, dstIP: ByteArray,
        srcPort: Int, dstPort: Int,
        seq: Long, ack: Long,
        flags: Int,
        window: Int = 65535,
        payload: ByteArray = ByteArray(0)
    ): ByteArray {
        val tcpLen = 20 + payload.size
        val totalLen = 20 + tcpLen
        val buf = ByteArray(totalLen)

        // --- IP header ---
        buf[0] = 0x45.toByte()          // version=4, IHL=5 (20 bytes)
        buf[1] = 0                       // DSCP/ECN
        buf[2] = (totalLen shr 8).toByte()
        buf[3] = totalLen.toByte()
        buf[4] = 0; buf[5] = 1          // Identification
        buf[6] = 0x40.toByte(); buf[7] = 0 // Don't Fragment
        buf[8] = 64                     // TTL
        buf[9] = 6                      // Protocol = TCP
        buf[10] = 0; buf[11] = 0        // checksum (computed below)
        srcIP.copyInto(buf, 12)
        dstIP.copyInto(buf, 16)

        // --- TCP header ---
        buf[20] = (srcPort shr 8).toByte(); buf[21] = srcPort.toByte()
        buf[22] = (dstPort shr 8).toByte(); buf[23] = dstPort.toByte()
        buf[24] = (seq shr 24).toByte(); buf[25] = (seq shr 16).toByte()
        buf[26] = (seq shr 8).toByte();  buf[27] = seq.toByte()
        buf[28] = (ack shr 24).toByte(); buf[29] = (ack shr 16).toByte()
        buf[30] = (ack shr 8).toByte();  buf[31] = ack.toByte()
        buf[32] = 0x50.toByte()         // Data offset = 5 (20 bytes)
        buf[33] = flags.toByte()
        buf[34] = (window shr 8).toByte(); buf[35] = window.toByte()
        buf[36] = 0; buf[37] = 0        // checksum (computed below)
        buf[38] = 0; buf[39] = 0        // urgent pointer

        payload.copyInto(buf, 40)

        // --- IP checksum ---
        val ipCs = checksum(buf, 0, 20)
        buf[10] = (ipCs shr 8).toByte(); buf[11] = ipCs.toByte()

        // --- TCP checksum (pseudo-header) ---
        val pseudo = ByteArray(12 + tcpLen)
        srcIP.copyInto(pseudo, 0)
        dstIP.copyInto(pseudo, 4)
        pseudo[8] = 0; pseudo[9] = 6
        pseudo[10] = (tcpLen shr 8).toByte(); pseudo[11] = tcpLen.toByte()
        buf.copyInto(pseudo, 12, 20, 20 + tcpLen)
        val tcpCs = checksum(pseudo)
        buf[36] = (tcpCs shr 8).toByte(); buf[37] = tcpCs.toByte()

        return buf
    }

    fun buildRstPacket(
        srcIP: ByteArray, dstIP: ByteArray,
        srcPort: Int, dstPort: Int,
        seq: Long
    ) = buildTcpPacket(srcIP, dstIP, srcPort, dstPort, seq, 0L, FLAG_RST)

    fun ipToString(bytes: ByteArray): String =
        InetAddress.getByAddress(bytes).hostAddress ?: "0.0.0.0"

    /** Extract SNI hostname from TLS ClientHello payload */
    fun extractSni(payload: ByteArray): String? {
        if (payload.size < 5) return null
        // TLS record: type=0x16 (handshake), version, length
        if (payload[0].toInt() and 0xFF != 0x16) return null
        if (payload.size < 43) return null

        var pos = 5 // skip TLS record header
        // Handshake type = 1 (ClientHello)
        if (payload[pos].toInt() and 0xFF != 0x01) return null
        pos += 4 // handshake type + length
        pos += 2 // client version
        pos += 32 // random
        if (pos >= payload.size) return null

        val sessionIdLen = payload[pos].toInt() and 0xFF
        pos += 1 + sessionIdLen
        if (pos + 2 >= payload.size) return null

        val cipherSuitesLen = ((payload[pos].toInt() and 0xFF) shl 8) or (payload[pos + 1].toInt() and 0xFF)
        pos += 2 + cipherSuitesLen
        if (pos >= payload.size) return null

        val compressionLen = payload[pos].toInt() and 0xFF
        pos += 1 + compressionLen
        if (pos + 2 >= payload.size) return null

        // Extensions
        val extTotalLen = ((payload[pos].toInt() and 0xFF) shl 8) or (payload[pos + 1].toInt() and 0xFF)
        pos += 2
        val extEnd = pos + extTotalLen

        while (pos + 4 <= extEnd && pos + 4 <= payload.size) {
            val extType = ((payload[pos].toInt() and 0xFF) shl 8) or (payload[pos + 1].toInt() and 0xFF)
            val extLen = ((payload[pos + 2].toInt() and 0xFF) shl 8) or (payload[pos + 3].toInt() and 0xFF)
            pos += 4

            if (extType == 0x0000) { // SNI extension
                if (pos + 5 > payload.size) return null
                val listLen = ((payload[pos].toInt() and 0xFF) shl 8) or (payload[pos + 1].toInt() and 0xFF)
                pos += 2
                val nameType = payload[pos].toInt() and 0xFF
                pos++
                if (nameType != 0) return null // 0 = host_name
                val nameLen = ((payload[pos].toInt() and 0xFF) shl 8) or (payload[pos + 1].toInt() and 0xFF)
                pos += 2
                if (pos + nameLen > payload.size) return null
                return String(payload, pos, nameLen, Charsets.US_ASCII)
            }
            pos += extLen
        }
        return null
    }
}
