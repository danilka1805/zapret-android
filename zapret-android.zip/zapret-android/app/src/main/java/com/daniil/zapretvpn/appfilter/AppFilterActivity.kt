package com.daniil.zapretvpn.appfilter

import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.daniil.zapretvpn.R
import com.daniil.zapretvpn.databinding.ActivityAppFilterBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppFilterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAppFilterBinding
    private lateinit var manager: AppFilterManager
    private lateinit var adapter: AppAdapter
    private var allApps: List<AppInfo> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppFilterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Фильтр приложений"

        manager = AppFilterManager(this)

        adapter = AppAdapter(
            pm = packageManager,
            onToggle = { pkg -> manager.togglePackage(pkg) }
        )
        binding.recyclerApps.layoutManager = LinearLayoutManager(this)
        binding.recyclerApps.adapter = adapter

        // Mode chips
        updateModeChips()
        binding.chipAll.setOnClickListener     { setMode("all") }
        binding.chipInclude.setOnClickListener { setMode("include") }
        binding.chipExclude.setOnClickListener { setMode("exclude") }

        // Search
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = filterApps(s?.toString() ?: "")
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })

        // Load apps in background
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            allApps = withContext(Dispatchers.IO) { manager.getInstalledApps() }
            binding.progressBar.visibility = View.GONE
            filterApps("")
        }
    }

    private fun setMode(mode: String) {
        manager.setMode(mode)
        updateModeChips()
        val hint = when (mode) {
            "include" -> "Только выбранные приложения будут обходить DPI"
            "exclude" -> "Выбранные приложения НЕ будут обходить DPI"
            else      -> "Все приложения обходят DPI"
        }
        binding.tvModeHint.text = hint
        binding.appListGroup.visibility = if (mode == "all") View.GONE else View.VISIBLE
    }

    private fun updateModeChips() {
        val mode = manager.getMode()
        binding.chipAll.isSelected     = mode == "all"
        binding.chipInclude.isSelected = mode == "include"
        binding.chipExclude.isSelected = mode == "exclude"
        binding.appListGroup.visibility = if (mode == "all") View.GONE else View.VISIBLE
        binding.tvModeHint.text = when (mode) {
            "include" -> "Только выбранные приложения будут обходить DPI"
            "exclude" -> "Выбранные приложения НЕ будут обходить DPI"
            else      -> "Все приложения обходят DPI"
        }
    }

    private fun filterApps(query: String) {
        val filtered = if (query.isBlank()) allApps
        else allApps.filter { it.label.contains(query, ignoreCase = true) ||
                               it.packageName.contains(query, ignoreCase = true) }
        adapter.submitList(filtered, manager.getSelectedPackages())
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}

// ─── RecyclerView adapter ────────────────────────────────────────────────────

class AppAdapter(
    private val pm: PackageManager,
    private val onToggle: (String) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var items: List<AppInfo> = emptyList()
    private var selected: Set<String> = emptySet()
    private val iconCache = HashMap<String, Drawable>()

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon:    ImageView = view.findViewById(R.id.ivAppIcon)
        val label:   TextView  = view.findViewById(R.id.tvAppLabel)
        val pkgName: TextView  = view.findViewById(R.id.tvPackageName)
        val check:   CheckBox  = view.findViewById(R.id.checkApp)
    }

    fun submitList(apps: List<AppInfo>, sel: Set<String>) {
        items = apps
        selected = sel
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = VH(
        LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
    )

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = items[position]
        holder.label.text   = app.label
        holder.pkgName.text = app.packageName
        holder.check.isChecked = app.packageName in selected

        // Load icon (cached)
        holder.icon.setImageDrawable(
            iconCache.getOrPut(app.packageName) {
                try { pm.getApplicationIcon(app.packageName) }
                catch (_: Exception) { pm.defaultActivityIcon }
            }
        )

        holder.itemView.setOnClickListener {
            onToggle(app.packageName)
            holder.check.isChecked = !holder.check.isChecked
        }
        holder.check.setOnClickListener {
            onToggle(app.packageName)
        }
    }

    override fun getItemCount() = items.size
}
