package com.daniil.zapretvpn.whitelist

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.daniil.zapretvpn.R
import com.daniil.zapretvpn.databinding.ActivityWhitelistBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class WhitelistActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWhitelistBinding
    private lateinit var manager: WhitelistManager
    private lateinit var adapter: DomainAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWhitelistBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Белый список"

        manager = WhitelistManager(this)
        adapter = DomainAdapter(manager.getDomains().toMutableList()) { domain ->
            manager.removeDomain(domain)
            refreshList()
        }

        binding.recyclerDomains.layoutManager = LinearLayoutManager(this)
        binding.recyclerDomains.adapter = adapter

        // Mode toggle
        updateModeToggle()
        binding.switchBypassAll.setOnCheckedChangeListener { _, checked ->
            manager.setMode(if (checked) "all" else "whitelist")
            binding.recyclerDomains.visibility = if (checked) View.GONE else View.VISIBLE
            binding.fabAdd.visibility = if (checked) View.GONE else View.VISIBLE
            binding.tvModeDesc.text = if (checked)
                "Весь трафик на 80/443 будет обходить DPI"
            else
                "Только домены из списка"
        }

        binding.fabAdd.setOnClickListener { showAddDialog() }

        binding.btnResetDefaults.setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("Сбросить список?")
                .setMessage("Будут восстановлены стандартные домены.")
                .setPositiveButton("Сбросить") { _, _ ->
                    manager.saveDomains(WhitelistManager.DEFAULT_DOMAINS)
                    refreshList()
                }
                .setNegativeButton("Отмена", null)
                .show()
        }
    }

    private fun updateModeToggle() {
        val isAll = manager.getMode() == "all"
        binding.switchBypassAll.isChecked = isAll
        binding.recyclerDomains.visibility = if (isAll) View.GONE else View.VISIBLE
        binding.fabAdd.visibility = if (isAll) View.GONE else View.VISIBLE
        binding.tvModeDesc.text = if (isAll)
            "Весь трафик на 80/443 будет обходить DPI"
        else
            "Только домены из списка"
    }

    private fun showAddDialog() {
        val input = EditText(this).apply {
            hint = "example.com"
            setPadding(48, 24, 48, 8)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Добавить домен")
            .setView(input)
            .setPositiveButton("Добавить") { _, _ ->
                val domain = input.text.toString().trim().lowercase()
                if (domain.isNotEmpty()) {
                    manager.addDomain(domain)
                    refreshList()
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun refreshList() {
        adapter.updateList(manager.getDomains().toMutableList())
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}

class DomainAdapter(
    private val domains: MutableList<String>,
    private val onRemove: (String) -> Unit
) : RecyclerView.Adapter<DomainAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvDomain: TextView = view.findViewById(R.id.tvDomain)
        val btnRemove: ImageButton = view.findViewById(R.id.btnRemove)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_domain, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.tvDomain.text = domains[position]
        holder.btnRemove.setOnClickListener { onRemove(domains[position]) }
    }

    override fun getItemCount() = domains.size

    fun updateList(newList: MutableList<String>) {
        domains.clear()
        domains.addAll(newList)
        notifyDataSetChanged()
    }
}
