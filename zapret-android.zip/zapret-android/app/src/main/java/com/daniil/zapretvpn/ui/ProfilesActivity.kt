package com.daniil.zapretvpn.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.daniil.zapretvpn.R
import com.daniil.zapretvpn.dpi.DpiProfile
import com.daniil.zapretvpn.dpi.ProfileManager
import com.daniil.zapretvpn.dpi.Profiles
import com.daniil.zapretvpn.databinding.ActivityProfilesBinding

class ProfilesActivity : AppCompatActivity() {
    private lateinit var binding: ActivityProfilesBinding
    private lateinit var profileManager: ProfileManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfilesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Профили обхода"

        profileManager = ProfileManager(this)
        val active = profileManager.getActiveProfileId()

        binding.recyclerProfiles.layoutManager = LinearLayoutManager(this)
        binding.recyclerProfiles.adapter = ProfileAdapter(Profiles.ALL, active) { id ->
            profileManager.setActiveProfile(id)
            finish()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}

class ProfileAdapter(
    private val profiles: List<DpiProfile>,
    private var selectedId: String,
    private val onSelect: (String) -> Unit
) : RecyclerView.Adapter<ProfileAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val radio: RadioButton = view.findViewById(R.id.radioProfile)
        val tvName: TextView   = view.findViewById(R.id.tvProfileName)
        val tvDesc: TextView   = view.findViewById(R.id.tvProfileDesc)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = VH(
        LayoutInflater.from(parent.context).inflate(R.layout.item_profile, parent, false)
    )

    override fun onBindViewHolder(holder: VH, position: Int) {
        val p = profiles[position]
        holder.tvName.text = p.name
        holder.tvDesc.text = p.description
        holder.radio.isChecked = p.id == selectedId
        holder.itemView.setOnClickListener {
            selectedId = p.id
            notifyDataSetChanged()
            onSelect(p.id)
        }
    }

    override fun getItemCount() = profiles.size
}
