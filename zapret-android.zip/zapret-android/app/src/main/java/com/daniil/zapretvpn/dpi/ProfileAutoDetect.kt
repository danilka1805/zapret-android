package com.daniil.zapretvpn.dpi

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

private const val TAG = "AutoDetect"

// Test URL — always accessible if any bypass works
private const val TEST_URL = "https://www.youtube.com/generate_204"
private const val TIMEOUT_MS = 6000

data class ProfileResult(val profile: DpiProfile, val pingMs: Long, val success: Boolean)

object ProfileAutoDetect {

    /**
     * Tests each profile by trying to connect through it and measuring latency.
     * Must be called AFTER the VPN is already running with the given profile.
     * The caller switches profile → waits → calls testCurrent() → repeats.
     */
    suspend fun testAllProfiles(
        onProgress: (String) -> Unit,
        onResult: (ProfileResult) -> Unit
    ): DpiProfile? = withContext(Dispatchers.IO) {
        val results = mutableListOf<ProfileResult>()

        // Only test meaningful profiles (skip "none")
        val toTest = Profiles.ALL.filter { it.mode != "none" }

        for (profile in toTest) {
            onProgress("Тестирую: ${profile.name}...")
            val result = testProfile(profile)
            onResult(result)
            results.add(result)
            Log.d(TAG, "Profile ${profile.id}: success=${result.success} ping=${result.pingMs}ms")
        }

        // Best = successful with lowest ping
        results.filter { it.success }.minByOrNull { it.pingMs }?.profile
    }

    suspend fun testProfile(profile: DpiProfile): ProfileResult = withContext(Dispatchers.IO) {
        val start = System.currentTimeMillis()
        return@withContext try {
            val conn = URL(TEST_URL).openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_MS
            conn.readTimeout = TIMEOUT_MS
            conn.requestMethod = "GET"
            conn.setRequestProperty("User-Agent", "Mozilla/5.0")
            conn.instanceFollowRedirects = false
            val code = conn.responseCode
            val ping = System.currentTimeMillis() - start
            conn.disconnect()
            // 204 = success, 301/302 = redirect (also means connection worked)
            val ok = code in 200..399
            ProfileResult(profile, ping, ok)
        } catch (e: Exception) {
            Log.d(TAG, "Test failed for ${profile.id}: ${e.message}")
            ProfileResult(profile, TIMEOUT_MS.toLong(), false)
        }
    }
}
