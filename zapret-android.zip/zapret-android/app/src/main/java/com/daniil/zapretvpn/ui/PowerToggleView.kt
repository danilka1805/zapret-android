package com.daniil.zapretvpn.ui

import android.animation.AnimatorSet
import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import androidx.core.content.ContextCompat
import com.daniil.zapretvpn.R
import kotlin.math.abs

class PowerToggleView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var isOn: Boolean = false
        private set

    var onToggled: ((Boolean) -> Unit)? = null

    // ─── Geometry ────────────────────────────────────────────────────────

    private val trackWidth  = dp(80f)
    private val trackHeight = dp(40f)
    private val thumbRadius = dp(16f)
    private val thumbPadding = dp(4f)

    private val trackLeft   get() = (width  - trackWidth)  / 2f
    private val trackTop    get() = (height - trackHeight) / 2f
    private val trackRight  get() = trackLeft + trackWidth
    private val trackBottom get() = trackTop + trackHeight
    private val trackRectF  get() = RectF(trackLeft, trackTop, trackRight, trackBottom)

    // Thumb X: OFF = left edge + padding + radius, ON = right edge - padding - radius
    private val thumbXOff get() = trackLeft + thumbPadding + thumbRadius
    private val thumbXOn  get() = trackRight - thumbPadding - thumbRadius
    private val thumbY    get() = trackTop + trackHeight / 2f

    // ─── Animation state ─────────────────────────────────────────────────

    private var thumbX = thumbXOff
    private var animProgress = 0f   // 0.0 = off, 1.0 = on

    // ─── Colors ──────────────────────────────────────────────────────────

    private val colorOff   = Color.parseColor("#242836")
    private val colorOn    = Color.parseColor("#16A34A")
    private val colorGlow  = Color.parseColor("#22C55E")
    private val colorThumb = Color.WHITE

    private var trackColor = colorOff
    private var glowAlpha  = 0

    // ─── Paints ──────────────────────────────────────────────────────────

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = colorThumb
        style = Paint.Style.FILL
        setShadowLayer(dp(6f), 0f, dp(2f), Color.argb(80, 0, 0, 0))
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        maskFilter = BlurMaskFilter(dp(12f), BlurMaskFilter.Blur.NORMAL)
    }
    private val powerIconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = dp(2f)
    }

    // ─── Touch ───────────────────────────────────────────────────────────

    private var touchDownX = 0f
    private var touchDownY = 0f
    private var dragging = false

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                touchDownX = event.x
                touchDownY = event.y
                dragging = false
            }
            MotionEvent.ACTION_MOVE -> {
                if (abs(event.x - touchDownX) > dp(4f)) dragging = true
                if (dragging) {
                    // Live drag
                    val clamped = event.x.coerceIn(thumbXOff, thumbXOn)
                    thumbX = clamped
                    animProgress = (thumbX - thumbXOff) / (thumbXOn - thumbXOff)
                    updateColors()
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val newState = if (dragging) {
                    animProgress >= 0.5f
                } else {
                    !isOn
                }
                animateTo(newState)
                performClick()
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    // ─── Animate ─────────────────────────────────────────────────────────

    fun setOn(on: Boolean, animate: Boolean = true) {
        if (on == isOn && animate) return
        if (animate) animateTo(on) else { isOn = on; animProgress = if (on) 1f else 0f; updatePositions(); invalidate() }
    }

    private fun animateTo(newState: Boolean) {
        if (newState == isOn && animProgress == (if (newState) 1f else 0f)) return
        isOn = newState

        val startProgress = animProgress
        val endProgress = if (newState) 1f else 0f

        val progressAnim = ValueAnimator.ofFloat(startProgress, endProgress).apply {
            duration = 280
            interpolator = DecelerateInterpolator(1.5f)
            addUpdateListener {
                animProgress = it.animatedValue as Float
                updatePositions()
                updateColors()
                invalidate()
            }
        }
        progressAnim.start()
        onToggled?.invoke(newState)
    }

    private fun updatePositions() {
        thumbX = thumbXOff + (thumbXOn - thumbXOff) * animProgress
    }

    private fun updateColors() {
        trackColor = ArgbEvaluator().evaluate(animProgress, colorOff, colorOn) as Int
        glowAlpha = (animProgress * 160).toInt()
    }

    // ─── Draw ────────────────────────────────────────────────────────────

    override fun onDraw(canvas: Canvas) {
        // Glow under track when ON
        if (glowAlpha > 0) {
            glowPaint.color = Color.argb(glowAlpha / 3, 34, 197, 94)
            canvas.drawRoundRect(
                trackRectF.apply { inset(-dp(6f), -dp(6f)) },
                dp(26f), dp(26f), glowPaint
            )
        }

        // Track
        trackPaint.color = trackColor
        canvas.drawRoundRect(trackRectF, trackHeight / 2f, trackHeight / 2f, trackPaint)

        // Track border
        trackPaint.color = Color.argb(40, 255, 255, 255)
        trackPaint.style = Paint.Style.STROKE
        trackPaint.strokeWidth = dp(1f)
        canvas.drawRoundRect(trackRectF, trackHeight / 2f, trackHeight / 2f, trackPaint)
        trackPaint.style = Paint.Style.FILL

        // Thumb shadow glow
        if (isOn || animProgress > 0.1f) {
            glowPaint.color = Color.argb((animProgress * 80).toInt(), 34, 197, 94)
            canvas.drawCircle(thumbX, thumbY, thumbRadius + dp(4f), glowPaint)
        }

        // Thumb
        canvas.drawCircle(thumbX, thumbY, thumbRadius, thumbPaint)

        // Power icon on thumb
        drawPowerIcon(canvas)
    }

    private fun drawPowerIcon(canvas: Canvas) {
        val cx = thumbX
        val cy = thumbY
        val r = thumbRadius * 0.45f

        // Icon color: grey when off, green when on
        val iconColor = ArgbEvaluator().evaluate(animProgress,
            Color.argb(120, 100, 100, 100),
            Color.parseColor("#16A34A")
        ) as Int
        powerIconPaint.color = iconColor

        // Circle arc (gap at top)
        val oval = RectF(cx - r, cy - r, cx + r, cy + r)
        canvas.drawArc(oval, -220f, 260f, false, powerIconPaint)

        // Vertical line (power symbol)
        canvas.drawLine(cx, cy - r - dp(1.5f), cx, cy - r * 0.3f, powerIconPaint)
    }

    // ─── Measure ─────────────────────────────────────────────────────────

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = resolveSize((trackWidth + dp(24f)).toInt(), widthMeasureSpec)
        val h = resolveSize((trackHeight + dp(24f)).toInt(), heightMeasureSpec)
        setMeasuredDimension(w, h)
    }

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null) // needed for BlurMaskFilter
    }

    private fun dp(value: Float) = value * resources.displayMetrics.density
}
