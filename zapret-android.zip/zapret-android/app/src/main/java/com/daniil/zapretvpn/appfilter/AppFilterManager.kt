package com.daniil.zapretvpn.appfilter

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build

data class AppInfo(
    val packageName: String,
    val label: String,
    val isSystem: Boolean,
    val isSelected: Boolean
)

class AppFilterManager(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("app_filter", Context.MODE_PRIVATE)

    companion object {
        const val KEY_PACKAGES = "selected_packages"
        const val KEY_MODE     = "filter_mode"
    }

    fun getMode(): String = prefs.getString(KEY_MODE, "all") ?: "all"
    fun setMode(mode: String) { prefs.edit().putString(KEY_MODE, mode).apply() }

    fun getSelectedPackages(): Set<String> =
        prefs.getStringSet(KEY_PACKAGES, emptySet()) ?: emptySet()

    fun setSelectedPackages(packages: Set<String>) {
        prefs.edit().putStringSet(KEY_PACKAGES, packages).apply()
    }

    fun togglePackage(pkg: String) {
        val current = getSelectedPackages().toMutableSet()
        if (pkg in current) current.remove(pkg) else current.add(pkg)
        setSelectedPackages(current)
    }

    fun getInstalledApps(): List<AppInfo> {
        val pm = ctx.packageManager
        val selected = getSelectedPackages()

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)
            PackageManager.MATCH_UNINSTALLED_PACKAGES.toLong().toInt()
        else 0

        val apps = try {
            pm.getInstalledApplications(flags)
        } catch (_: Exception) {
            pm.getInstalledApplications(0)
        }

        return apps
            .filter { app ->
                // Show all user-installed apps + system apps if selected
                val isSystem = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                !isSystem || app.packageName in selected
            }
            .mapNotNull { app ->
                try {
                    val label = pm.getApplicationLabel(app).toString()
                    if (label.isBlank()) return@mapNotNull null
                    AppInfo(
                        packageName = app.packageName,
                        label = label,
                        isSystem = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                        isSelected = app.packageName in selected
                    )
                } catch (_: Exception) { null }
            }
            .sortedWith(compareBy({ !it.isSelected }, { it.label.lowercase() }))
    }

    fun applyToBuilder(builder: VpnService.Builder) {
        val mode = getMode()
        val packages = getSelectedPackages()
        if (mode == "all" || packages.isEmpty()) return
        packages.forEach { pkg ->
            try {
                when (mode) {
                    "include" -> builder.addAllowedApplication(pkg)
                    "exclude" -> builder.addDisallowedApplication(pkg)
                }
            } catch (_: Exception) {}
        }
    }
}
