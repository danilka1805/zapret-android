package com.daniil.zapretvpn.appfilter

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager

data class AppInfo(
    val packageName: String,
    val label: String,
    val isSystem: Boolean,
    val isSelected: Boolean
)

class AppFilterManager(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("app_filter", Context.MODE_PRIVATE)

    companion object {
        const val KEY_PACKAGES   = "selected_packages"
        const val KEY_MODE       = "filter_mode"   // "all" | "include" | "exclude"
    }

    fun getMode(): String = prefs.getString(KEY_MODE, "all") ?: "all"
    fun setMode(mode: String) { prefs.edit().putString(KEY_MODE, mode).apply() }

    fun getSelectedPackages(): Set<String> =
        prefs.getStringSet(KEY_PACKAGES, emptySet()) ?: emptySet()

    fun setSelectedPackages(packages: Set<String>) {
        prefs.edit().putStringSet(KEY_PACKAGES, packages).apply()
    }

    fun togglePackage(pkg: String) {
        val current = getSelectedPackages().toMutableSet()
        if (pkg in current) current.remove(pkg) else current.add(pkg)
        setSelectedPackages(current)
    }

    /** Returns installed non-system apps + chosen system apps, sorted by label */
    fun getInstalledApps(): List<AppInfo> {
        val pm = ctx.packageManager
        val selected = getSelectedPackages()
        return pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { app ->
                // Include user apps always; include system apps only if already selected
                val isSystem = app.flags and ApplicationInfo.FLAG_SYSTEM != 0
                !isSystem || app.packageName in selected
            }
            .map { app ->
                val isSystem = app.flags and ApplicationInfo.FLAG_SYSTEM != 0
                AppInfo(
                    packageName = app.packageName,
                    label = pm.getApplicationLabel(app).toString(),
                    isSystem = isSystem,
                    isSelected = app.packageName in selected
                )
            }
            .sortedWith(compareBy({ !it.isSelected }, { it.label.lowercase() }))
    }

    /** Apply the filter to a VpnService.Builder via reflection-free API */
    fun applyToBuilder(builder: android.net.VpnService.Builder) {
        val mode = getMode()
        val packages = getSelectedPackages()
        if (mode == "all" || packages.isEmpty()) return

        val pm = ctx.packageManager
        when (mode) {
            "include" -> {
                // Only these apps go through the VPN (get bypass)
                packages.forEach { pkg ->
                    try { builder.addAllowedApplication(pkg) } catch (_: Exception) {}
                }
            }
            "exclude" -> {
                // These apps bypass the VPN entirely (no interception)
                packages.forEach { pkg ->
                    try { builder.addDisallowedApplication(pkg) } catch (_: Exception) {}
                }
            }
        }
    }
}
