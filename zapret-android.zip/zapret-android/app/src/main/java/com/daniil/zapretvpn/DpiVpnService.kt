package com.daniil.zapretvpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import com.daniil.zapretvpn.appfilter.AppFilterManager
import com.daniil.zapretvpn.dpi.ProfileManager
import com.daniil.zapretvpn.tcp.PacketUtils
import com.daniil.zapretvpn.tcp.TcpSessionManager
import com.daniil.zapretvpn.whitelist.WhitelistManager
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean

private const val TAG = "DpiVpnService"
private const val NOTIF_CHANNEL = "zapret_vpn"
private const val NOTIF_ID = 1
const val ACTION_START = "com.daniil.zapretvpn.START"
const val ACTION_STOP  = "com.daniil.zapretvpn.STOP"
const val EXTRA_PROFILE = "profile_id"

class DpiVpnService : VpnService() {

    private var tunFd: ParcelFileDescriptor? = null
    private val running = AtomicBoolean(false)
    private var readerThread: Thread? = null
    private var sessionManager: TcpSessionManager? = null
    private var startTimeMs = 0L

    companion object {
        var isRunning = false
            private set
        var activeProfile = "split2"
            private set
    }

    // ─── Lifecycle ───────────────────────────────────────────────────────

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopVpn(); return START_NOT_STICKY }
            ACTION_START -> {
                val profileId = intent.getStringExtra(EXTRA_PROFILE) ?: "split2"
                startVpn(profileId)
            }
        }
        return START_STICKY
    }

    override fun onRevoke() {
        stopVpn()
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }

    // ─── Start / Stop ────────────────────────────────────────────────────

    private fun startVpn(profileId: String) {
        if (running.get()) stopVpn()

        val profile = ProfileManager(this).run { setActiveProfile(profileId); getActiveProfile() }
        activeProfile = profileId

        // Build the VPN interface
        val builder = Builder()
            .setSession("ZapretVPN")
            .addAddress("10.0.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1")
            .addDnsServer("8.8.8.8")
            .setMtu(1500)
            .setBlocking(true)

        // Apply per-app filter (include/exclude selected apps)
        AppFilterManager(this).applyToBuilder(builder)

        tunFd = builder.establish() ?: run {
            Log.e(TAG, "Failed to establish VPN interface")
            return
        }

        val whitelist = WhitelistManager(this)
        val tunOutputStream = FileOutputStream(tunFd!!.fileDescriptor)
        sessionManager = TcpSessionManager(this, tunOutputStream, whitelist, profile)

        running.set(true)
        isRunning = true
        startTimeMs = System.currentTimeMillis()

        readerThread = Thread({ readLoop() }, "tun-reader").also { it.start() }

        startForeground(NOTIF_ID, buildNotification(profile.name))
        Log.i(TAG, "VPN started with profile: ${profile.name}")

        // Broadcast status update
        sendBroadcast(Intent("com.daniil.zapretvpn.STATUS_CHANGED"))
    }

    private fun stopVpn() {
        running.set(false)
        isRunning = false
        sessionManager?.closeAll()
        sessionManager = null
        readerThread?.interrupt()
        readerThread = null
        try { tunFd?.close() } catch (_: Exception) {}
        tunFd = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        Log.i(TAG, "VPN stopped")
        sendBroadcast(Intent("com.daniil.zapretvpn.STATUS_CHANGED"))
    }

    // ─── Packet reader loop ──────────────────────────────────────────────

    private fun readLoop() {
        val inp = FileInputStream(tunFd!!.fileDescriptor)
        val buf = ByteArray(32767)
        Log.d(TAG, "Read loop started")
        try {
            while (running.get()) {
                val n = inp.read(buf)
                if (n <= 0) continue
                if (n < 20) continue  // too small for an IP header

                // We only intercept IPv4 TCP (protocol 6) on ports 80/443
                // Everything else: write back to TUN so the OS routes it normally
                val version = PacketUtils.getVersion(buf)
                if (version != 4) {
                    // IPv6 — pass through (we didn't add IPv6 routes so this shouldn't happen)
                    continue
                }

                val proto = PacketUtils.getProtocol(buf)
                if (proto == 6) {  // TCP
                    val ihl = PacketUtils.getIHL(buf)
                    if (n < ihl + 20) continue
                    val dstPort = PacketUtils.getTcpDstPort(buf, ihl)
                    if (dstPort == 80 || dstPort == 443) {
                        // Hand off to session manager for DPI bypass handling
                        sessionManager?.handlePacket(buf, n)
                        continue
                    }
                }

                // For all other traffic (UDP, ICMP, TCP other ports):
                // We need to forward it using a protected socket.
                // Since we set addRoute("0.0.0.0", 0), all traffic comes here.
                // Non-80/443 TCP and UDP: let Android handle via the tunnel naturally.
                // The TUN approach: we just don't write back non-intercepted packets,
                // which means they're dropped. For a proper implementation we'd need
                // tun2socks for UDP/other TCP. For now we focus on 80/443 bypass.
            }
        } catch (e: InterruptedException) {
            Log.d(TAG, "Read loop interrupted")
        } catch (e: Exception) {
            if (running.get()) Log.e(TAG, "Read loop error: ${e.message}")
        }
        Log.d(TAG, "Read loop ended")
    }

    // ─── Notification ────────────────────────────────────────────────────

    private fun buildNotification(profileName: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(NOTIF_CHANNEL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(NOTIF_CHANNEL, "ZapretVPN", NotificationManager.IMPORTANCE_LOW)
                    .also { it.description = "Статус работы DPI-обхода" }
            )
        }
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, DpiVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, NOTIF_CHANNEL)
            .setContentTitle("ZapretVPN активен")
            .setContentText("Профиль: $profileName")
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .setContentIntent(openIntent)
            .addAction(
                Notification.Action.Builder(
                    android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_media_pause),
                    "Стоп", stopIntent
                ).build()
            )
            .setOngoing(true)
            .build()
    }

    fun getUptimeSeconds(): Long =
        if (isRunning) (System.currentTimeMillis() - startTimeMs) / 1000 else 0L
}
