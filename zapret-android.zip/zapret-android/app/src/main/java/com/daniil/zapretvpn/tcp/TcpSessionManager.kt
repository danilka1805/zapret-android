package com.daniil.zapretvpn.tcp

import android.net.VpnService
import android.util.Log
import com.daniil.zapretvpn.dpi.DpiProfile
import com.daniil.zapretvpn.whitelist.WhitelistManager
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap

private const val TAG = "TcpSessionManager"
private const val CLEANUP_INTERVAL_MS = 30_000L

class TcpSessionManager(
    private val vpnService: VpnService,
    private val tunOut: FileOutputStream,
    private val whitelistManager: WhitelistManager,
    private val profile: DpiProfile
) {
    private val sessions = ConcurrentHashMap<String, TcpSession>()
    private var lastCleanup = System.currentTimeMillis()

    /**
     * Process an incoming IP packet from TUN.
     * Only handles IPv4 TCP. Everything else is silently ignored
     * (and the VPN routes will handle non-intercepted traffic normally).
     */
    fun handlePacket(pkt: ByteArray, len: Int) {
        if (len < 40) return
        val packet = pkt.copyOf(len)

        if (PacketUtils.getVersion(packet) != 4) return
        if (PacketUtils.getProtocol(packet) != 6) return  // not TCP

        val ihl = PacketUtils.getIHL(packet)
        if (len < ihl + 20) return

        val flags = PacketUtils.getTcpFlags(packet, ihl)
        val srcIP = PacketUtils.getSrcIP(packet)
        val dstIP = PacketUtils.getDstIP(packet)
        val srcPort = PacketUtils.getTcpSrcPort(packet, ihl)
        val dstPort = PacketUtils.getTcpDstPort(packet, ihl)
        val seq = PacketUtils.getTcpSeq(packet, ihl)
        val payload = PacketUtils.getTcpPayload(packet, ihl)

        val key = TcpSession.sessionKey(srcIP, dstIP, srcPort, dstPort)

        when {
            // New connection: SYN without ACK
            flags and PacketUtils.FLAG_SYN != 0 && flags and PacketUtils.FLAG_ACK == 0 -> {
                // Determine if this connection gets DPI bypass
                // We only intercept port 80 and 443
                if (dstPort != 80 && dstPort != 443) return

                // Check whitelist: bypass only if in whitelist (or whitelist is empty = bypass all)
                val bypassEnabled = whitelistManager.isEmpty() || whitelistManager.matchesPort(dstPort)

                Log.d(TAG, "SYN $key bypass=$bypassEnabled")

                val session = TcpSession(
                    vpnService = vpnService,
                    tunOut = tunOut,
                    clientIP = srcIP,
                    serverIP = dstIP,
                    clientPort = srcPort,
                    serverPort = dstPort,
                    clientSeq = seq,
                    profile = profile,
                    enabled = bypassEnabled
                )
                sessions[key] = session
                session.start()
            }

            // Data or ACK on existing connection
            else -> {
                val session = sessions[key]
                if (session == null) {
                    // Unknown session → send RST
                    if (flags and PacketUtils.FLAG_RST == 0) {
                        val rst = PacketUtils.buildRstPacket(dstIP, srcIP, dstPort, srcPort, 0L)
                        try { tunOut.write(rst) } catch (_: Exception) {}
                    }
                    return
                }

                when {
                    flags and PacketUtils.FLAG_RST != 0 -> {
                        session.onClientRst()
                        sessions.remove(key)
                    }
                    flags and PacketUtils.FLAG_FIN != 0 -> {
                        session.onClientFin()
                        sessions.remove(key)
                    }
                    payload.isNotEmpty() -> {
                        session.updateAck(seq + payload.size - 1)
                        session.onClientData(payload)
                    }
                    // Pure ACK: nothing to do
                }
            }
        }

        // Periodic cleanup of dead sessions
        val now = System.currentTimeMillis()
        if (now - lastCleanup > CLEANUP_INTERVAL_MS) {
            cleanup()
            lastCleanup = now
        }
    }

    private fun cleanup() {
        val dead = sessions.entries.filter { it.value.state == TcpState.CLOSED }
        dead.forEach { sessions.remove(it.key) }
        Log.d(TAG, "Cleanup: removed ${dead.size}, active: ${sessions.size}")
    }

    fun closeAll() {
        sessions.values.forEach { it.close() }
        sessions.clear()
    }

    val activeCount get() = sessions.size
}
