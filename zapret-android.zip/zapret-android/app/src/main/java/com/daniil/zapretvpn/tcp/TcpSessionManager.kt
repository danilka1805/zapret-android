package com.daniil.zapretvpn.tcp

import android.net.VpnService
import android.util.Log
import com.daniil.zapretvpn.dpi.DpiProfile
import com.daniil.zapretvpn.whitelist.WhitelistManager
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

private const val TAG = "SessionMgr"
private const val MAX_SESSIONS = 64   // hard cap — prevents thread explosion

class TcpSessionManager(
    private val vpnService: VpnService,
    private val tunOut: FileOutputStream,
    private val whitelistManager: WhitelistManager,
    private val profile: DpiProfile
) {
    private val sessions = ConcurrentHashMap<String, TcpSession>()
    private var lastCleanup = System.currentTimeMillis()

    // Shared pool: max 16 threads for ALL sessions combined
    private val executor = Executors.newFixedThreadPool(16)

    fun handlePacket(pkt: ByteArray, len: Int) {
        if (len < 40) return
        val packet = pkt.copyOf(len)
        if (PacketUtils.getVersion(packet) != 4) return
        if (PacketUtils.getProtocol(packet) != 6) return

        val ihl = PacketUtils.getIHL(packet)
        if (len < ihl + 20) return

        val flags    = PacketUtils.getTcpFlags(packet, ihl)
        val srcIP    = PacketUtils.getSrcIP(packet)
        val dstIP    = PacketUtils.getDstIP(packet)
        val srcPort  = PacketUtils.getTcpSrcPort(packet, ihl)
        val dstPort  = PacketUtils.getTcpDstPort(packet, ihl)
        val seq      = PacketUtils.getTcpSeq(packet, ihl)
        val payload  = PacketUtils.getTcpPayload(packet, ihl)
        val key      = TcpSession.sessionKey(srcIP, dstIP, srcPort, dstPort)

        if (flags and PacketUtils.FLAG_SYN != 0 && flags and PacketUtils.FLAG_ACK == 0) {
            // Enforce session cap
            if (sessions.size >= MAX_SESSIONS) {
                cleanup()
                if (sessions.size >= MAX_SESSIONS) return
            }
            val bypass = whitelistManager.isEmpty() || whitelistManager.matchesPort(dstPort)
            val session = TcpSession(
                vpnService, tunOut, srcIP, dstIP, srcPort, dstPort,
                seq, profile, bypass, executor
            )
            sessions[key] = session
            session.start()
        } else {
            val session = sessions[key] ?: return
            when {
                flags and PacketUtils.FLAG_RST != 0 -> { session.onClientRst(); sessions.remove(key) }
                flags and PacketUtils.FLAG_FIN != 0 -> { session.onClientFin(); sessions.remove(key) }
                payload.isNotEmpty() -> { session.updateAck(seq + payload.size - 1); session.onClientData(payload) }
            }
        }

        val now = System.currentTimeMillis()
        if (now - lastCleanup > 20_000) { cleanup(); lastCleanup = now }
    }

    private fun cleanup() {
        val dead = sessions.entries.filter { it.value.state == TcpState.CLOSED }
        dead.forEach { sessions.remove(it.key) }
    }

    fun closeAll() {
        sessions.values.forEach { it.close() }
        sessions.clear()
        executor.shutdownNow()
        executor.awaitTermination(2, TimeUnit.SECONDS)
    }

    val activeCount get() = sessions.size
}
