package com.daniil.zapretvpn.tcp

import android.net.VpnService
import android.util.Log
import com.daniil.zapretvpn.dpi.DpiProfile
import java.io.FileOutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

private const val TAG = "TcpSession"

enum class TcpState { SYN_RECEIVED, ESTABLISHED, CLOSE_WAIT, CLOSED }

/**
 * Handles one TCP connection: relays between the local TUN "virtual client"
 * and the real remote server via a protected socket.
 * Applies DPI bypass (TCP segmentation split) on the first data packet.
 */
class TcpSession(
    private val vpnService: VpnService,
    private val tunOut: FileOutputStream,
    val clientIP: ByteArray,
    val serverIP: ByteArray,
    val clientPort: Int,
    val serverPort: Int,
    private val clientSeq: Long,    // from SYN
    private val profile: DpiProfile,
    private val enabled: Boolean     // DPI bypass on/off for this connection
) {
    var state = TcpState.SYN_RECEIVED

    // Sequence numbers we maintain for the virtual client side
    private var localSeq = (System.nanoTime() and 0xFFFFFFFFL)   // our ISN
    private var localAck = clientSeq + 1                           // next expected from client

    private val socket = Socket()
    private val clientDataQueue = ArrayBlockingQueue<ByteArray>(64)
    private val closed = AtomicBoolean(false)

    // ─── Called from reader thread when packet arrives from TUN ─────────

    fun onClientData(payload: ByteArray) {
        if (!closed.get()) clientDataQueue.offer(payload, 50, TimeUnit.MILLISECONDS)
    }

    fun onClientFin() {
        closed.set(true)
        try { socket.shutdownOutput() } catch (_: Exception) {}
    }

    fun onClientRst() {
        close()
    }

    fun updateAck(seq: Long) {
        localAck = seq + 1
    }

    // ─── Start relay threads ─────────────────────────────────────────────

    fun start() {
        // Step 1: Send SYN-ACK back to client via TUN
        sendToClient(PacketUtils.FLAG_SYN or PacketUtils.FLAG_ACK, ByteArray(0))
        localSeq++ // SYN consumes one seq

        // Step 2: Connect to real server in background
        Thread({ connectAndRelay() }, "relay-${clientPort}→${serverPort}").start()
    }

    private fun connectAndRelay() {
        try {
            vpnService.protect(socket)
            socket.connect(
                InetSocketAddress(
                    InetAddress.getByAddress(serverIP),
                    serverPort
                ),
                10_000
            )
            socket.soTimeout = 0
            state = TcpState.ESTABLISHED

            // Launch server→client reader
            Thread({ serverToClient() }, "s2c-$clientPort").start()

            // client→server writer (this thread)
            clientToServer()

        } catch (e: Exception) {
            Log.w(TAG, "Relay connect error $clientPort: ${e.message}")
            sendRst()
            close()
        }
    }

    // ─── Client → Server ─────────────────────────────────────────────────

    private fun clientToServer() {
        var firstPacket = true
        try {
            val out = socket.getOutputStream()
            while (!closed.get()) {
                val data = clientDataQueue.poll(500, TimeUnit.MILLISECONDS) ?: continue
                if (data.isEmpty()) break

                if (firstPacket && enabled && data.size > profile.splitPos + 1) {
                    // ── DPI SPLIT ──────────────────────────────────────────
                    // Split TLS ClientHello: send [0..splitPos-1] then [splitPos..end]
                    // This breaks DPI reassembly without affecting the real server
                    when (profile.mode) {
                        "split" -> {
                            out.write(data, 0, profile.splitPos)
                            out.flush()
                            Thread.sleep(0, 100_000) // 0.1ms gap
                            out.write(data, profile.splitPos, data.size - profile.splitPos)
                            out.flush()
                        }
                        "disorder" -> {
                            // Send second part with low TTL first, then first part
                            // (On Android without root we can't set TTL per-packet easily,
                            //  so fallback to plain split)
                            out.write(data, 0, profile.splitPos)
                            out.flush()
                            out.write(data, profile.splitPos, data.size - profile.splitPos)
                            out.flush()
                        }
                        "fake" -> {
                            // Send random garbage of same size first (fake ClientHello)
                            val fake = ByteArray(data.size) { 0xFF.toByte() }
                            out.write(fake)
                            out.flush()
                            out.write(data)
                            out.flush()
                        }
                        else -> {
                            out.write(data)
                            out.flush()
                        }
                    }
                    firstPacket = false
                } else {
                    out.write(data)
                    out.flush()
                    if (firstPacket) firstPacket = false
                }

                // ACK the client data
                sendToClient(PacketUtils.FLAG_ACK, ByteArray(0))
            }
        } catch (e: Exception) {
            Log.d(TAG, "c2s closed $clientPort: ${e.message}")
        } finally {
            close()
        }
    }

    // ─── Server → Client ─────────────────────────────────────────────────

    private fun serverToClient() {
        try {
            val inp = socket.getInputStream()
            val buf = ByteArray(4096)
            while (!closed.get()) {
                val n = inp.read(buf)
                if (n == -1) break
                val data = buf.copyOf(n)
                sendToClient(PacketUtils.FLAG_PSH or PacketUtils.FLAG_ACK, data)
            }
            // Server closed connection: send FIN-ACK
            sendToClient(PacketUtils.FLAG_FIN or PacketUtils.FLAG_ACK, ByteArray(0))
        } catch (e: Exception) {
            Log.d(TAG, "s2c closed $clientPort: ${e.message}")
        } finally {
            close()
        }
    }

    // ─── Write a packet to TUN (going to the client app) ─────────────────

    @Synchronized
    private fun sendToClient(flags: Int, payload: ByteArray) {
        val pkt = PacketUtils.buildTcpPacket(
            srcIP = serverIP,   // from client's perspective: packet comes FROM server
            dstIP = clientIP,
            srcPort = serverPort,
            dstPort = clientPort,
            seq = localSeq,
            ack = localAck,
            flags = flags,
            payload = payload
        )
        try {
            tunOut.write(pkt)
            if (payload.isNotEmpty()) localSeq += payload.size
            if (flags and PacketUtils.FLAG_SYN != 0 || flags and PacketUtils.FLAG_FIN != 0) {
                // SYN and FIN consume one sequence number each
                // (already incremented for SYN in start(), FIN incremented here)
                if (flags and PacketUtils.FLAG_FIN != 0) localSeq++
            }
        } catch (e: Exception) {
            Log.w(TAG, "tunOut write error: ${e.message}")
        }
    }

    private fun sendRst() {
        val pkt = PacketUtils.buildRstPacket(serverIP, clientIP, serverPort, clientPort, localSeq)
        try { tunOut.write(pkt) } catch (_: Exception) {}
    }

    fun close() {
        if (closed.compareAndSet(false, true)) {
            try { socket.close() } catch (_: Exception) {}
            state = TcpState.CLOSED
        }
    }

    val key get() = sessionKey(clientIP, serverIP, clientPort, serverPort)

    companion object {
        fun sessionKey(cIP: ByteArray, sIP: ByteArray, cPort: Int, sPort: Int): String =
            "${PacketUtils.ipToString(cIP)}:$cPort->${PacketUtils.ipToString(sIP)}:$sPort"
    }
}
