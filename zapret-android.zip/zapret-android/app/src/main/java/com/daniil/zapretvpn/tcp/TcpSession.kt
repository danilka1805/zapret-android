package com.daniil.zapretvpn.tcp

import android.net.VpnService
import android.util.Log
import com.daniil.zapretvpn.dpi.DpiProfile
import java.io.FileOutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.ExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

private const val TAG = "TcpSession"

enum class TcpState { SYN_RECEIVED, ESTABLISHED, CLOSED }

class TcpSession(
    private val vpnService: VpnService,
    private val tunOut: FileOutputStream,
    val clientIP: ByteArray,
    val serverIP: ByteArray,
    val clientPort: Int,
    val serverPort: Int,
    private val clientSeq: Long,
    private val profile: DpiProfile,
    private val enabled: Boolean,
    private val executor: ExecutorService
) {
    var state = TcpState.SYN_RECEIVED
    private var localSeq = (System.nanoTime() and 0xFFFFFFFFL)
    private var localAck = clientSeq + 1
    private val socket = Socket()
    private val clientDataQueue = ArrayBlockingQueue<ByteArray>(32)
    private val closed = AtomicBoolean(false)

    fun onClientData(payload: ByteArray) {
        if (!closed.get()) clientDataQueue.offer(payload)
    }

    fun onClientFin() {
        closed.set(true)
        try { socket.shutdownOutput() } catch (_: Exception) {}
    }

    fun onClientRst() { close() }

    fun updateAck(seq: Long) { localAck = seq + 1 }

    fun start() {
        sendToClient(PacketUtils.FLAG_SYN or PacketUtils.FLAG_ACK, ByteArray(0))
        localSeq++
        executor.execute { connectAndRelay() }
    }

    private fun connectAndRelay() {
        try {
            vpnService.protect(socket)
            socket.connect(InetSocketAddress(InetAddress.getByAddress(serverIP), serverPort), 8_000)
            socket.soTimeout = 0
            socket.tcpNoDelay = true
            state = TcpState.ESTABLISHED
            executor.execute { serverToClient() }
            clientToServer()
        } catch (e: Exception) {
            Log.d(TAG, "Connect error $clientPort: ${e.message}")
            sendRst(); close()
        }
    }

    private fun clientToServer() {
        var firstPacket = true
        try {
            val out = socket.getOutputStream()
            while (!closed.get()) {
                val data = clientDataQueue.poll(300, TimeUnit.MILLISECONDS) ?: continue
                if (data.isEmpty()) break
                if (firstPacket && enabled && profile.mode != "none" && data.size > profile.splitPos + 1) {
                    when (profile.mode) {
                        "split", "disorder" -> {
                            out.write(data, 0, profile.splitPos)
                            out.flush()
                            out.write(data, profile.splitPos, data.size - profile.splitPos)
                            out.flush()
                        }
                        "fake" -> {
                            val fake = ByteArray(data.size) { 0xFF.toByte() }
                            out.write(fake); out.flush()
                            out.write(data); out.flush()
                        }
                        else -> { out.write(data); out.flush() }
                    }
                    firstPacket = false
                } else {
                    out.write(data); out.flush()
                    firstPacket = false
                }
                sendToClient(PacketUtils.FLAG_ACK, ByteArray(0))
            }
        } catch (_: Exception) {
        } finally { close() }
    }

    private fun serverToClient() {
        try {
            val inp = socket.getInputStream()
            val buf = ByteArray(8192)
            while (!closed.get()) {
                val n = inp.read(buf)
                if (n == -1) break
                sendToClient(PacketUtils.FLAG_PSH or PacketUtils.FLAG_ACK, buf.copyOf(n))
            }
            sendToClient(PacketUtils.FLAG_FIN or PacketUtils.FLAG_ACK, ByteArray(0))
        } catch (_: Exception) {
        } finally { close() }
    }

    @Synchronized
    private fun sendToClient(flags: Int, payload: ByteArray) {
        try {
            val pkt = PacketUtils.buildTcpPacket(
                srcIP = serverIP, dstIP = clientIP,
                srcPort = serverPort, dstPort = clientPort,
                seq = localSeq, ack = localAck, flags = flags, payload = payload
            )
            tunOut.write(pkt)
            if (payload.isNotEmpty()) localSeq += payload.size
            if (flags and PacketUtils.FLAG_FIN != 0) localSeq++
        } catch (_: Exception) {}
    }

    private fun sendRst() {
        try { tunOut.write(PacketUtils.buildRstPacket(serverIP, clientIP, serverPort, clientPort, localSeq)) } catch (_: Exception) {}
    }

    fun close() {
        if (closed.compareAndSet(false, true)) {
            try { socket.close() } catch (_: Exception) {}
            state = TcpState.CLOSED
        }
    }

    val key get() = sessionKey(clientIP, serverIP, clientPort, serverPort)

    companion object {
        fun sessionKey(cIP: ByteArray, sIP: ByteArray, cPort: Int, sPort: Int) =
            "${PacketUtils.ipToString(cIP)}:$cPort-${PacketUtils.ipToString(sIP)}:$sPort"
    }
}
