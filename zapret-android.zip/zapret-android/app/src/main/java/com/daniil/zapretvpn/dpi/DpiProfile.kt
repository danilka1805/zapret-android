package com.daniil.zapretvpn.dpi

import android.content.Context

data class DpiProfile(
    val id: String,
    val name: String,
    val description: String,
    val mode: String,        // "split", "disorder", "fake", "none"
    val splitPos: Int = 2,   // byte position to split TLS ClientHello
    val repeats: Int = 1
)

object Profiles {
    val ALL = listOf(
        DpiProfile(
            id = "split2",
            name = "Split (pos 2)",
            description = "Делит TLS ClientHello на байте 2. Обходит большинство DPI.",
            mode = "split",
            splitPos = 2
        ),
        DpiProfile(
            id = "split1",
            name = "Split (pos 1)",
            description = "Делит TLS ClientHello на самом первом байте.",
            mode = "split",
            splitPos = 1
        ),
        DpiProfile(
            id = "split40",
            name = "Split (pos 40)",
            description = "Делит после заголовка TLS — подходит для ряда провайдеров.",
            mode = "split",
            splitPos = 40
        ),
        DpiProfile(
            id = "fake",
            name = "Fake + Real",
            description = "Сначала отправляет фейковый пакет, потом настоящий TLS CH.",
            mode = "fake",
            splitPos = 2
        ),
        DpiProfile(
            id = "disorder",
            name = "Disorder",
            description = "Меняет порядок фрагментов — некоторые DPI теряют контекст.",
            mode = "disorder",
            splitPos = 2
        ),
        DpiProfile(
            id = "none",
            name = "Без обхода",
            description = "Трафик идёт без изменений (тест).",
            mode = "none",
            splitPos = 2
        )
    )

    fun byId(id: String) = ALL.find { it.id == id } ?: ALL[0]
}

class ProfileManager(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("profiles", Context.MODE_PRIVATE)

    fun getActiveProfileId(): String = prefs.getString("active_profile", "split2") ?: "split2"

    fun setActiveProfile(id: String) {
        prefs.edit().putString("active_profile", id).apply()
    }

    fun getActiveProfile(): DpiProfile = Profiles.byId(getActiveProfileId())
}
