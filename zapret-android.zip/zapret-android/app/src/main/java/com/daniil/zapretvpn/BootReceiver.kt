package com.daniil.zapretvpn

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs: SharedPreferences = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
        if (prefs.getBoolean("autostart", false)) {
            Intent(context, DpiVpnService::class.java).also {
                it.action = ACTION_START
                context.startForegroundService(it)
            }
        }
    }
}
