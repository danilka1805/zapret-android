package com.daniil.zapretvpn.whitelist

import android.content.Context

/**
 * Manages the domain whitelist.
 * If the whitelist is empty → bypass ALL port-80/443 connections.
 * If non-empty → only bypass connections whose SNI matches a listed domain/suffix.
 */
class WhitelistManager(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("whitelist", Context.MODE_PRIVATE)

    companion object {
        const val KEY_DOMAINS = "domains"
        const val KEY_MODE = "mode"   // "whitelist" | "all"

        val DEFAULT_DOMAINS = listOf(
            "discord.com",
            "discord.gg",
            "discordapp.com",
            "discordapp.net",
            "discord.media",
            "gateway.discord.gg",
            "youtube.com",
            "youtu.be",
            "googlevideo.com",
            "ytimg.com",
            "ggpht.com",
            "googleapis.com",
            "google.com",
            "gstatic.com",
            "instagram.com",
            "cdninstagram.com",
            "facebook.com",
            "fbcdn.net",
            "twitter.com",
            "twimg.com",
            "x.com",
            "twitch.tv",
            "jtvnw.net",
            "twitchapps.com",
            "tiktok.com",
            "ttwimg.com",
            "reddit.com",
            "redd.it",
            "redditmedia.com",
            "redditstatic.com",
            "spotify.com",
            "scdn.co",
            "telegram.org",
            "t.me",
            "github.com",
            "githubusercontent.com",
            "4pda.to",
            "cloudflare.com",
            "cloudflarestream.com",
            // WhatsApp
            "whatsapp.com",
            "whatsapp.net",
            "wa.me",
            "web.whatsapp.com",
            "static.whatsapp.net",
            "mmg.whatsapp.net",
            "media.whatsapp.net",
            "pps.whatsapp.net",
            "v.whatsapp.net",
            "e.whatsapp.net",
            "g.whatsapp.net",
            "www.whatsapp.com"
        )
    }

    init {
        // First launch: save defaults
        if (!prefs.contains(KEY_DOMAINS)) {
            saveDomains(DEFAULT_DOMAINS)
        }
    }

    fun getDomains(): List<String> {
        val raw = prefs.getString(KEY_DOMAINS, "") ?: ""
        return if (raw.isBlank()) emptyList()
        else raw.split("\n").filter { it.isNotBlank() }
    }

    fun saveDomains(domains: List<String>) {
        prefs.edit().putString(KEY_DOMAINS, domains.joinToString("\n")).apply()
    }

    fun getMode(): String = prefs.getString(KEY_MODE, "whitelist") ?: "whitelist"
    fun setMode(mode: String) { prefs.edit().putString(KEY_MODE, mode).apply() }

    fun isEmpty(): Boolean = getMode() == "all"

    /**
     * Returns true if a connection to this port should get DPI bypass applied.
     * Called before SNI is known (SYN stage). In whitelist mode we still let it
     * through — the actual SNI matching happens in TcpSession once ClientHello arrives.
     */
    fun matchesPort(port: Int) = port == 443 || port == 80

    /**
     * Returns true if the given SNI matches the whitelist.
     * Called in DpiProcessor after extracting SNI.
     */
    fun matchesSni(sni: String): Boolean {
        if (getMode() == "all") return true
        val domains = getDomains()
        if (domains.isEmpty()) return true
        val sniLower = sni.lowercase()
        return domains.any { domain ->
            val d = domain.lowercase().trimStart('.')
            sniLower == d || sniLower.endsWith(".$d")
        }
    }

    fun addDomain(domain: String) {
        val current = getDomains().toMutableList()
        if (!current.contains(domain)) {
            current.add(domain)
            saveDomains(current)
        }
    }

    fun removeDomain(domain: String) {
        saveDomains(getDomains().filter { it != domain })
    }
}
