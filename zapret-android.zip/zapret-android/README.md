# ZapretVPN — Android DPI bypass app

Обходит DPI-блокировки через локальный TUN-интерфейс.
**Трафик никуда не уходит** — всё работает на устройстве.

---

## Как работает

Приложение поднимает локальный VPN-интерфейс (TUN) и перехватывает TCP-соединения на портах **80 и 443**.

Для каждого соединения оно само устанавливает TCP-сессию с удалённым сервером через защищённый сокет и при первом TLS-пакете (ClientHello) применяет один из режимов обхода:

| Режим | Что делает |
|-------|-----------|
| **split** | Делит TLS ClientHello на 2 части — DPI не успевает собрать сигнатуру |
| **fake** | Сначала отправляет мусорный пакет, потом настоящий ClientHello |
| **disorder** | Меняет порядок фрагментов |
| **none** | Без обхода (тест) |

Белый список: если включён — обход применяется только к выбранным доменам (SNI).  
Если выключен — ко всем HTTPS/HTTP соединениям.

---

## Сборка в Android Studio

### Требования
- Android Studio Hedgehog (2023.1) или новее
- JDK 17
- Android SDK 34
- Минимальная версия Android: 8.0 (API 26)

### Шаги

1. Открой Android Studio → **File → Open** → выбери папку `zapret-android`
2. Подожди пока синхронизируется Gradle
3. **Build → Build Bundle(s)/APK(s) → Build APK(s)**
4. APK появится в `app/build/outputs/apk/debug/`
5. Установи на телефон: `adb install app-debug.apk`

### Или через командную строку
```bash
cd zapret-android
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

---

## Структура проекта

```
app/src/main/java/com/daniil/zapretvpn/
├── MainActivity.kt              — Главный экран
├── DpiVpnService.kt             — VPN-сервис, TUN reader loop
├── BootReceiver.kt              — Автозапуск после перезагрузки
├── tcp/
│   ├── PacketUtils.kt           — Парсинг IP/TCP, SNI-экстрактор, чексуммы
│   ├── TcpSession.kt            — Одна TCP-сессия с DPI bypass
│   └── TcpSessionManager.kt     — Менеджер всех активных сессий
├── dpi/
│   └── DpiProfile.kt            — Профили обхода + ProfileManager
├── whitelist/
│   ├── WhitelistManager.kt      — Менеджер белого списка доменов
│   └── WhitelistActivity.kt     — Экран редактирования списка
└── ui/
    └── ProfilesActivity.kt      — Экран выбора профиля
```

---

## Встроенные домены в белом списке

Discord, YouTube, Google, Instagram, Facebook, Twitter/X,
Twitch, TikTok, Reddit, Spotify, Telegram, GitHub, 4pda.to, Cloudflare и др.

---

## Добавить EAS Build (если нужен .apk без Android Studio)

Так как это нативный Android-проект (не Expo), собирать нужно через Android Studio
или Gradle. Для сборки без компьютера можно использовать **GitHub Actions**:

```yaml
# .github/workflows/build.yml
name: Build APK
on: [push]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-java@v3
        with: { java-version: '17', distribution: 'temurin' }
      - run: cd zapret-android && ./gradlew assembleDebug
      - uses: actions/upload-artifact@v3
        with:
          name: apk
          path: zapret-android/app/build/outputs/apk/debug/app-debug.apk
```

---

## Ограничения

- Перехватываются только порты **80 и 443** (HTTP/HTTPS)
- UDP (QUIC) пока не обходится — для YouTube QUIC отключится сам и упадёт на TCP
- Требует разрешения VPN при первом запуске (стандартный системный диалог)
- Не требует root
